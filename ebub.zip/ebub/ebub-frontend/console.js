//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// The goal of the console is to help to be as independent of the rest of ebub: the goal is to grow it as a means ///
/// to communicate with the server and to display the results of queries to the 9723 server and to display results ///
/// of the worker's contributions on the screen in a way that is understandable and easy to manipulate             ///
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class Console {
	constructor(parent_div) {
		this.parent_div = parent_div;
		this.init();
	}

	init() { this.init_div(); }

	init_div() {
		this.div = new_child_div(this.parent_div, { wpc: 100, hpc: 100, z: 4096, bg: '#181230', visible: false });
	}

	get is_visible() { return this._is_visible ?? false }
	set is_visible(_is_visible) { this._is_visible = _is_visible; adj_elem_visibility(this.div, this.is_visible) }

	evo_hf() {}
	evo_lf() {}

	refresh_hf() {}
	refresh_lf() {}

}