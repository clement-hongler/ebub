// Ewo map

class Emap {
    constructor(eco) {
        this.eco = eco;
        this.should_reconstruct = true;
        this.init_div();
    }

    init_div() {
        this.x_shift_pc = 0;
        this.soft_x_shift_pc = 0;
        this.max_x_shift_pc = 0;
        this.x_shift_increments = 25;
        this.xpc_by_gid = {}; // the positions of the display of a gid
        this.div = new_child_div(this.eco.div, { xpc: - this.x_shift_pc, wpc: 100, hpc: 100, z: 512, bg: '#000011dd' });
        this.blackboard_div = new_child_div(this.div, { xpc: 0, ypc: 0, wpc: 100, hpc: 100, z: 512, bg: '#000011dd', is_visible: false });
        this.is_visible = false;
    }

    get is_visible() { return this._is_visible ?? false }
    set is_visible(_is_visible) {  this.evo_and_refresh_lf_soon(); this._is_visible = _is_visible; }

    get is_blackboard() { return this._is_blackboard_visible ?? false }
    set is_blackboard(_is_blackboard_visible) { this._is_blackboard_visible = _is_blackboard_visible; }

    evo_and_refresh_lf_soon() { 
        if (this.prev_refresh_timeout) { clearTimeout(this.prev_refresh_timeout); this.prev_refresh_timeout = undefined; }
        this.prev_refresh_timeout = setTimeout(() => { this.evo_lf(); this.refresh_lf(); this.prev_refresh_timeout = undefined; }, 1); 
    }

    reconstruct_soon() { this.should_reconstruct = true } // {?} Clarify when this is called

    reconstruct_blackboard() {
        this.blackboard_div.innerHTML = "blackboard";
    }

    reconstruct() { // called if should_reconstruct is true
        this.div.innerHTML = '';
        this.ega_divs_by_gid = {};
        this.ega_alinks_by_gid = {};
        this.ewo_alinks_by_wid_by_gid = {};
        this.xs_by_gid = {}; // the positions of the display of a wid (in percent)

        const [ox, oy, w, h] = [2, 2, 15, 2]; // weird
        let [x, y] = [ox, oy]; // units are in percent {?} should be improved/clarified
        const wids_with_ega = new Set(); 
        let egas = eco.gids.map(gid => eco.egas_by_gid[gid]).filter(ega => ega.name != 'blackboard');
        let num_cols = 1;

        for (const ega of egas) { // {?} should be made much leaner and cleaner and should add links
            const [gid, name] = [ega.gid, ega.full_name]; 
            const num_lines = ega.is_cur_or_expanded ? 1 + ega.wids.length : 1;
            if (y + num_lines * h + oy >= 100) { y = oy; x += w; num_cols++; } // {?} not very clean... oy plays the role of margin here
            this.xs_by_gid[gid] = x;
            const ega_div = new_child_div(this.div, { xpc: x, ypc: y, wpc: w, hpc: h });
            const ega_name_div = new_child_div(ega_div, {});
            ega_div.innerText = name;  // {?} to fix with style
            const ega_alink = new_child_alink(this.div, { xpc: x, ypc: y, wpc: w, hpc: h, href: '#', font_weight: 'bold', color: 'white', text_decoration: 'none' });
            ega_alink.innerText = name; 
            // {?} experimental
            ega_alink.addEventListener('mouseover', () => ega_alink.style.color = '#ffdd00'); 
            ega_alink.addEventListener('mouseleave', () => ega_alink.style.color = 'white'); 
            ega_alink.addEventListener('click', (event) => { eco.nav_to_ega_by_gid(gid); this.is_visible = event.metaKey || event.ctrlKey; });
            if (ega.sync_addresses?.length > 0) ega_div.innerHTML += ' (synced with ' + ega.sync_addresses.join(', ') + ')';
            
            this.ega_divs_by_gid[gid] = ega_div;
            this.ega_alinks_by_gid[gid] = ega_alink;
            y += h;
            this.ewo_alinks_by_wid_by_gid[gid] = {};
            if (ega.is_cur_or_expanded) {
                for (const wid of ega.wids){ 
                    wids_with_ega.add(wid);
                    const ewo = eco.ewos_by_wid[wid];
                    const ewo_alink = new_child_alink(this.div, { xpc: x + 1, ypc: y, wpc: w, hpc: h, href: '#', text_decoration: 'none' });
                    ewo_alink.addEventListener('mouseover', () => ewo_alink.style.color = '#ffdd00');
                    ewo_alink.addEventListener('mouseleave', () => ewo_alink.style.color = 'white'); 
                    ewo_alink.addEventListener('click', (event) => { eco.nav_to_ewo_by_wid_with_gid(wid, ega.gid); this.is_visible = event.metaKey || event.ctrlKey; });
                    this.ewo_alinks_by_wid_by_gid[gid][wid] = ewo_alink; 
                    ewo_alink.innerText = ewo?.name ?? '';
                    y += h; 
                }
            }
        }
        this.max_x_shift_pc = Math.max(num_cols - 3, 1) * this.x_shift_increments;

//        this.max_x_shift_pc = Math.ceil(x / w) * w + 100;
        adj_elem(this.div, { wpc: this.max_x_shift_pc + 50 }); // {?} hacky

        this.wids_without_ega = eco.wids.filter(wid => !wids_with_ega.has(wid));
        this.should_reconstruct = false;
    }

    evo_lf() {
        // {?} Would be good to have a mechanism to decide if the things to display have changed at all
        if (this.should_reconstruct) this.reconstruct(); 
        const cur_ewo_gids = eco.cur_ewo_gids ?? [];
        for (const gid in this.ega_divs_by_gid) {
            const { wids, is_expanded, is_cur_or_expanded, main_wid } = eco.egas_by_gid[gid];
            const fg = (cur_ewo_gids.indexOf(gid) != -1) ? '#ff0000' : '#ffffff';
            const font_style = is_expanded ? 'regular' : 'italic';
            adj_elem(this.ega_divs_by_gid[gid], { fg, font_style });
            adj_elem(this.ega_alinks_by_gid[gid], { fg, font_style });
            if (is_cur_or_expanded) {
                for (const wid of (wids ?? [])) {
                    const font_weight = wid == main_wid ? 'bold' : 'normal';
                    adj_elem(this.ewo_alinks_by_wid_by_gid[gid][wid], { fg: (wid == eco.cur_wid ? '#ff0000' : '#ffffff'), font_weight })
                }
            }
        }
    }

    ensure_cur_ega_is_vis() {
        let cur_ega_x = this.xs_by_gid[this.eco.cur_gid]; // in percent
        if (is_def(cur_ega_x)) { // {?} very hacky, but it works quite well
            while (this.x_shift_pc + 100 < cur_ega_x * 2) this.x_shift_pc += this.x_shift_increments;
            while (this.x_shift_pc > cur_ega_x * 2) this.x_shift_pc -= this.x_shift_increments;
        }
    }

    refresh_lf() { 
        adj_elem_visibility(this.div, this.is_visible); 
    }

    evo_hf() { 
        if (this.should_reconstruct) this.evo_lf(); 
        this.soft_x_shift_pc = adj_float(this.soft_x_shift_pc, this.x_shift_pc);
    }

    refresh_hf() {
        if (!this.is_visible) return;
        adj_elem(this.div, { fsp: 10.5 / this.eco.zoom_level });
        adj_elem(this.div, { xpc: -this.soft_x_shift_pc });
    }

    on_event(event, key_event) {
        const emap_event = emap_events_by_shortcut[key_event.key_combination]; // undefined is fine
        if (event == 'toggle_eco_map') { this.is_visible ^= true; return true; }
        if (event == 'toggle_blackboard_mode') { this.is_blackboard ^= true; return;}

        if (!this.is_visible) return false; 
        ////////// IS_VISIBLE=TRUE BELOW ///////////
        if (event == 'deep_action') { this.is_visible = false; return true; }
        if (this.eco.cur_ega != undefined) {
            if (event == 'expand_cur_ega') { this.eco.cur_ega.is_expanded = true; this.reconstruct(); this.evo_lf(); }
            if (event == 'collapse_cur_ega') { this.eco.cur_ega.is_expanded = false; this.reconstruct(); this.evo_lf(); }
        }
        if (emap_event) { // units are in percent below
            if (emap_event == 'move_right_in_emap') { 
                // {?} very unclear code
                this.x_shift_pc = Math.max(this.x_shift_pc - this.x_shift_increments, 0); 
            }
            if (emap_event == 'move_left_in_emap') { 
                this.x_shift_pc = Math.min(this.x_shift_pc + this.x_shift_increments, this.max_x_shift_pc - 25); 
            }
            return true;
        }
        return false; 
    }
}

function fill_ega_menu_div(ega, ega_div) { // {?} temporary code (to get an idea of what we really want)
    const [ewo_width, ewo_height, x_shift, y_shift] = [320, 24, 16, 32]; // {?} magical numbers to be put somewhere else
    const [menu_width, menu_height] = [ewo_width + x_shift, ewo_height * (1 + ega.ewos.length) + y_shift]; 
    const margins = { margin_left: '8px', margin_right: '8px', margin_top: '4px', margin_bottom: '4px' };

    ega_div.innerHTML = '';
    adj_elem(ega_div, { position: 'absolute', x: 32, y: 16, w: menu_width, h: menu_height, bg: '#00000066', fg: 'white', z: 128, fsp: 13, ... margins })

    const ega_name_div = new_child_div(ega_div, {... margins });
    ega_name_div.innerText = ega.full_name;
    let [x, y] = [x_shift, ewo_height + y_shift];
    for (const ewo of ega.ewos) {
        const name = ewo.name;
        const href = `${name}.html`; // {?} should be cleaner
        const ewo_div = new_child_div(ega_div, { x, y, w: ewo_width, h: ewo_height, position: 'absolute', bg: '#00000066', z : 0, fsp: 13, ... margins });
        const ewo_alink = new_child_alink(ewo_div, { href, position: 'absolute' });
        ewo_alink.innerText = name; 
        y += ewo_height;
    }
}
