const ebu_padding_dict = { padding_left: 6.6, padding_right: 6.6, padding_top: 1.1, padding_bottom: 7 };  // magical numbers
const deep_text_sd = { z: 256, bg: '#330000', fg: '#ffffff', fsp: 13, padding_left: 10.5, padding_top: 5, margin_left: 0, border_width: 0, lh: '1.4', resize: 'None', font_family: 'Courier' };

const input_padding_dict = { z: 256, bg: colors.input_bg, fg: colors.input_fg, fsp: 13, padding_left: 8.5, padding_top: 4, gmar: 0, border_width: 0, line_height: '1.4',resize: 'None' };

// Decoration for the bubs
// How does the bub decoration? How do they move around? 
class Decoration {
	constructor(type, x, y, fill=undefined, stroke=undefined) {
		this.svg = new Svg(64, 64);
        this.svg.svg_node.style.z_index = 256;
		this._type = undefined;
		this.type = type;
		[this.x, this.y] = [x, y];
		[this.fill, this.stroke] = [fill ?? '#ffffff', stroke ?? '#ffffff'];
        this.is_visible = true;
	}

	get fill() { return this._fill }
	set fill(_fill) {
	  	this._fill = _fill;
	  	let firstSvgChild = first(this.svg_node.children);
		if (firstSvgChild) firstSvgChild.setAttribute('fill', _fill);
	 }

	get stroke() { return this._stroke }
	set stroke(_stroke) {
		this._stroke = _stroke;
		let firstSvgChild = first(this.svg_node.children);
		if (firstSvgChild) firstSvgChild.setAttribute('stroke', _stroke);
	}

	get svg_node() { return this.svg.svg_node }
	set svg_node(_svg_node) { this.svg.svg_node = _svg_node }

	get type() { return this._type }

	set type(_type) {
		if (this._type == _type) return; else this.__type = _type;
		for (let child of this.svg_node.children) this.svg_node.removeChild(child);
		switch (_type) {
			case 'circle': this.svg.add_new_circle(31, 12, 3, '#ffffff'); break;
			case 'square': this.svg.add_new_rect(29, 10, 6, 6, '#ffffff'); break;
			default: break;
		}
	}


	get x() { return this._x } set x(_x) { this._x = _x; this.svg.x = _x; }
	get y() { return this._y } set y(_y) { this._y = _y; this.svg.y = _y; }

    get is_visible() { return this._is_visible ?? false }
    set is_visible(_is_visible) { this._is_visible = _is_visible; this.svg.display = _is_visible ? 'Block' : 'None' }
}
