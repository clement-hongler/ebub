class Helper {
	constructor(eco) {
		this.eco = eco;
		this.init_div();
	}

	get is_visible() { return this._is_visible ?? false }
	set is_visible(_is_visible) { this._is_visible = _is_visible; if (_is_visible) { this.reconstruct_soon(); this.refresh_lf_soon(); } }

	init_div() {
        this.div = new_child_div(this.eco.div, { wpc: 100, hpc: 100 });
        this.refresh_lf_soon();
	}


	reconstruct_soon() {
		setTimeout(() => { this.reconstruct_helper(); }, 1); 
	}

	refresh_lf_soon() { setTimeout(() => { this.refresh_lf(); }, 1); }

	refresh_hf() { adj_elem(this.div, { fspx: 18 / this.eco.zoom_level }); }

	refresh_lf() { adj_elem_visibility(this.div, this.is_visible); }

	reconstruct_helper() {

		/* this.div.style.transform = 'scale(1)';
		this.div.style.transformOrigin = '0 0'; */
		// units are percent at this point
		const [x_margin, y_margin] = [2, 2];
		const [x_spacing, y_spacing] = [2, 0];
		const [w, h] = [25, 3];

		adj_elem(this.div, { x: 0, y: 0, z: 1024, bg: '#000022dd', wpc: 100, hpc: 100 });

		let [x, y] = [x_margin, y_margin];
		// {?} clean up (experimental code)
		for (const [event_name, key_combination] of Object.entries(shortcuts_by_eco_event)) { // defined in events.js
			const key_div = new_child_div(this.div, { xpc: x, ypc: y, wpc: w, hpc: h });
			const event_alink = new_child_alink(key_div, { href: '#', font_style: 'bold', position: 'relative', text_decoration: 'none', color: 'white' });
			// {?} determine why this click is not working
			event_alink.addEventListener('click', (event) => { this.eco.on_event(event_name); });
			event_alink.addEventListener('mouseover', () => event_alink.style.color = '#ffdd00'); 
            event_alink.addEventListener('mouseleave', () => event_alink.style.color = 'white'); 
			event_alink.innerText = event_name;
			const key_combination_span = new_child_span(key_div);
			key_combination_span.innerText = ': ' + key_combination;
			y += y_spacing + h;
			if (y + y_margin >= 100) { x += x_spacing + w; y = y_margin; }
		}
		for (const [event_name, key_combinations] of Object.entries(command_shortcuts_by_eco_event)) { // defined in events.js
			const key_div = new_child_div(this.div, { xpc: x, ypc: y, wpc: w, hpc: h });
			const full_key_combinations = key_combinations.map(key_combination => `[${shortcuts_by_eco_event['command_mode']} ${key_combination}]`);
			const event_alink = new_child_alink(key_div, { href: '#', font_style: 'bold', position: 'relative', text_decoration: 'none', color: 'white' });
			event_alink.innerText = event_name;
			event_alink.addEventListener('mouseover', () => event_alink.style.color = '#ffdd00'); 
            event_alink.addEventListener('mouseleave', () => event_alink.style.color = 'white'); 
            event_alink.addEventListener('click', (event) => { this.eco.on_event(event_name); });
			const key_combination_span = new_child_span(key_div);
			key_combination_span.innerText = ': ' + full_key_combinations.join(' or '); 

			y += y_spacing + h;
			if (y + y_margin >= 100) { x += x_spacing + w; y = y_margin; }
		}

	}
}

async function on_add_help_ega(eco) {
	try {
		const file_path = path.join(path.app_dir, 'ebub-resources', 'ebub-help.json');
		ega_dict = JSON.parse(await eapi.load({ file_path }));
		const ega = sync_ega_from_dict(eco, ega_dict);
		eco.cur_gid = ega?.gid;
	}
	catch (err) {
		console.log("Error loading help ega:", err);
	}
}
