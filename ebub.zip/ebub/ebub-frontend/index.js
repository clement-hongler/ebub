let eco = undefined; // The current eco [main class where everything is happening]

adj_elem(document.body, { bg : '#000000', fg : '#fedcba', fsp : 13 });
document.body.style.overflow = 'hidden';

const default_eco_file_name = 'eco.json';
const default_eco_history_file_name = 'eco-history.json';
const config_file_name = 'ebub-config.json';

let default_eco_file_path = undefined; // will be defined one the path is defined
let default_eco_history_file_path = undefined; // will be defined one the path is defined
let eco_file_paths = [], cur_eco_file_path = undefined; // should be guaranteed to point to something
let cur_eco_history_file_path = undefined;

const timestamp_server = 'wss://eulalie.io:9724';

async function load_config() { // Assumes path is already well formed
    cur_eco_file_path = default_eco_file_path; // if all else fails, we will have a an eco_file_path
    cur_eco_history_file_path = default_eco_history_file_path; // {?} maybe make this more flexible later
    if (!await eapi.is_file_existing({ file_name: config_file_name, is_within_data_dir: true })) return;
    let data_dict = undefined;
    try { data_dict = JSON.parse(await eapi.load({ file_name: config_file_name, is_within_data_dir: true })) }
    catch (e) { console.log(`Error ${e} while trying to load the config file ${config_file_name} in the data dir`); return; }
    eco_file_paths = data_dict.eco_file_paths ?? data_dict.ecoFilePaths ?? data_dict.cosmosFilePaths ?? [];
    cur_eco_file_path = data_dict.cur_eco_file_path ?? data_dict.curCosmos ?? first(eco_file_paths);
}

 // [should be called when we add a new eco filename]
async function save_config() { 
    const data = JSON.stringify({ eco_file_paths, cur_eco_file_path });
    await eapi.save({ file_name: config_file_name, data, is_within_data_dir: true }); 
}

async function add_eco_file_path(file_path) {
    if (typeof file_path != typeof '') return; 
    eco_file_paths.push(file_path);
    await save_config();
    return eco_file_paths.length - 1; // that's the index of the eco we loaded
}

async function on_add_eco_file_path() {
    const dialog_title = "Pick eco file path to create:"
    const fileData = await eapi.request_file_to_save({ dialog_title, default_file_name : 'new-eco.json' });
    const { canceled, file_path } = fileData; if (canceled) return;
    const new_eco_file_index = await add_eco_file_path(file_path);
    switch_eco(new_eco_file_index);
}

async function on_add_existing_eco_file_path() {
    const dialog_title = "Pick eco file path to load"
    const fileData = await eapi.request_file_to_open({ dialog_title });
    const { canceled, file_paths } = fileData; if (canceled || file_paths[0] == undefined) return;
    const new_eco_file_index = await add_eco_file_path(file_paths[0]);
    switch_eco(new_eco_file_index);
}

async function load_eco() { eco = new Xeco(undefined, cur_eco_file_path, document.body); return await on_load_eco(eco); } // to move to sync.js

async function switch_eco(new_eco_file_index) { // {?} to deprecate, ultimately
    cur_eco_file_path = next_val_circ(eco_file_paths, cur_eco_file_path);
    console.log("Trying to move to", cur_eco_file_path);
    const res = await load_eco(); 
    if (res) await save_config();
}

async function init_path() {
    path.sep = await eapi.get_path_sep(); // path.sep is defined in common.js
    path.app_dir = await eapi.get_app_dir();
    path.data_dir = await eapi.get_data_dir();
    path.media_dir = path.join(path.data_dir, 'media');

    default_eco_file_path = path.join(path.data_dir, default_eco_file_name); // global variable
    default_eco_history_file_path = path.join(path.data_dir, default_eco_history_file_name);
}

async function init() {
    await init_path();

    await eapi.ensure_dir_exists({ dir: path.data_dir });
    await eapi.ensure_dir_exists({ dir: path.media_dir });


    attach_event_handlers(); // defined in events.js

    await load_config();

    if (!eco_file_paths.includes(default_eco_file_path)) eco_file_paths.push(default_eco_file_path); // will not affect the current ecoFilePath

    console.log(`Current eco file path: ${cur_eco_file_path}`);

    await load_eco(); // by default, the eco file path
    
    refresh_lf();
    const res = await eapi.is_ws_available({ host: 'localhost', port: 9723 });
    console.log("Local server status:", res ? 'available' : 'not available'); 

}

async function is_local_ws_available() { console.log(await eapi.is_ws_available({ host: 'localhost', port: 9723 })); } // {?} Doesn't work yet

// should be called with a low period, and also when a non-trivial event occurs
function refresh_lf() { eco.refresh_lf() }
function refresh_hf() { eco.refresh_hf() }
// We could later do away without this, if we have a direct websocket 
// connection between the front interface and the backend
// but it's good to keep for now
// async function checkResponses() { await xeco.on_check_agent_responses() }

// moves things around
function evo_lf() { eco.evo_lf() }
function evo_hf() { eco.evo_hf() }

setTimeout(init, 0);
const lf_refresh_clock = setInterval(refresh_lf, 1000);
const hf_refresh_clock = setInterval(refresh_hf, 20);
const lf_evo_clock = setInterval(evo_lf, 1000); // later we can make things evolve with a lower frequency even
const hf_evo_clock = setInterval(evo_hf, 20);
// setInterval(() => eco.showTraceProfile(), 1000);

