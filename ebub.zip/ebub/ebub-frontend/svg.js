/*
	The SVG class creates an SVG element (which can then be put in a div),
	We need to specify a size initially, and then we can draw in it, by adding things
	like a circle, etc. 
*/

function new_svg_element(el_type_name)  { return document.createElementNS('http://www.w3.org/2000/svg', el_type_name) }

class Svg {
	constructor({ w, h }, parent_elem=undefined) { 
		this.svg_node = new_svg_element('svg');
        this.svg_node.style.position = 'absolute';
        [this.w, this.h] = [w ?? 256, h ?? 256];
        if (parent_elem != undefined) parent_elem.appendChild(this.svg_node);
	}

    //////////////////////
    /// ACCESS METHODS ///
    //////////////////////

    get x() { return this._x ?? 0 }
    set x(_x) { this._x = _x; this.svg_node.style.left = _x + 'px'; }
    get y() { return this._y ?? 0 }
    set y(_y) { this._y = _y; this.svg_node.style.top = _y + 'px'; }
    get w() { return this._w } set w(_w) { this._w = _w; this.svg_node.setAttribute('width', _w + 'px'); }
    get h() { return this._h } set h(_h) { this._h = _h; this.svg_node.setAttribute('height', _h + 'px'); }

    get z_index() { return this.svg_node.zIndex }
    set z_index(_z_index) { this.svg_node.zIndex = _z_index }

    get is_visible() { return this._is_visible ?? true }
	set is_visible(_is_visible) { this._is_visible = _is_visible; adj_elem_visibility(this.svg_node, _is_visible); }

	update_pos(x, y) { [this.x, this.y] = [x, y] }


    add_elem(elem) { this.svg_node.append(elem); }

    // calls the remove method of the corresponding svg element
    rem_elem(elem) { elem.destroy(); } 

	add_new_circle(cx, cy, r, fill, stroke) { 
        let circle = new Elem('circle', this.svg_node);
        [circle.cx, circle.cy, circle.r, circle.fill, circle.stroke] = [cx, cy, r, fill, stroke]; 
        return circle 
    }

	add_new_rect(x, y, w, h, fill, stroke) { 
        let rect = new Elem('rect', this.svg_node); [rect.x, rect.y, rect.w, rect.h, rect.fill, rect.stroke] = [x, y, w, h, fill, stroke]; 
        return rect;
    }

	add_new_ellipse(cx, cy, rx, ry, fill, stroke) { 
        let ellipse = new Elem('ellipse', this.svg_node);
        [ellipse.cx, ellipse.cy, ellipse.rx, ellipse.ry, ellipse.fill, ellipse.stroke] = [cx, cy, rx, ry, fill, stroke];
        return ellipse 
    }

	add_new_line(x1, y1, x2, y2, stroke) { 
        let line = new Elem('line', this.svg_node);
        [line.x1, line.y1, line.x2, line.y2, line.stroke] = [x1, y1, x2, y2, stroke];
        return line; 
    }

    add_new_polyline(points) { let polyline = new Elem('polyline', this.svg_node); if (points) polyline.points = points; return polyline }


    ////////////////////////
    /// LEGACY FUNCTIONS ///
    ////////////////////////

	add_new_polygon(points) { let polygon = new Elem('polygon', this.svg_node); if (points) polygon.points = points; return polygon }
	add_new_path(instructions) { let path = new Elem('path', this.svg_node); if (points) path.points = points; return path }

    add_new_defs_node() { const defsNode = new_svg_element('defs'); this.svg_node.append(defsNode); return defsNode; }
    add_new_arrow_marker_node(id='arrowhead') {
        const defs = new Elem('defs', this.svg_node);
        const marker = new Elem('marker', defs.elem);
        marker.id = id;
        marker.marker_width = '10';
        marker.marker_height = '7';
        marker.ref_x = '0';
        marker.ref_y = '3.5';
        marker.orient = 'auto';
        const polygon = new 
        Elem('polygon', marker.elem);
        polygon.points = [[0, 0], [10, 3.5], [0, 7]];
        polygon.fill = 'red';
    }
}


//////////////////////
/// SVG ELEM CLASS ///
//////////////////////

class Elem {
    constructor(elem_type_name, parent_svg_node) {
        this.elem_type_name = elem_type_name;
        this.elem = new_svg_element(elem_type_name);
        if (is_def(parent_svg_node)) parent_svg_node.appendChild(this.elem);
    }

    destroy() { this.elem.remove() }

    ////////////////////////////////////////
    /// UNIVERSAL (x, y) GETTERS/SETTERS ///
    ////////////////////////////////////////
    get ux() { 
        switch (this.elem_type_name) {
            case 'rect': return this.x; 
            case 'circle': return this.cx - this.r; 
            case 'ellipse': return this.cx - this.rx;
            case 'line': return Math.min(this.x1, this.x2);
            case 'polyline': case 'polygon': case 'path': return Math.min(... this.points.map(point => point[0]));
            default: return undefined;
        }
    }

    set ux(_ux) {
        const dx = _ux - this.ux; // the amount by which we should move; this should be streamlined into a global modification
        switch (this.elem_type_name) {
            case 'rect': this.x = _ux; return;
            case 'circle': this.cx = _ux + this.r; return;
            case 'ellipse': this.cx = _ux + this.rx; return;
            case 'line': const dx = _ux - Math.min(this.x1, this.x2); this.x1 += dx; this.x2 += dx; return;
            case 'polyline': case 'polygon': case 'path': {
                // Needs clean-up
                const old_ux = Math.min(... this.points.map(point => point[0]));
                const dx = _ux - old_ux;
                this.points = this.points.map(point => [point[0] + dx, point[1]]); return;
            }
        }
    }

    get uy() { 
        switch (this.elem_type_name) {
            case 'rect': return this.y;
            case 'circle': return this.y - this.r;
            case 'ellipse': return this.cy - this.ry;
            case 'line': return Math.min(this.y1, this.y2);
            case 'polyline': case 'polygon': case 'path': return Math.min(... this.points.map(point => point[1]));
            default: return undefined;
        }
    }

    set uy(_uy) {
        const dy = _uy - this.uy; // the amount by which we should move; this should be streamlined into a global modification
        switch (this.elem_type_name) {
            case 'rect': this.y = _uy; return;
            case 'circle': this.cy = _uy + this.r; return;
            case 'ellipse': this.cy = _uy + this.ry; return;
            case 'line': const dy = _uy - Math.min(this.y1, this.y2); this.y1 += dy; this.y2 += dy; return; // {?} TO REVISE
            case 'polyline': case 'polygon': case 'path': {
                // Needs clean-up
                const old_uy = Math.min(... this.points.map(point => point[1]));
                const dy = _uy - old_uy;
                this.points = this.points.map(point => [point[0], point[1] + dy]); return;
            }
        }
    }

    get uw() { 
        switch (this.elem_type_name) {
            case 'rect': return this.w;
            case 'circle': return 2 * this.r;
            case 'ellipse': return 2 * this.rx;
            case 'line': return Math.abs(this.x2 - this.x1);
            case 'polyline': case 'polygon': case 'path': {
                return Math.max(... this.points.map(point => point[0])) - Math.min(... this.points.map(point => point[0]));
            }
            default: return undefined;
        }
    }

    set uw(_uw) {
        switch (this.elem_type_name) {
            case 'rect': this.w = _uw; return;
            case 'circle': this.r = _uw / 2; return;
            case 'ellipse': this.rx = _uw / 2; return;
            case 'line': this.w = _uw; if (this.x1 < this.x2) this.x2 = this.x1 + _uw; else this.x1 = this.x2 + _uw; return; // {?} TO REVISE
            case 'polyline': case 'polygon': case 'path': {
                _uw = Math.max(32, _uw);
                // Needs clean-up // The outer Math.max(..., 1) is to prevent division by zero errors
                const old_uw = Math.max(Math.max(... this.points.map(point => point[0])) - Math.min(... this.points.map(point => point[0])), 1);
                const scafax = _uw / old_uw;
                const pointxmin = Math.min(... this.points.map(point => point[0]));
                this.points = this.points.map(point => [(point[0] - pointxmin) * scafax + pointxmin, point[1]]); return;
            }
        }
    }

    get uh() { 
        switch (this.elem_type_name) {
            case 'rect': return this.h;
            case 'circle': return 2 * this.r;
            case 'ellipse': return 2 * this.ry;
            case 'line': return Math.abs(this.y2 - this.y1);
            case 'polyline': case 'polygon': case 'path': {
                return Math.max(... this.points.map(point => point[1])) - Math.min(... this.points.map(point => point[1]));
            }
            default: return undefined;
        }
    }

    set uh(_uh) {
        switch (this.elem_type_name) {
            case 'rect': this.h = _uh; return;
            case 'circle': this.r = _uh / 2; return;
            case 'ellipse': this.ry = _uh / 2; return;
            case 'line': this.h = _uh; if (this.y1 < this.y2) this.y2 = this.y1 + _uh; else this.y1 = this.y2 + _uh; return;
            case 'polyline': case 'polygon': case 'path': {
                _uh = Math.max(32, _uh);
                // Needs clean-up // The outer Math.max(..., 1) is to prevent division by zero errors
                const old_uh = Math.max(Math.max(... this.points.map(point => point[1])) - Math.min(... this.points.map(point => point[1])), 1);
                const scafay = _uh / old_uh;
                const pointymin = Math.min(... this.points.map(point => point[1]));
                this.points = this.points.map(point => [point[0], (point[1] - pointymin) * scafay + pointymin]); return;
            }
        }
    }

    get x() { return this._x }
    set x(_x) { this._x = _x; if (is_def(_x)) this.elem.setAttribute('x', _x + 'px'); }

    get y() { return this._y }
    set y(_y) { this._y = _y; if (is_def(_y)) this.elem.setAttribute('y', _y + 'px'); }

    get x1() { return this._x1 }
    set x1(_x1) { this._x1 = _x1; if (is_def(_x1)) this.elem.setAttribute('x1', _x1 + 'px'); }

    get y1() { return this._y1 }
    set y1(_y1) { this._y1 = _y1; if (is_def(_y1)) this.elem.setAttribute('y1', _y1 + 'px'); }

    get x2() { return this._x2 }
    set x2(_x2) { this._x2 = _x2; if (is_def(_x2)) this.elem.setAttribute('x2', _x2 + 'px'); }

    get y2() { return this._y2 }
    set y2(_y2) { this._y2 = _y2; if (is_def(_y2)) this.elem.setAttribute('y2', _y2 + 'px'); }

    get w() { return this._w }
    set w(_w) { this._w = _w; if (is_def(_w)) this.elem.setAttribute('width', _w + 'px'); }

    get h() { return this._h }
    set h(_h) { this._h = _h; if (is_def(_h)) this.elem.setAttribute('height', _h + 'px'); }

    get r() { return this._r }
    set r(_r) { this._r = _r; if (is_def(_r)) this.elem.setAttribute('r', _r + 'px'); }

    get cx() { return this._cx }
    set cx(_cx) { this._cx = _cx; if (is_def(_cx)) this.elem.setAttribute('cx', _cx + 'px'); }

    get cy() { return this._cy }
    set cy(_cy) { this._cy = _cy; if (is_def(_cy)) this.elem.setAttribute('cy', _cy + 'px'); }

    get rx() { return this._rx }
    set rx(_rx) { this._rx = _rx; if (is_def(_rx)) this.elem.setAttribute('rx', _rx + 'px'); }

    get ry() { return this._ry }
    set ry(_ry) { this._ry = _ry; if (is_def(_ry)) this.elem.setAttribute('ry', _ry + 'px'); }

    get fill() { return this._fill }
    set fill(_fill) { this._fill = _fill; if (is_def(_fill)) this.elem.setAttribute('fill', _fill); }

    get stroke() { return this._stroke }
    set stroke(_stroke) { this._stroke = _stroke; if (is_def(_stroke)) this.elem.setAttribute('stroke', _stroke); }

    get points() { return this._points ?? [] }
    // Points are to be a list of lists of two coordinates
    set points(_points) { 
        this._points = _points; 
        const point_strings = _points.map(point => `${point[0]} ${point[1]}`).join(' ');
        this.elem.setAttribute('points', point_strings);
    }

    get bezier_dict() { return this._bezier_dict ?? {} }

    set bezier_dict({ first_point, points, controls }) { // {?} to be tested and improved
        this._bezier_dict = { first_point, points, controls };
        const p2s = (({ x, y }) => `${x} ${y}`); // point to string
        let bezier_string = `M ${p2s(first_point)}`;
        if (!(points?.length > 0 && points?.length == controls?.length)) return;
        for (let i = 0; i < Math.min(points.length, controls.length); i++) {
            const point = points[i];
            const control = controls[i];
            if (control.length == 2) bezier_string += '\n' + `Q ${p2s(control[0])} ${p2s(control[1])}, ${p2s(point)}`;
            if (control.length == 3) bezier_string += '\n' + `C ${p2s(control[0])} ${p2s(control[1])} ${p2s(control[2])}, ${p2s(point)}`;
        }
        this.elem.setAttribute('d', bezier_string);
    } 

    set orient(orient) { this.elem.setAttribute('orient', orient) }
    set id(id) { this.elem.setAttribute('id', id) }
    set ref_x(ref_x) { this.elem.setAttribute('ref-x', ref_x) }
    set ref_y(ref_y) { this.elem.setAttribute('ref-y', ref_y) }
    set marker_width(marker_width) { this.elem.setAttribute('marker-width', marker_width) }
    set marker_height(marker_height) { this.elem.setAttribute('marker-height', marker_height) }

    get num_points() { return this.points.length }

    u_move(x, y) { this.ux += x; this.uy += y; }
    u_resize(dw, dh) { this.uw = Math.max(this.uw + dw, 0); this.uh = Math.max(this.uh + dh, 0); }

    set stroke_width(_stroke_width) { this.elem.setAttribute('stroke-width', _stroke_width) }
    set marker_start_id(id) { this.elem.setAttribute('marker-start', `url(#${id})`); } 
    set marker_end_id(id) { this.elem.setAttribute('marker-end', `url(#${id})`); } 



}

class Cross extends Svg {
	constructor(cx, cy, rx, ry, stroke) {
		super({ w: 256, h: 256 });
		this.z_index = 1; 
        [this.rx, this.ry] = [rx, ry];
        this.stroke = stroke;
        this.update_pos(cx, cy);
		this.init_svg();
	}

    init_svg() {
        this.horLine = this.add_new_line();
		this.verLine = this.add_new_line();
        [this.horLine.x1, this.horLine.y1] = [0, this.ry / 2];
        [this.horLine.x2, this.horLine.y2] = [this.rx, this.ry / 2];
        [this.verLine.x1, this.verLine.y1] = [this.rx / 2, 0];
        [this.verLine.x2, this.verLine.y2] = [this.rx / 2, this.ry];
        
        this.horLine.stroke = this.stroke;
        this.verLine.stroke = this.stroke;
	}

	update_pos(cx, cy) {
		[this.cx, this.cy] = [cx, cy];
		const nodeStyle = this.svg_node.style;
		[nodeStyle.left, nodeStyle.top] = [(cx - this.rx / 2) + 'px', (cy - this.ry / 2) + 'px'];
	}
}


// {?} Initially an arrow svg, but later, we can add several intermediate points
class SvgLink extends Svg {
    constructor(ox, oy, dx, dy, stroke) { 
        super({ w: 1024, h: 1024 }); 
        [this._ox, this._oy, this._dx, this._dy] = [ox, oy, dx, dy];
        this.intermediatePoints = []; // {?} TO BE ADDED LATER
        this.lines = [];
        this._stroke = stroke;
        for (let i = 0; i < 5; i++) this.lines.push(this.add_new_line(0, 0, 1, 1, stroke));
        this.update();
        this.z_index = 10000; 
    }
    // whether horizontal or vertical
    get orientation() { return this._orientation ?? 'none' } set orientation(_orientation) { this._orientation = _orientation; this.update() }
    get ox() { return this._ox ?? 0 } set ox(_ox) { this._ox = _ox; this.update(); }
    get oy() { return this._oy ?? 0 } set oy(_oy) { this._oy = _oy; this.update(); }
    get dx() { return this._dx ?? 0 } set dx(_dx) { this._dx = _dx; this.update(); }
    get dy() { return this._dy ?? 0 } set dy(_dy) { this._dy = _dy; this.update(); }
    get stroke() { return this._stroke } set stroke(_stroke) { this._stroke = _stroke; this.lines.forEach(line => line.stroke = _stroke); }

    update() { 
        // we first must make a frame to contain all the points, including some margin for the arrowheads
        let [xmin, xmax] = minmax(this.ox, this.dx), [ymin, ymax] = minmax(this.oy, this.dy);
        const arrow_head_size = 8; // {?} TO BE MOVED SOMEWHERE
        [xmin, xmax, ymin, ymax] = [xmin - arrow_head_size, xmax + arrow_head_size, ymin - arrow_head_size, ymax + arrow_head_size]; // add margin for arrow head
        [this.x, this.y] = [xmin, ymin]; 
        [this.w, this.h] = [Math.max(xmax - xmin, 1), Math.max(ymax - ymin, 1)];
        const [ocx, ocy, dcx, dcy] = [this.ox - xmin, this.oy - ymin, this.dx - xmin, this.dy - ymin]; // centered points in the local frame
        const [mcx, mcy] = [(ocx + dcx) / 2, (ocy + dcy) / 2];
        if (this.orientation == 'vertical') { // mostly vertical arrow {?} TO CLEAN UP
            [this.lines[0].x1, this.lines[0].y1] = [ocx, ocy];
            [this.lines[0].x2, this.lines[0].y2] = [ocx, mcy];
            [this.lines[1].x1, this.lines[1].y1] = [ocx, mcy];
            [this.lines[1].x2, this.lines[1].y2] = [dcx, mcy];
            [this.lines[2].x1, this.lines[2].y1] = [dcx, mcy];
            [this.lines[2].x2, this.lines[2].y2] = [dcx, dcy];
        }
        else if (this.orientation == 'horizontal') { // mostly horizontal arrow {?} TO CLEAN UP
            [this.lines[0].x1, this.lines[0].y1] = [ocx, ocy];
            [this.lines[0].x2, this.lines[0].y2] = [mcx, ocy];
            [this.lines[1].x1, this.lines[1].y1] = [mcx, ocy];
            [this.lines[1].x2, this.lines[1].y2] = [mcx, dcy];
            [this.lines[2].x1, this.lines[2].y1] = [mcx, dcy];
            [this.lines[2].x2, this.lines[2].y2] = [dcx, dcy];
        }

        const [vx, vy] = [Math.sign(dcx - mcx), Math.sign(dcy - mcy)]; // The 'velocity' with which the arrow arrives

        // {?} TO CLEAN UP
        if (this.orientation == 'vertical') {
            [this.lines[3].x1, this.lines[3].y1] = [dcx, dcy];
            [this.lines[3].x2, this.lines[3].y2] = [dcx - arrow_head_size, dcy - vy * arrow_head_size];
            [this.lines[4].x1, this.lines[4].y1] = [dcx, dcy];
            [this.lines[4].x2, this.lines[4].y2] = [dcx + arrow_head_size, dcy - vy * arrow_head_size]; 
        }
        else if (this.orientation == 'horizontal') {
            [this.lines[3].x1, this.lines[3].y1] = [dcx, dcy];
            [this.lines[3].x2, this.lines[3].y2] = [dcx - vx * arrow_head_size, dcy + arrow_head_size];
            [this.lines[4].x1, this.lines[4].y1] = [dcx, dcy];
            [this.lines[4].x2, this.lines[4].y2] = [dcx - vx * arrow_head_size, dcy - arrow_head_size];
        }
    }

    update_intermediate_points() { } // {?} For later
}

class SmartGrid extends Svg {
    constructor({ spacing, stroke_color }, parent_elem=undefined) {
        const [w, h] = [width(), height()]; // {?} should be careful with the zoom level
        super({ w, h }, parent_elem);
        [this.spacing, this.stroke_color] = [spacing, stroke_color];
        this.z_index = -512;
        this.svg_node.style.position = 'absolute';
        [this.vert_lines, this.hor_lines] = [[], []];
        [this.max_num_vert_lines, this.max_num_hor_lines] = [8 * Math.ceil(w / spacing), 8 * Math.ceil(h / spacing)];
        for (let i = 0; i < this.max_num_vert_lines; i++) this.vert_lines.push(this.add_new_line(0, 0, 0, 0, stroke_color));
        for (let i = 0; i < this.max_num_hor_lines; i++) this.hor_lines.push(this.add_new_line(0, 0, 0, 0, stroke_color));
    }

    update_grid(obs_soft_pos, screen_size_dict) {
        const { w, h } = eco.screen_size_dict, { x: obs_soft_x, y: obs_soft_y } = obs_soft_pos, spacing = this.spacing; // {?} should be careful with the zoom level
        let x = signed_mod(-obs_soft_x, spacing), y = signed_mod(-obs_soft_y, spacing);
        let [num_visible_vert_lines, num_visible_hor_lines] = [Math.min(Math.ceil(w / spacing), this.max_num_vert_lines), Math.min(Math.ceil(h / spacing), this.max_num_hor_lines)];
        for (let i = 0; i < num_visible_vert_lines; i++) { this.vert_lines[i].x1 = this.vert_lines[i].x2 = x; this.vert_lines[i].y2 = h; x += spacing; }
        for (let i = num_visible_vert_lines; i < this.max_num_vert_lines; i++) { this.vert_lines[i].x1 = 0; this.vert_lines[i].x2 = 0; }
        for (let i = 0; i < num_visible_hor_lines; i++) { this.hor_lines[i].y1 = y; this.hor_lines[i].y2 = y; this.hor_lines[i].x2 = w; y += spacing; }
        for (let i = num_visible_hor_lines; i < this.max_num_hor_lines; i++) this.hor_lines[i].y1 = this.hor_lines[i].y2 = 0;
        
    }
}
