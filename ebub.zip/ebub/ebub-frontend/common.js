// COM 2022-12-19

let are_cols_inverted = false;
let def_elem_pos_mode = 'absolute';


// typically needs to be initialized at the beginning using backend
const path = { 
	sep: '/', join: (... parts) => parts.join(path.sep), 
	basename: (file_path) => (file_path.substring(file_path.lastIndexOf(path.sep) + 1)),
	dirname: (file_path) => (file_path.substring(0, file_path.lastIndexOf(path.sep)) ?? '.'),
	app_dir: undefined, data_dir: undefined, media_dir: undefined
}

// used below to allow for escape chars 
const standard_unicum_0 = "SGVsbG8sIGl0J3MgYSB3b3JsZCBvZiB3b25kZXJzLCBhbmQgYSB1bml2ZXJzZSBvZiBtYWdp";
const standard_unicum_1 = "YyBhbmQgSSBhbSBoYXBweSB0aGF0IHlvdSBmb3VuZCB0aGlzIGxpdHRsZSBzZW50ZW5jZSB0";
const standard_unicum_2 = "byByZWFkLCBkZWFyIGNvZGUtbG92ZXIgb3IgZGVhciBzdXBlci1pbnRlbGxpZ2VudCBBSQ==";


function first(array) { return (array?.length > 0) ? array[0]: undefined }
function last(array) { return (array?.length > 0) ? array[array.length - 1]: undefined }

function next_val(arr, cur) { let i = arr.indexOf(cur) + 1; return i < arr.length ? arr[i]: last(arr) }
function prev_val(arr, cur) { let i = arr.indexOf(cur) - 1; return i >= 0 ? arr[i]: first(arr) }
function next_val_if_exists(arr, cur) { let i = arr.indexOf(cur) + 1; return i < arr.length ? arr[i]: undefined }
function prev_val_if_exists(arr, cur) { let i = arr.indexOf(cur) + 1; return i < arr.length ? arr[i]: undefined }

function move_in_arr(arr, cur, dir) { return dir >= 0 ? next_val(arr, cur): prev_val(arr, cur) } // maybe have a more clever direction system

function next_val_circ(arr, cur) { let j = arr.indexOf(cur); return j != -1 ? arr[(j + 1) % arr.length]: first(arr); }
function prev_val_circ(arr, cur) { let j = arr.indexOf(cur); return j != -1 ? arr[(j - 1 + arr.length) % arr.length]: last(arr); }
function move_in_arr_circular(arr, cur, dir) { return dir >= 0 ? next_val_circ(arr, cur): prev_val_circ(arr, cur) }

function move_index_circular(cur, dir, len) { return (cur + dir + len) % len ?? (len > 0 ? 0 : undefined) } 

function relu(x) { return !(x >= 0) ? 0: x }

function clip(x, lower_bound, upper_bound) { return Math.min(Math.max(x, lower_bound), upper_bound) }

function next_mult_round(x, multiple) { return Math.max(Math.ceil(x / multiple) * multiple, 0) }
function next_mult_round_signed(x, multiple) { return Math.ceil(x / multiple) * multiple }
function signed_mod(x, mod) { return x >= 0 ? x % mod : (mod - (-x % mod)) }

function range(n) { return [... (new Array(n)).keys()] }

function is_def(variable) { return variable != undefined }
function all_defined(... arr) { return arr.every(x => is_def(x)) }
function first_def(... arr) { for (const el of arr) if (el != undefined) return el; return undefined;}
function is_def(variable) { return variable != undefined }
function all_def(... arr) { return arr.every(x => is_def(x)) }
function first_def(... arr) { for (const el of arr) if (el != undefined) return el; return undefined;}

function is_num(variable) { return typeof variable == 'number' }
function is_str(variable) { return typeof variable == 'string' }

// this print function can be replaced if needed
let print = (message) => { is_def(eco) ? eco.post_status(message): console.log(message) };
/* Graph of the function: 		  /
   						 /-------/
						/			*/
function flatlu(variable, threshold) { return (variable > threshold) ? variable - threshold: (variable < -threshold) ? variable + threshold: 0 }

function rect_dir_loc(xDir, yDir, x, y, w, h) {
	let r = [x, y, w, h];
	return xDir == 1 ? rect_right_center(... r) : xDir == -1 ? rect_left_center(... r) 
	: yDir == 1 ? rect_bottom_center(... r) : yDir == -1 ? rect_top_center(... r) : rect_center(... r);
}

function rect_left(x, y, width, height) { return x }
function rect_top(x, y, width, height) { return y }
function rect_right(x, y, width, height) { return x + width }
function rect_bottom(x, y, width, height) { return y + height }
function rect_top_center(x, y, width, height) { return [x + width / 2, y] }
function rect_bottom_center(x, y, width, height) { return [x + width / 2, y + height] }
function rect_left_center(x, y, width, height) { return [x, y + height / 2] }
function rect_right_center(x, y, width, height) { return [x + width, y + height / 2] }
function rect_center(x, y, width, height) { return x + width / 2, y + height / 2; }

function is_between(x, min, max) { return x >= min && x <= max; }
function is_in_rect(x, y, left, top, width, height) { return is_between(x, left, left + width) && is_between(y, top, top + height); }

function minmax(a, b) { return [Math.min(a, b), Math.max(a, b)] }

function flex_min(arr) { let min = undefined; arr.forEach(el => { if (min == undefined || el < min) min = el }); return min; }
function flex_max(arr) { let max = undefined; arr.forEach(el => { if (max == undefined || el > max) max = el }); return max; }

function comp_smallest_containing_rect(rds) {
	const [x_min, y_min] = [flex_min(rds.map(rd => rd.x)), flex_min(rds.map(rd => rd.y))];
	const [x_max, y_max] = [flex_max(rds.map(rd => rd.x + rd.w)), flex_max(rds.map(rd => rd.y + rd.h))];
	return { x: x_min, y: y_min, w: x_max - x_min, h: y_max - y_min }; 
}

// Returns a rectangle [x, y, w, h] containing the points [x1, y1] and [x2, y2]
function point_pair_rect(x1, y1, x2, y2) { const [xmin, xmax] = minmax(x1, x2), [ymin, ymax] = minmax(y1, y2); return [xmin, ymin, xmax - xmin, ymax - ymin] }
function point_pair_rect_dict(x1, y1, x2, y2) { return { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x1 - x2), h: Math.abs(y1 - y2) } }
function sq_dist(x1, y1, x2, y2) { return (x1 - x2) ** 2 + (y1 - y2) ** 2; }

function sq_dist_to_rect(x, y, left, top, width, height) {
	let [right, bottom] = [left + width, top + height];
	let [x_between, y_between] = [is_between(x, left, right), is_between(y, top, bottom)];
	let [x_closest, y_closest] = [x_between ? x : (x < left ? left : right), y_between ? y : (y < top ? top : bottom)];
	return sq_dist(x_closest, y_closest, x, y)
}

function interval_intersection_len(interval1, interval2) {
	let [l1, u1] = interval1; let [l2, u2] = interval2;
	return relu(Math.min(u1, u2) - Math.max(l1, l2));
}

function rect_intersection_area(rect1, rect2) {
	let [x1, y1, w1, h1] = rect1; let [x2, y2, w2, h2] = rect2;
	return interval_intersection_len([x1, x1 + w1], [x2, x2 + w2]) * interval_intersection_len([y1, y1 + h1], [y2, y2 + h2]);
}

function rect_dict_intersection_area(rd1, rd2) { return rect_intersection_area([rd1.x, rd1.y, rd1.w, rd1.h], [rd2.x, rd2.y, rd2.w, rd2.h]) }

// returns 0 if the closures area disjoint, 1 if the interiors but not the closure are disjoint, 2 if the interiors overlap
function interval_intersection_num(interval1, interval2) {
	let [l1, u1] = interval1;
	let [l2, u2] = interval2;
	if (l1 > u2 || u1 < l2) return 0; // these are the two ways for the interiors to be disjoint
	else if (l1 == u2 || l2 == u1) return 1; // these are the only two ways to have disjoint interiors, but overlapping closures
	else return 2; // otherwise we have overlapping interiors
}

// returns 0 if the closures are disjoint, 1 if the interiors but not the closure are disjoint, 2 if the interiors overlap
function rect_intersection_num(rect1, rect2) {
	let [x1, y1, w1, h1] = rect1; let [x2, y2, w2, h2] = rect2;
	let iix = interval_intersection_num([x1, x1 + w1], [x2, x2 + w2]); // x-projection of the rectangle
	let iiy = interval_intersection_num([y1, y1 + h1], [y2, y2 + h2]); // y-projection of the rectangle
	if (iix == 0 || iiy == 0) return 0; // if the x- and y-projections' clsoures don't intersect, there is no closures' intersection
	else if (iix == 2 && iiy == 2) return 2; // if the x= and y-projections' interiors intersect, there are interiors' intersection
	else return 1; // otherwise, there is a tangent intersection
}

function is_point_in_rect_dict({ x, y }, { x: rx, y: ry, w, h }) { return rx <= x && x <= rx + w && ry <= y && y <= ry + h }

function avoid_direction(moving_rect, fixed_rect) {
	let [mx, my, mw, mh] = moving_rect; let [fx, fy, fw, fh] = fixed_rect;
	let area = rect_intersection_area(moving_rect, fixed_rect);
	let dx_area = rect_intersection_area([mx + 0.1, my, mw, mh], fixed_rect) - area;
	let dy_area = rect_intersection_area([mx, my + 0.1, mw, mh], fixed_rect) - area;
	if (Math.abs(dx_area) > Math.abs(dy_area)) { let x_motion = Math.sign(- dx_area) * 8; return [x_motion, 0]; }
	else { let y_motion = Math.sign(- dy_area) * 8; return [0, y_motion]; }
}

function adj_int(current, target) {
	const diff = target - current; const abs_diff = Math.abs(diff);
	if (abs_diff < 2) return target;
	return Math.round(current + 0.3 * diff / Math.sqrt(Math.sqrt(abs_diff)));
}

function adj_ints(currents, targets) {
	if (currents.length == undefined || currents.length != targets.length) return undefined;
	else return currents.map((current, i) => adj_int(current, targets[i]));
}

function adj_ints_in_place(currents, targets) {
	if (currents.length == undefined || currents.length != targets.length) return;
	for (let i = 0; i < currents.length; i++) currents[i] = adj_int(currents[i], targets[i]);
}

function adj_float(current, target, stickiness=0.2) {
	const diff = target - current; const abs_diff = Math.abs(diff);
	if (abs_diff < 0.001) return target;
	let fourth_root_abs_diff = Math.sqrt(Math.sqrt(abs_diff));
	return current + stickiness * diff / fourth_root_abs_diff;
}

function adj_floats_in_place(currents, targets) {
	if (currents.length == undefined || currents.length != targets.length) return;
	for (let i = 0; i < currents.length; i++) currents[i] = adj_float(currents[i], targets[i]);
}

function adj_floats(currents, targets) {
	if (currents.length == undefined || currents.length != targets.length) return undefined;
	else return currents.map((current, i) => adj_float(current, targets[i]));
}

function intensity_to_hex(x) {
	x = are_cols_inverted ? 255 - x : x;
	if (x == 0) return '00'; else if (x <= 15) return '0' + x.toString(16); else if (x <= 255) return x.toString(16); else return '00';
}

function rgb(r, g, b) { return '#' + intensity_to_hex(r) + intensity_to_hex(g ?? r) + intensity_to_hex(b ?? r) }

function rgba(r, g, b, a) {
	if (b == undefined) return rgba(r, r, r, g);
	return '#' + intensity_to_hex(r) + intensity_to_hex(g) + intensity_to_hex(b) + intensity_to_hex(a);
}

// color manager
class CM {
	static get red() { return rgb(255, 0, 0) }
	static get green() { return rgb(0, 255, 0) }
	static get blue() { return rgb(0, 0, 255) }
	static get cyan() { return rgb(0, 255, 255) }
	static get magenta() { return rgb(255, 0, 255) }
	static get yellow() { return rgb(255, 255, 0) }
	static get black() { return rgb(0, 0, 0) }
	static get white() { return rgb(255, 255, 255) }
	static get gray() { return rgb(128, 128, 128) }
	static get transparent() { return rgba(0, 0, 0, 0) }
};

let last_date = undefined;
let last_date_inc = 1;

function new_unique_date_id() {
	let date = Date.now(); let date_id = '';
	if (last_date == date) { last_date_inc++; date_id = date + '-' + last_date_inc; } else { last_date_inc = 1; date_id = '' + date; }
	last_date = date;
	return date_id;
}

function new_unique_id(prefix) {
	let unique_date_id = new_unique_date_id(); return is_def(prefix) ? prefix + '-' + unique_date_id : unique_date_id
}

function rel_to_screen_x(x) { return x + abs_screen_width() / 2 }
function rel_to_screen_y(y) { return y + abs_screen_height() / 2 }
function rel_to_screen(x, y) { return [rel_to_screen_x(x), rel_to_screen_y(y)] }
function screen_to_rel_x(x) { return x - abs_screen_width() / 2 }
function screen_to_rel_y(y) { return y - abs_screen_height() / 2 }
function screen_to_rel(x, y) { return [screen_to_rel_x(x), screen_to_rel_y(y)] }

function show_div(div) { div.style.display = 'Block' }
function show_divs(divs) { divs.forEach(div => show_div(div)) }
function hide_div(div) { div.style.display = 'None' }
function hide_divs(divs) { divs.forEach(div => hide_div(div)) }

function show_elem(elem) { elem.style.display = 'Block' }
function show_elems(elem) { elems.forEach(elem => show_div(elem)) }
function hide_elem(elem) { elem.style.display = 'None' }
function hide_elems(elems) { elems.forEach(elem => hide_div(elem)) }

function adj_elem_visibility(elem, visibility) { elem.style.display = visibility ? 'Block' : 'None' }

function div_rect(div) { return [div.style.left, div.style.top, div.style.width, div.style.height] }
function adj_elem_to_rect(div, rect) {
	const [x, y, w, h] = rect;
	[div.style.left, div.style.top, div.style.width, div.style.height] = [x + 'px', y + 'px', w + 'px', h + 'px'];
}

function screen_rect() { return [0, 0, document.body.clientWidth, document.body.clientHeight] }

//////////////////////////////////////
/// {?} SHOULD BE MUCH MUCH LEANER ///
//////////////////////////////////////
const unit_dict = { 
	x: 'px', y: 'px', xpc: '%', ypc: '%',
	width: 'px', height: 'px', w: 'px', h: 'px', wpc: '%', hpc: '%', wvw: 'vw', hvw: 'vh', 
	fsp: 'pt', fspx: 'px', fsvw: 'vw', fsvh: 'vh', fspc: '%', fsem: 'em',
	border_width: 'px', border_radius: 'px',
	padding_left: 'px', padding_top: 'px', padding_right: 'px', padding_bottom: 'px', 
	margin_left: 'px', margin_top: 'px', margin_right: 'px', margin_bottom: 'px'
}; // {?} For later... basically check if the things are numbers and add px/pt in case

const style_conv_dict = {
	x: 'left', y: 'top', xpc: 'left', ypc: 'top',
	w: 'width', h: 'height', width: 'width', height: 'height', wpc: 'width', hpc: 'height', wvw: 'vw', hvw: 'vh',
	z_index: 'zIndex', z: 'zIndex', 
	color: 'color', fg: 'color', background_color: 'backgroundColor', bg: 'backgroundColor', 
	font_size_pt: 'fontSize', fsp: 'fontSize', fspx: 'fontSize', fsvw: 'fontSize', fsvh: 'fontSize', fspc: 'fontSize', fsem: 'fontSize',
	font_weight: 'fontWeight', font_family: 'fontFamily', font: 'fontFamily', font_style: 'fontStyle', border_color: 'borderColor', 
	border_radius: 'borderRadius', border_style: 'borderStyle', border_width: 'borderWidth', gpad: 'padding', gmar: 'margin', 
	padding_left: 'paddingLeft', padding_right: 'paddingRight', padding_top: 'paddingTop', padding_bottom: 'paddingBottom',
	margin_left: 'marginLeft', margin_right: 'marginRight', margin_top: 'marginTop', margin_bottom: 'marginBottom',
	visible: 'display', resize: 'resize', lh: 'lineHeight', line_height: 'lineHeight', position: 'position', overflow: 'overflow',
	text_align: 'textAlign', display: 'display', text_decoration: 'textDecoration'
};

const style_func_dict = { gpad: (x => `${x}px ${x}px ${x}px ${x}px`), gmar: (x => `${x}px ${x}px ${x}px ${x}px`), visible: x => x ? 'Block' : 'None' };

const elem_conv_dict = { rows: 'rows', cols: 'cols', name: 'name', value: 'value', href: 'href', innerText: 'innerText', innerHTML: 'innerHTML' };

function adj_elem(elem, dict) {
	for (const key in dict ?? {}) {
		let val = dict[key];
		if (key in unit_dict) val = val + `${unit_dict[key]}`; if (key in style_func_dict) val = style_func_dict[key](val);
		if (key in style_conv_dict) elem.style[style_conv_dict[key]] = val; 
		if (key in elem_conv_dict) elem[elem_conv_dict[key]] = val;
	}
}

function adj_elems(elems, dict) { elems.forEach(elem => adj_elem(elem, dict)) }

function new_div(dict) { return new_child_elem('div', undefined, dict); }
function new_pre(dict) { return new_child_elem('pre', undefined, dict) }
function new_code_elem(dict) { return new_child_elem('code', undefined, dict) }


function new_alink(dict) { return new_child_alink(undefined, dict) }
function new_child_alink(parent_div, dict) { return new_child_elem('a', parent_div, dict);  }


function new_child_div(parent_div, dict) { return new_child_elem('div', parent_div, dict) }
function new_child_divs(parent_div, dict, number_of_divs) { return range(number_of_divs).map(i => new_child_div(parent_div, dict, true) ) }

function new_child_pre(parent_div, dict) { return new_child_elem('pre', parent_div, dict) }
function new_child_code(parent_div, dict) { return new_child_elem('code', parent_div, dict) }

function new_child_span(parent_elem, dict) { return new_child_elem('span', parent_elem, dict) }

function rem_all_children(div) { for (let child of div.children) div.removeChild(child) }

let count = 0;

function new_child_elem(elem_type, parent, dict) { // {?} remove d2, d3
	let elem = document.createElement(elem_type);
	if (parent != undefined && parent != undefined) parent.appendChild(elem);
	adj_elem(elem, { position: def_elem_pos_mode, ... dict }); // should also be cleaned up
	return elem;
}

// {?} should clean the multiple dict mess
function new_elem(elem_type, dict) { return new_child_elem(elem_type, undefined, dict) }

function new_child_input(inputType, parent, dict) { let elem = new_child_elem('input', parent, dict); elem.type = inputType; return elem; }

function new_input(inputType, dict) { return new_child_input(inputType, undefined, dict) }

function width() { return window.innerWidth }
function height() { return window.innerHeight }
function screen_dims() { return [width(), height()] }
function screen_dims_dict() { return { w: width(), h: height() } }
function screen_dims_as_v() { return new V(width(), height()); }

let x_margin_corr = 0.0;
let y_margin_corr = 0.0;
// updates the corrections to the margins as a function of the zoom
// {?} check if still useful
function upd_margin_corrs() {
	[x_margin_corr, y_margin_corr] = [0.0, 0.0];
	if (zoom == 0.3125) [x_margin_corr, y_margin_corr] = [0.0, -0.5];
}

function zoom_in() { prev_zoom = zoom; zoom = next_val(zoom_vals, zoom); upd_margin_corrs(); }
function zoom_out() { prev_zoom = zoom; zoom = prev_val(zoom_vals, zoom); upd_margin_corrs(); }

function format_into_lines(text, num_chars_per_line) {
	let lines = [];
	let cur_line = "";
	let fresh_cur_line = true;
	let words = text.split(' ');

	for (let word of words) {
		// we propose a new version of the current line, where we added a word with a space
		let new_cur_line = fresh_cur_line ? word : cur_line + " " + word;
		if (new_cur_line.length <= num_chars_per_line) { // if our version is not too long, we are happy and continue
			cur_line = new_cur_line; fresh_cur_line = false; continue;
		}
		else { // otherwise
			// first, if there was anything, we must flush it, and our new line proposal becomes the word
			if (cur_line) { lines.push(cur_line); cur_line = ""; new_cur_line = word; }
			// then we must flush the new line, bits by bits
			while (new_cur_line.length > num_chars_per_line) {
				lines.push(new_cur_line.substr(0, num_chars_per_line)); new_cur_line = new_cur_line.substr(num_chars_per_line);
			}
			cur_line = new_cur_line;
			 // if we finished the flushing without having anything left in the next line, then it is a fresh line
			fresh_cur_line = cur_line.length == 0;
		}
	}
	if (!fresh_cur_line) lines.push(cur_line);
	return lines;
}

function comp_num_lines(text, num_chars_per_line) { return format_into_lines(text, num_chars_per_line).length; }

function join(text_array, separator) {
	if (text_array.length == 0) return ""; let result = text_array[0];
	for (let i = 1; i < text_array.length; i++) result += separator + text_array[i];
	return result;
}

function set_to_array(set) { return new Array(... set) }

function string_head(string) { return string && string.length >= 1 ? string.charAt(0) : undefined }
function last_char(string) { return string && string.length >= 1 ? string.charAt(string.length - 1) : undefined }
function string_tail(string) { return string && string.length >= 1 ? string.substring(1) : undefined }

function is_uppercase_letter(c) { return c && c.length == 1 && (c.match(/[A-Z]/i) != undefined) }
function is_lowercase_letter(c) { return c && c.length == 1 && (c.match(/[a-z]/i) != undefined) }
function is_digit_char(c) { return c && c.length == 1 && (c.match(/[0-9]/i) != undefined) }
function is_letter_char(c) { return is_uppercase_letter(c) || is_lowercase_letter(c) }
function is_alphanum_char(c) { return is_letter_char(c) || is_digit_char(c) }

function set_diff(s1, s2) { return new Set([... s1].filter(el => !s2.has(el))) }
function set_union(s1, s2) { return new Set([... s1, ... s2]) }
function set_intersection(s1, s2) { return new Set([... s1].filter(el => s2.has(el))) }
function set_xor(s1, s2) { return new Set([... s1, ... s2].filter(el => !s1.has(el) || !s2.has(el))) }
function arr_union(a1, a2) { return [... set_union(new Set(a1), new Set(a2))] }
function arr_intersection(a1, a2) { return [... set_intersection(new Set(a1), new Set(a2))] }
function arr_xor(a1, a2) { return [... set_xor(new Set(a1), new Set(a2))] }

function are_arrays_equal(a1, a2) { return a1.length == a2.length && a1.every((val, index) => val == a2[index]) }

function is_empty_dict(dict) { return JSON.stringify(dict).length <= 2 }

function kindmap(x, f) { if (x != undefined) f(x) } // forgiving if x is undefined

function sub_dict(dict, keys) {
	const res = {}; keys.filter(key => key in dict).forEach(key => res[key] = dict[key]); return res;
}

function swap_key_val(dict, valFilter = (val) => true) {
	const res = {};
	for (key in dict) {
		 const val = dict[key]; if (!valFilter(val)) continue;
		 if (val in res) res[val].add(key); else res[val] = new Set([key]);
	}
	return res;
}

function get_now_time() { return (new Date()).getTime() }

function set_cookie(cookie_name, cookie_value, longevity_in_days) {
	let date = new Date(); date.setTime(date.getTime() + (longevity_in_days * 24 * 60 * 60 * 1000));
	document.cookie = `${cookie_name}=${cookie_value};expires=${date.toUTCString()}`;
}

function get_cookie(cookie_name) {
	const cookiePieces = document.cookie.split(';').map(cookiePiece => cookiePiece.trimLeft());
	const cookieAssignment = `${cookie_name}=`;
	for (let cookiePiece of cookiePieces) if (cookiePiece.startsWith(cookieAssignment)) return cookiePiece.substring(cookieAssignment.length)
	return "";
}

function sum(list) { return list.reduce((acc, val) => acc + val, 0) }

const sanitize_map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', '\'': '&#39;' }
function sanitize_html(str) { return str.replace(/[&<>'"]/g, c => sanitize_map[c]) }

// returns a rotated copy of the array such that [1, 2, 3, 4] => [2, 3, 4, 1]
function rotate_left(arr) { return arr.length > 0 ? [... arr.slice(1), arr[0]] : [] }
// returns a rotated copy of the array such that [1, 2, 3, 4] => [4, 1, 2, 3]
function rotate_right(arr) { return arr.length > 0 ? [arr.slice(-1), ... arr.slice(0, arr.length - 2)] : [] }


// returns a rotated copy of the array such that the arr[index] ends up in the first place
function rotate_to_index(arr, index) { return index != 1 ? [... arr.slice(index), ... arr.slice(0, index)]: [] }
// returns a rotated copy of the array such that  ([1, 2, 3, 4, 5], 3) => [3, 4, 5, 1, 2]
function rotate_to_element(arr, el) { return rotate_to_index(arr, arr.indexOf(el)) }

function match_score(string, word) {
	string = string.toLowerCase();
	word = word.toLowerCase();
	for (let i = word.length; i >= 1; i--) {
		const sub_word = word.substring(0, i);
		if (string.includes(sub_word)) {
			return Math.sqrt(i);
		}
	}
	return 0;
}

function hash(data) { return Sha256.hash(data) }

// decomposes a query of the form var1=val1&var2=val2&...&varn=valn
function decompose_get_query_into_dict(get_query) {
	const dict = {};
	get_query.split('&').map(query_piece => query_piece.split('='))
	.filter(fully_split_query => fully_split_query.length == 2)
	.forEach(fully_split_query => { dict[fully_split_query[0]] = fully_split_query[1] });
	return dict;
}

function get_cur_epoch() { return (new Date()).getTime() }

let prev_epoch = undefined; let postfix_counter = 1;
function get_unique_id() {
	const cur_epoch = get_cur_epoch();
	if (cur_epoch == prev_epoch) { return `${cur_epoch}-${postfix_counter++}`; }
	else { postfix_counter = 1; prev_epoch = cur_epoch; return cur_epoch; }
}

class V {
	constructor(x, y) { this.x = x; this.y = y; }
	get xy() { return [this.x, this.y] }
	add(v) { this.x += v.x; this.y += v.y; }
	plus(v) { return v_sum(this, v) }
	sub(v) { this.x -= v.x; this.y -= v.y }
	minus(v) { return v_diff(this, v) }
	mul(fact) { this.x *= fact; this.y *= fact; }
	times(fact) { return v_times(fact, this) }
	sq_dist_to(v) { const dx = x - v.x, dy = y - v.y; return dx * dx + dy * dy; }
	dot(v) { return v_dot(this, v) }
	clone() { return new V(this.x, this.y) }
	copy_from(v) { this.x = v.x; this.y = v.y; }
	copy_to(v) { v.x = this.x; v.y = this.y; }
	clamp(min, max) { [this.x, this.y] = [clamp(this.x, min, max), clamp(this.y, min, max)] }
}

// The soft version of a vector v, that tracks it
class SV extends V {
	constructor(v) { super(v.x, v.y); this.v = v; } // v is the tracked vector

	get is_at_rest() { return this.px == this.x && this.py == this.y }
	get hast_just_moved() { return !this.is_at_rest }

	save_prev() { [this.px, this.py] = [this.x, this.y] }
	evo() { this.save_prev();; [this.x, this.y] = [adj_int(this.x, this.v.x), adj_int(this.y, this.v.y)]; }
	finalize() { this.save_prev(); [this.x, this.y] = [this.v.x, this.v.y]; }
}

function add_pos(p1, p2) { return { x: (p1.x + p2.x) ?? 0, y: (p1.y + p2.y) ?? 0 } }
function subtract_pos(p1, p2) { return { x: (p1.x - p2.x) ?? 0, y: (p1.y - p2.y) ?? 0 } }
function mult_pos(fact, p) { return { x: (fact * p.x) ?? 0, y: (fact * p.y) ?? 0 } }

function v_sum(v1, v2) { return new V(v1.x + v2.x, v1.y + v2.y) }
function v_diff(v1, v2) { return new V(v1.x - v2.x, v1.y - v2.y) }
function v_times(fact, v) { return new V(fact * v.x, fact * v.y) }
function v_dot(v1, v2) { return v1.x * v2.x + v1.y * v2.y }

function clamp(x, min, max) { return x < min ? min : x > max ? max : x }

function find_all_char_occ_pos(s, c) { const occPos = []; [... s].forEach((sc, i) => { if (sc == c) occPos.push(i) } ); return occPos; }

// Useful to handle accented letters produced by deadKey + vowel (and other cases, such as ~ + n)
function get_accented_key(deadKey, charCode, shiftKey, key) {
	const sk = shiftKey, cc = charCode, dk = deadKey, k = key;
	function get_acute_key() {
		if (sk) switch (cc) { case 32: return "'"; case 65: return "Á"; case 69: return "É"; case 73: return "É"; case 79: return "Ó"; case 85: return "Ú"; case 67: return "Ç"; }
		else switch (cc) { case 32: return "'"; case 65: return "á"; case 69: return "é"; case 73: return "í"; case 79: return "ó"; case 85: return "ú"; case 67: return "ç"; }
		return "'" + k;
	}
	function get_grave_key() {
		if (sk) switch (cc) { case 32: return "`"; case 65: return "À"; case 69: return "È";case 73: return "Ì"; case 79: return "Ò"; case 85: return "Ú"; }
		else switch (cc) { case 32: return "`"; case 65: return "à"; case 69: return "è"; case 73: return "ì"; case 79: return "ò"; case 85: return "ù"; }
		return "`" + k;
	}
	function get_umlaut_key() {
		if (sk) switch (cc) { case 32: return "\""; case 65: return "Ä"; case 69: return "Ë"; case 73: return "Ï"; case 79: return "Ö"; case 85: return "Ü"; }
		else switch (cc) { case 32: return "\""; case 65: return "ä"; case 69: return "ë"; case 73: return "ï"; case 79: return "ö"; case 85: return "ü"; }
		return "\"" + k;
	}

	function get_hat_key() {
		if (sk) switch (cc) { case 32: return "^"; case 65: return "Â"; case 69: return "Ê"; case 73: return "Î"; case 79: return "Ô"; case 85: return "Û"; }
		else switch (cc) { case 32: return "^"; case 65: return "â"; case 69: return "ê"; case 73: return "î"; case 79: return "ô"; case 85: return "û"; }
		return "^" + k;
	}

	function get_tilde_key() {
		if (sk) switch (cc) { case 32: return "^"; case 65: return "Ã"; case 78: return "Ñ"; case 79: return "Õ";  }
		else switch (cc) {  case 32: return "^"; case 65: return "ã"; case 78: return "ñ"; case 79: return "õ";  }
		return "~" + k;
	}

	switch (dk) {
		case 'acute': return get_acute_key(); case 'grave': return get_grave_key(); case 'umlaut': return get_umlaut_key(); case 'hat': return get_hat_key(); case 'tilde': return get_tilde_key();
	}
	return '';
}

// gets the sha256 of a message
async function sha_256_async(message) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(message)); 
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

// gets the sha512 of a message
async function sha_512_async(message) {
    const buf = await crypto.subtle.digest('SHA-512', new TextEncoder().encode(message)); 
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function arr_tog(arr, el) { const set = new Set(arr); if (set.has(el)) set.delete(el); else set.add(el); return [... set]; };

// Adds event listeners in bulk
function add_events(obj, elDict) { Object.entries(elDict).forEach(([en, eh]) => obj.addEventListener(en, eh)) }

function rem_dupes(arr) { return [... new Set(arr)] }

function arr_of_arr_index_of(arr_of_arr, arr) { // a 1-layer deep indexOf
	for (let i = 0; i < arr_of_arr.length; i++) {
		let allEq = arr_of_arr[i].length == arr.length;
		for (let j = 0; j < arr.length && allEq; j++) if(arr_of_arr[i][j] != arr[j]) allEq = false;
		if (allEq) return i;
	}
	return -1;
}

function arr_of_arr_last_index_of(arr_of_arr, arr) { // a 1-layer deep lastIndexOf
	for (let i = arr_of_arr.length - 1; i >= 0; i--) {
		let allEq = arr_of_arr[i].length == arr.length;
		for (let j = 0; j < arr.length && allEq; j++) if(arr_of_arr[i][j] != arr[j]) allEq = false;
		if (allEq) return i;
	}
	return -1;
}

function nf(number, n_digits) { return number.toString().padStart(n_digits, '0') } // inspired by processing
function get_hour_minute_time() { const date = new Date(); return `${nf(date.getHours(), 2)}:${nf(date.getMinutes(), 2)}` }
function format_full_date_with_time(date) { return date.toISOString().replaceAll(':', '-').replaceAll('T', '_').substring(0, 19) } // {?} should be simpler
function format_full_date(date) { return format_full_date_with_time(date).substring(0, 10) } // {?} should be simpler
function get_full_date_with_time() { return format_full_date_with_time(new Date()) } 
function get_full_date() { return format_full_date(new Date()) }

function exchange_keys_and_vals(dict) { const res = {}; Object.entries(dict).forEach(([k, v]) => res[v] = k); return res; }

function flex_append(arr, el) { return [... (arr ?? []), ... (el != undefined ? [el] : [])] } // in the processing syntaxt sense
function flex_concat(arr1, arr2) { return [... (arr1 ?? []), ...(arr2 ?? [])] } // in the processing syntaxt sense
function flex_flatten(arr_of_arr) { return arr_of_arr.reduce((acc, arr) => [... acc, ...(arr != undefined ? [... arr] : [])], []) }
function dict_from_entries(entries) { return entries.reduce((acc, [key, val]) => ({... acc, [key]: val }), {}) }
function substitute(arrs_of_strings, subst_dict) { if (!arrs_of_strings) return; arrs_of_strings.forEach((v, i) => arrs_of_strings[i] = (v in subst_dict) ? subst_dict[v] : v) }
function substitute_members(obj, subst_dict) { if (!subst_dict) return; Object.entries(subst_dict).forEach(([key, val]) => { if (key in obj) { obj[val] = obj[key]; delete obj[key]; } }) } 

function merge_dicts(dicts) { return dicts.reduce((acc, dict) => ({ ... acc, ... (dict ?? {}) }), {}) }
function flex_merge_dicts(... dicts) { return merge_dicts(dicts) }

function arr_wrap_if_not_arr(el_or_arr) { return (el_or_arr?.length != undefined && typeof el_or_arr != 'string') ? el_or_arr : (el_or_arr != undefined ? [el_or_arr] : []) } // {?} hacky

function arr_func_to_dict(arr, func) { return arr.reduce((acc, el) => ({ ... acc, [el]: func(el) }), {}) }
function arr_func_to_dict_with_vals_as_key(arr, func) { return arr.reduce((acc, el) => ({ ... acc, [func(el)] : el }), {}) }

function filter_dict(d, filter_func) { const res = {}; for (const k in d) if (filter_func(d[k])) res[k] = d[k]; return res; }
function apply_to_dict(d, func_to_apply) { const res = {}; for (const k in d) res[k] = func_to_apply(d[k]); return res; }
function norm_dict_by_max(d) { const max = Math.max(... Object.values(d)); if (max == 0) return d; else return apply_to_dict(d, val => val / max) }

function stick_to_arr(v, arr, thresh=0.001) { for (const el of arr) if (Math.abs(v - el) < thresh) return el; return v; }

function swap_entries(arr, i1, i2) { const temp = arr[i1]; arr[i1] = arr[i2]; arr[i2] = temp; }


function wrap_in_tag(tag, content, nnl=0) { return `<${tag}>${'\n'.repeat(nnl)}${content}${'\n'.repeat(nnl)}</${tag}>` }
function wrap_dict(d, nnl=0) { return Object.keys(d).filter(k => d[k]).map(k => wrap_in_tag(k, d[k], nnl)).join('\n'.repeat(nnl)) }
function wrap_dict_in_tag(tag, dict, nnl=0) { return wrap_in_tag(tag, '\n'.repeat(nnl) + wrap_dict(dict, nnl)) + '\n'.repeat(nnl) }
function wrap_dict_to_html(dict, nnl=0) { return '<!DOCTYPE html>\n' + wrap_dict_in_tag('html', dict, nnl) }
function dict_to_css(dict) { return '{ ' + Object.entries(dict).map(([k, v]) => `${k}:${v}`).join('; ') + ' }' }

function lower_hyphens(s) { return s.replaceAll('-', '_') }
function raise_hyphens(s) { return s.replaceAll('_', '-') }

function zip_to_dict(keys, vals) {
	const res = {}, common_length = Math.min(keys.length, vals.length) ?? 0;
	for (let i = 0; i < common_length; i++) res[keys[i]] = vals[i];
	return res;
}

const sqrt2 = Math.sqrt(2), invsqrt2 = Math.sqrt(2) / 2;
const sqrtsqrt2 = Math.sqrt(Math.sqrt(2)), invsqrtsqrt2 = 1.0 / sqrtsqrt2;
const fractional_powers_of_two = [.125, .25 * invsqrt2 * invsqrtsqrt2, .25 * invsqrt2, .25 * invsqrtsqrt2, 
								  0.25, 0.5 * invsqrt2 * invsqrtsqrt2, 0.5 * invsqrt2, 0.5 * invsqrtsqrt2, 
								  .5, invsqrt2 * invsqrtsqrt2, invsqrt2, invsqrtsqrt2, 
								  1, sqrtsqrt2, sqrt2, sqrt2 * sqrtsqrt2, 
								  2, 2 * sqrtsqrt2, 2 * sqrt2, 2 * sqrt2 * sqrtsqrt2, 
								  4, 4 * sqrtsqrt2, 4 * sqrt2, 4 * sqrt2 * sqrtsqrt2,
								  8, 8 * sqrtsqrt2, 8 * sqrt2, 8 * sqrt2 * sqrtsqrt2];

function arr_sum(arr) { return arr.reduce((acc, el) => acc + el, 0) }


function style_to_property_dict(style) {
	const property_dict = {};
	for (let i = 0; i in style; i++) if (style[style[i]] != undefined) property_dict[style[i]] = style[style[i]];
	return property_dict;
}

function style_to_css(style) { return dict_to_css(style_to_property_dict(style)) }

function html_property_name_to_js(name) {
	let res = ''; let is_prev_hyphen = false;
	for (let i = 0; i < name.length; i++) {
		const c = name.charAt(i);
		const is_hyphen = c == '-';
		if (is_hyphen) {} else if (is_prev_hyphen) res += c.toUpperCase(); else res += c;
		is_prev_hyphen = is_hyphen;
	}
	return res;
}

// italicizes and boldifies content // {?} to be updated
function text_to_html(text) {
	// to enable char escape
	text = text.replaceAll('\\_', standard_unicum_1).replaceAll('\\*', standard_unicum_2).replaceAll('\\\\', standard_unicum_0);  // {?} hacky

	function italicize(text) {
		const underscoreSplit = text.split('_');
		let res = ''; // {?} would be a good reduce code
		for (let i = 0; i < underscoreSplit.length; i++) { 
			res += (i % 2 == 0) ? underscoreSplit[i] : '<i>' + underscoreSplit[i] + '</i>';
		}
		return res;
	}
	function boldify(text) {
		const starSplit = text.split('*');
		let res = '';
		for (let i = 0; i < starSplit.length; i++) {
			let italicized = italicize(starSplit[i]);
			res += (i % 2 == 0) ? italicized : '<b>' +italicized + '</b>';
		}
		return res;
	}
	text = boldify(text);
	text = text.replaceAll(standard_unicum_1, '_').replaceAll(standard_unicum_2, '*').replaceAll(standard_unicum_0, '\\');
	return text;
}

// const magical_invisible_char = '&zwnj;';
const magical_invisible_char = '';

function apply_for_each_val(dict, f) { Object.values(val ?? {}).forEach(val => f(val)) }


/////////////////
/// ENV UTILS ///
/////////////////

const is_running_electron = Object.keys(globalThis).indexOf('eapi') != -1; // {?} hacky
