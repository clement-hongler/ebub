///////////////////////////////////////////////////
/// External world (including the display, etc) ///
///////////////////////////////////////////////////

class Ewo {
    constructor(eco, dict) {
        this.eco = eco;
        this.is_initialized = false; // to prevent the setter functions to refresh prematurely
        this.is_xewo = false;
        this.init_div(); // initializes the div in which the external world will be displayed
        this.init(dict);
        this.show_all = true; // typically disabled for performance reasons, but can be enabled in case {?} re-enabled because of weird bug
        this.show_ewo_name = true;
    }

    init(dict) {
        this.wid ??= dict?.wid; // necessary for the registering (though redundant with the rest)
        this.register_in_eco();
        this.init_obs();
        this.ebus_by_bid = {};
        this.elis_by_lid = {};
        this.fade_by_bid = {}; // how much we fade ebubles and links
        [this.lids_by_oribid, this.lids_by_desbid] = [{}, {}]; // for search // {?} Perhaps better placed in the eco, like other things
        this.baw = new Baw(this, {}); // the background world
        if (dict) this.from_dict(dict);
    }

    // {?} Hacky but better than the alternatives at the moment; overloaded in the xewo
    register_in_eco() { 
        if (this.wid != undefined) {
            if (!this.is_xewo) this.eco.ewos_by_wid[this.wid] = this; // i.e. we are a 'regular' ewo, not an exchange ewo
            if (this.is_xewo && eco.is_xeco) this.eco.xewos_by_wid[this.wid] = this; 
        }
    } 

    init_div() {
        const { w, h } = this.screen_size_dict;

        this.div = new_div({ bg: '#000000', wpc: 100, hpc: 100 });

        this.svg = new Svg({ w, h }, this.div); // Will be used to display the background svg
        [this.svg.x, this.svg.y] = [0, 0]; 
        this.svg_focus_circle = this.svg.add_new_circle(-8, -8, 4, '#00004444', '#ff5500');

        this.init_corner_pos(); this.init_cross(); this.init_name_div();

        adj_elem(this.div, { w, h, bg: '#00000044', border_color: 'black' });

        this.is_initialized = true; // now the refresh may work nominally    
    }

    delete_div() { delete this.div; }

    init_obs() { this.obs_pos = new V(0, 0); this.obs_soft_pos = new SV(this.obs_pos); }
    // the position of the world in the window
    init_corner_pos() { this.corner_pos = new V(0, 0); this.corner_soft_pos = new SV(this.corner_pos); } 

    init_cross() { // Cross is defined in Svg.js
        this.origin_cross = new Cross(0, 0, 64, 64, rgb(255, 0, 0), rgb(255, 0, 0));
        this.origin_cross.svg_node.style.z_index = 12;
        this.div.appendChild(this.origin_cross.svg_node);
    }
    
    init_name_div() {
        // ebu_padding_dict is defined in appearance.js
        this.name_div = new_child_div(this.div, { bg: '#000000', fg: '#ffffff', fsem: 1.3, ...ebu_padding_dict }, true); 
        this.name_div.innerHTML = "";
    }

    // Called when the world should be destroyed (should remove the div, etc.)
    clear_all() { 
        const [ebus, elis] = [this.ebus, this.elis];
        ebus.forEach(ebu => ebu.destroy()); elis.forEach(eli => eli.destroy());

    } // {?} Add code

    destroy() { this.clear_all(); this.release_focus(); } // {?} the unregistering in the eco is for now down at the eco level

    // concatenates the active code ebuble content
    get_active_code() { return this.ebus.filter(ebu => ebu.is_active_code).sort((lb, rb) => (lb.y - rb.y)).map(ebu => ebu.text).join('\n\n') }

    //////////////////////
    /// ACCESS METHODS ///
    //////////////////////

    get is_cur() { return this.eco.cur_wid == this.wid }

    get num_ebus() { return this.ebus.length }

    get bids() { return Object.keys(this.ebus_by_bid) }
    get lids() { return Object.keys(this.elis_by_lid) }
   
    get ebus() { return Object.values(this.ebus_by_bid) } 
    get elis() { return Object.values(this.elis_by_lid) }

    get bels() { return this.baw.bels }

    get media_ebus() { return this.ebus.filter(ebu => ebu.is_media_ebu) }

    get red_and_selection_bids() { 
        return (this.red_bid == undefined || this.selection_bids.has(this.red_bid)) ? [... this.selection_bids]: [... this.selection_bids, this.red_bid] 
    }

    get left() { return Math.min(... this.ebus.map(ebu => ebu.x)) }
    get top() { return Math.min(... this.ebus.map(ebu => ebu.y)) }
    get right() { return Math.max(... this.ebus.map(ebu => ebu.x + ebu.w)) }
    get bottom() { return Math.max(... this.ebus.map(ebu => ebu.y + ebu.h)) }

    get screen_width() { return this.eco.screen_width }
    get screen_height() { return this.eco.screen_height }
    get screen_size_dict() { return this.eco.screen_size_dict }

    get needs_tex() { return this.ebus.some(ebu => ebu.needs_tex) }

    abs_to_soft_screen_pos({ x, y }) { return { x: x - this.obs_soft_pos.x + this.corner_soft_pos.x, y: y - this.obs_soft_pos.y + this.corner_soft_pos.y } }
    abs_to_soft_screen_rect({ x, y, w, h }) { return { ... this.abs_to_soft_screen_pos({ x, y }), w, h } }
    soft_screen_to_abs_pos({ x, y }) { return { x: x + this.obs_soft_pos.x - this.corner_soft_pos.x, y: y + this.obs_soft_pos.y - this.corner_soft_pos.y } }
    soft_screen_to_abs_rect({ x, y, w, h }) { return { ... this.soft_screen_to_abs_pos({ x, y }), w, h } }
    abs_to_screen_pos({ x, y }) { return { x: x - this.obs_pos.x + this.corner_pos.x, y: y - this.obs_pos.y + this.corner_pos.y } }
    abs_to_screen_rect({ x, y, w, h }) { return { ... this.abs_to_screen_pos({ x, y }), w, h } }
    screen_to_abs_pos({ x, y }) { return { x: x + this.obs_pos.x - this.corner_pos.x, y: y + this.obs_pos.y - this.corner_pos.y } }
    screen_to_abs_rect({ x, y, w, h }) { return { ... this.screen_to_abs_pos({ x, y }), w, h } }

    get_main_pos_list() { return [[-128, -128], [-128, this.bottom - 128], [this.right - this.screen_width + 128, -128], [this.right - this.screen_width + 128, this.bottom - this.screen_height + 128]]; }

    find_lids(oribid, desbid) { return arr_intersection(this.lids_by_oribid[oribid] ?? [], this.lids_by_desbid[desbid]?? []) }

    make_new_ebu_from_dict(dict) { // {?} can be improved // for internal use only [private method]
        dict.metadata ??= {};
        dict.metadata.wid ??= this.wid; // Useful for the old version of the ebuble worlds
        dict.metadata.bid ??= `b-${get_unique_id()}`;
        dict.metadata.type ??= 'text'; 
        dict.text ??= '';
        switch (dict.metadata.type) { // the possible types are listed at the beginning of ebu.js
            case 'text': return new UniEbu(dict);
            case 'draw': return new DrawEbu(dict);
            case 'code': return new CodeEbu(dict);
            case 'media': case 'image': case 'video':  return new MediaEbu(dict); // image and video is for legacy
            case 'fra_bel': return new FraBel(this, dict); // {?} quite hacky
            default: return undefined;
        }
    }

    add_new_ebu_from_dict(dict, overwrite=false) {  // {?} ill-named, because it doesn't always add new ebu
        const bid = dict?.metadata?.bid; 
        if (overwrite || !(bid in this.ebus_by_bid)) return this.add_ebu(this.make_new_ebu_from_dict(dict));
        else { this.ebus_by_bid[bid].from_dict(dict); return this.ebus_by_bid[bid]; }
    }
    
    // adds an ebu to the world
    add_ebu(ebu) { if (ebu?.bid != undefined) this.ebus_by_bid[ebu.bid] = ebu; return ebu; }  // {?} Could add code to transfer an ebu from an ewo to another one

    remove_ebu(ebu) { return this.remove_ebu_by_bid(ebu?.bid) } // {?} clarify between remove and unlink

    remove_ebu_by_bid(bid) { // {?} Should sync with the server {?} Should be moved to the xeco anyway
        const ebu = eco.ebus_by_bid[bid]; if (!ebu) return undefined; 

        ebu.destroy(); 
        const lids_to_remove = flex_concat(this.lids_by_oribid[bid], this.lids_by_desbid[bid]);
        lids_to_remove.forEach(lid => this.remove_eli_by_lid(lid));
        this.unlink_ebu_by_bid(bid);
        return ebu;
    }

    unlink_ebu(ebu) { return this.unlink_ebu_by_bid(ebu?.bid) }

    unlink_ebu_by_bid(bid) { // {?} Should sync with the server {?} Should be moved to the xeco anyway
        const ebu = this.ebus_by_bid[bid]; if (!ebu) return undefined; 
        if (this.red_bid == bid) this.red_bid = undefined;
        if (this.green_bid = bid) this.green_bid = undefined;
        if (this.blue_bid == bid) this.blue_bid = undefined;
        if (this.selection_bids.has(bid)) this.selection_bids = new Set([... this.selection_bids].filter(sel_bid => sel_bid != bid));
        delete this.eco.ebus_by_bid[bid]; 
        delete this.ebus_by_bid[bid];
        return ebu;
    }

    add_eli(eli) { 
        const { lid, oribid, desbid } = eli;
        if (!all_defined(lid, oribid, desbid)) return undefined; 
        this.elis_by_lid[lid] = eli; 
        [this.lids_by_oribid[oribid], this.lids_by_desbid[desbid]] = [flex_append(this.lids_by_oribid[oribid], lid), flex_append(this.lids_by_desbid[desbid], lid)];
        if (eco?.on_lin_update) eco.on_lin_update(eli); // {?} Should be cleaner and should be elsewhere
        return eli; 
    }

    // sets an lid if not previously set {?} not very explicit
    make_new_eli_from_dict(dict) { dict.wid ??= this.wid; dict.lid ??= `l-${get_unique_id()}`; return new Eli(dict) }

    add_new_eli_from_dict(dict, overwrite=false) { 
        const { lid } = dict;
        if (overwrite || !(lid in this.elis_by_lid)) return this.add_eli(this.make_new_eli_from_dict(dict)); 
        else { this.elis_by_lid[lid].from_dict(dict, overwrite); return this.elis_by_lid[lid]; }
    }

    remove_eli(eli) { return this.remove_eli_by_lid(eli.lid) }

    remove_eli_by_lid(lid) { // {?} should sync with the server {?} Should be moved to the xeco anuwau
        const eli = this.elis_by_lid[lid]; if (!lid) return undefined; 
        const { oribid, desbid } = eli;
        eli.destroy(); 
        this.lids_by_oribid[oribid] = this.lids_by_oribid[oribid].filter(lid2 => lid2 != lid);
        this.lids_by_desbid[desbid] = this.lids_by_desbid[desbid].filter(lid2 => lid2 != lid);
        delete this.elis_by_lid[lid];
        return eli;
    }

    // {?} Perhaps later best moved to (x)eco
    get_eli_target_ebus(ori) { return this.lids_by_oribid[ori.bid].map(lid => this.elis_by_lid[lid]).map(eli => eli.desbid).map(bid => this.ebus_by_bid[bid]) }
    getProxiEbus(ori) {}

    /////////////////////
    /// FOCUS METHODS ///
    /////////////////////
    get red_bid() { return this._red_bid } 

    set red_bid(_red_bid) {  // {?} to be unified with the other colors
        const [old_red_ebu, new_red_ebu] = [this.ebus_by_bid[this._red_bid], this.ebus_by_bid[_red_bid]]; // undefined are acceptable
        if (old_red_ebu != new_red_ebu) { if (old_red_ebu) old_red_ebu.on_release_red(); if (new_red_ebu) new_red_ebu.on_get_red(); }
        if (this.eco.is_xeco) this.eco.on_change_red_ebu(old_red_ebu, new_red_ebu); // {?} a bit messy
        this._red_bid = _red_bid; 
        // the danger with the selection bids is that we may have an infinite sequence of recursive calls
        if (this.red_bid != undefined && !this.selection_bids.has(this.red_bid)) this.selection_bids = new Set([this.red_bid]);
        else if (this.red_bid == undefined && this.selection_bids.size > 0) this.selection_bids = new Set([]);
        if (this.red_bid != undefined) this.move_to_see_red_ebu();
        this.refresh_lf(); 
    }
    get green_bid() { return this._green_bid } 

    set green_bid(_green_bid) { 
        this._green_bid = _green_bid; 
        const [old_green_ebu, new_green_ebu] = [this.ebus_by_bid[this._green_bid], this.ebus_by_bid[_green_bid]]; // undefined are acceptable
        if (old_green_ebu != new_green_ebu) { if (old_green_ebu) old_green_ebu.on_release_green(); if (new_green_ebu) new_green_ebu.on_get_green(); }
        this.refresh_lf(); 
    }

    get blue_bid() { return this._blue_bid } 
    set blue_bid(_blue_bid) { 
        this._blue_bid = _blue_bid; 
        const [old_blue_ebu, new_blue_ebu] = [this.ebus_by_bid[this._blue_bid], this.ebus_by_bid[this._blue_bid]]; // undefined are acceptable
        if (old_blue_ebu != new_blue_ebu) { if (old_blue_ebu) old_blue_ebu.on_release_blue(); if (new_blue_ebu) new_blue_ebu.on_get_blue(); }
        this.refresh_lf(); 
    }

    get red_ebu() { return this.ebus_by_bid[this.red_bid] } // undefined is acceptable
    get green_ebu() { return this.ebus_by_bid[this.green_bid] } // undefined is acceptable
    get blue_ebu() { return this.ebus_by_bid[this.blue_bid] } // undefined is acceptable

    // this is a set, not an array
    get selection_bids() { return this._selection_bids ?? new Set() }
    set selection_bids(_selection_bids) { 
        this._selection_bids = this.sort_bids(_selection_bids); 
        // the danger with the red bids setter is that we may have an infinite sequence of recursive calls
        if (this.selection_bids.size == 0 && this.red_bid != undefined) this.red_bid = undefined;
        else if (!this.selection_bids.has(this.red_bid)) this.red_bid = first([... this.selection_bids])
    }

    get selection_ebus() { return [... this.selection_bids].map(bid => this.ebus_by_bid[bid]) }

    sort_bids(selection_bids) { 
        const ebu_compare = (l_ebu, r_ebu) => (l_ebu.y - r_ebu.y + 1e-6 * (l_ebu.x - r_ebu.x)); // {?} a bit hacky
        const bid_compare = (left_bid, right_bid) => ebu_compare(this.ebus_by_bid[left_bid], this.ebus_by_bid[right_bid]);
        return new Set([... (selection_bids ?? [])].sort(bid_compare)); 
    }

    get_closest_ebu(origin, excluded_bids=[], max_sq_rad = 1e6) {
        excluded_bids = arr_wrap_if_not_arr(excluded_bids);
        let closest_ebu = undefined;
        let min_sq_dist = max_sq_rad;
        const ebus_and_sq_dists = this.ebus.filter(ebu => excluded_bids.indexOf(ebu.bid) == -1).map(ebu => [ebu, ebu.sq_dist_to(origin)]);
        for (let [ebu, sq_dist] of ebus_and_sq_dists) if (sq_dist < min_sq_dist) { min_sq_dist = sq_dist; closest_ebu = ebu; }
        return closest_ebu;
    }

    // Should handle the case where exclEbuBid=undefined well (the corresponding exclEbu should also be undefined) and also if
    get_closest_ebu_bid(v, exclEbuBids=[], max_sq_rad = 1e6) {  return this.get_closest_ebu(v, exclEbuBids, max_sq_rad)?.bid }

    // gets the first ebu appearing in a given direction
    get_ebu_in_dir(origin, dir, excluded_bids=[]) {
        const inc = 8, { x: dir_x, y: dir_y } = dir, { x: originX, y: originY } = origin;
        for (let i = 1; i < 30; i++) {
            const [cx, cy, sqRad] = [originX + i * inc * dir_x, originY + i * inc * dir_y, (inc * i) * (inc * i)];
            const newOrigin = new V(cx, cy);
            const closest_ebu = this.get_closest_ebu(newOrigin, excluded_bids, sqRad);
            if (closest_ebu) return closest_ebu;
        }
        return undefined;
    }

    // if the ebu is undefined, we start from the observation point
    get_ebu_from_ebu_in_dir(ori_ebu, dir) {
        const ebuRect = ori_ebu ? [ori_ebu.x, ori_ebu.y, ori_ebu.w, ori_ebu.h]: undefined, dir_x = dir.x, dir_y = dir.y;
        const origin = ori_ebu ? new V(... rect_dir_loc(Math.sign(dir_x), Math.sign(dir_y), ... ebuRect)): this.obs_pos; // where we start looking from
        return ori_ebu ? this.get_ebu_in_dir(origin, dir, ori_ebu.bid) : this.get_ebu_in_dir(origin, dir);
    }

    // if the bid is not a real id, we start from the observation point (should also handled the undefinedness well)
    get_ebu_bid_from_ebu_bid_in_dir(bid, dir) { const ebu = this.get_ebu_from_ebu_in_dir(this.ebus_by_bid[bid], dir); return ebu?.bid }

    get_next_ebu_wrt_creation_time(cur_ebu) { // {?} a bit hacky
        const ebus_by_creation_date= {};
        this.ebus.forEach(ebu => ebus_by_creation_date[ebu.get_creation_date()] = ebu);
        const creation_dates = Object.keys(ebus_by_creation_date); creation_dates.sort();
        const next_creation_date = next_val(creation_dates, cur_ebu.get_creation_date());
        return ebus_by_creation_date[next_creation_date]; // undefined is acceptable
    }

    get_intersecting_ebus(rect_dict) { return this.ebus.filter(ebu => ebu.intersects_abs_rect_dict(rect_dict)) }

    switch_red_ebu_in_direction(dir_v) { this.red_bid = this.get_ebu_bid_from_ebu_bid_in_dir(this.red_bid, dir_v); }

    move_to_see_ebu(ebu, frame_rect_dict=undefined, margin) {
        const { x, y, w, h } = ebu.screen_rect_dict;
        const step = 16;
        margin ??= 32; // {?} TO IMPROVE
        const { x: fx, y: fy, w: fw, h: fh } = frame_rect_dict ?? { x: margin, y: margin, w: this.screen_width - 2 * margin, h: this.screen_height - 2 * margin }; // frame rect
        if (x < fx) this.obs_pos.x -= next_mult_round(-x + fx, step);
        if (x + w > fx + fw) this.obs_pos.x += next_mult_round((x + w) - (fx + fw), step);
        if (y < fy) this.obs_pos.y -= next_mult_round(-y + fy, step);
        if (y + h > fy + fh) this.obs_pos.y += next_mult_round((y + h) - (fy + fh), step);
    }

    move_to_see_red_ebu(frame_rect_dict=undefined) { if (this.red_ebu) this.move_to_see_ebu(this.red_ebu, frame_rect_dict) } 
    move_to_see_blue_ebu(frame_rect_dict=undefined) { if (this.blue_ebu) this.move_to_see_ebu(this.blue_ebu, frame_rect_dict) }

    move_to_center_ebu(ebu) {
        const step = 16;
        [this.obs_pos.x, this.obs_pos.y] = [next_mult_round(ebu.x - this.screen_width / 2, step), next_mult_round(ebu.y - this.screen_height / 2, step)];
    }

    get_all_ebus_in_direction(center_ebu, dir_v) {
        const { x, y } = dir_v;
        const { x: cx, y: cy, w: cw, h: ch } = center_ebu;
        if (x != 0) return this.ebus.filter(ebu => interval_intersection_len([ebu.y, ebu.y + ebu.h], [cy, cy + ch]) > 0 && (ebu.x - cx) * x >= 0);
        if (y != 0) return this.ebus.filter(ebu => interval_intersection_len([ebu.x, ebu.x + ebu.w], [cx, cx + cw]) > 0 && (ebu.y - cy) * y >= 0);
        else return [center_ebu];
    }

    ///////////////////////////////
    /// DISPLAY AND EVO METHODS ///
    ///////////////////////////////

    // moves things around
    evo_hf(is_deep = true) { 
        if (this.needs_evo_lf) this.evo_lf(this.needsDeepEvoLf);
        is_deep = true;  // {?} hacky
        this.obs_soft_pos.evo(); this.corner_soft_pos.evo(); 
        if (is_deep) { this.evo_ebus_hf(); this.evo_elis_hf(); } 
        this.baw.evo_hf();
    }
   
    evo_ebus_hf() { this.ebus.forEach(ebu => ebu.evo_hf()) }
    evo_elis_hf() { this.elis.forEach(eli => eli.evo_hf()) }

    evo_lf(is_deep=true) { 
        [this.needs_evo_lf, this.needsDeepEvoLf] = [false, false]; 
        if (is_deep) { this.evo_ebus_lf(); this.evo_elis_lf(); } 
        this.baw.evo_lf();
    }

    evo_ebus_lf() { this.ebus.forEach(ebu => ebu.evo_lf()) }
    evo_elis_lf() { this.elis.forEach(eli => eli.evo_lf()) }

    finalize(is_deep=true) { this.obs_soft_pos.finalize(); if (is_deep) this.finalize_ebus(); }

    finalize_ebus() { this.ebus.forEach(ebu => ebu.finalize()); }

    refresh_hf(is_deep = true) { 
        if (!this.is_initialized) return; 
        if (this.needs_refresh_lf) this.refresh_lf(this.needs_deep_refresh_lf);
        if (is_deep) { this.refresh_ebus_hf(); this.refresh_elis_hf(); }
        this.refresh_cross_hf();
        this.refresh_name_hf();
        this.baw.refresh_hf();
    }

    // full refresh
    refresh_lf(is_deep = true) {
        if (!this.is_initialized) return;
        [this.needs_refresh_lf, this.needs_deep_refresh_lf] = [false, false];
        const { w, h } = this.screen_size_dict;
        adj_elem(this.div, { w, h });
        [this.svg.w, this.svg.h] = [w, h];
        if (is_deep) this.refresh_ebus_lf();
        this.baw.refresh_lf();
    }

    refresh_ebus_hf() { this.ebus.forEach(ebu => ebu.refresh_hf()) }
    refresh_elis_hf() { this.elis.forEach(eli => eli.refresh_hf()) }
    refresh_cross_hf() { this.origin_cross.update_pos(-this.obs_soft_pos.x, -this.obs_soft_pos.y) }
    refresh_name_hf() {
        const [x, y] = [-this.obs_soft_pos.x, -32 - this.obs_soft_pos.y];
        adj_elem(this.name_div, {x, y});
        this.name_div.innerHTML = this.name;
        if (this.tags.length > 0) this.name_div.innerHTML += " (" + this.tags.join(" ") + ")";
        adj_elem_visibility(this.name_div, this.show_ewo_name);
    }
    refresh_ebus_lf() { this.ebus.forEach(ebu => ebu.refresh_lf()) }
    refresh_elis_lf() { this.elis.forEach(eli => eli.refresh_lf()) }

    evo_and_refresh_lf_soon(is_deep = false) { [this.needs_evo_lf, this.needs_refresh_lf, this.needsDeepEvoLf, this.needs_deep_refresh_lf] = [true, true, is_deep, is_deep] }

    acquire_focus() { if (!this.eco.div.contains(this.div)) this.eco.div.appendChild(this.div); }
    release_focus() { if (this.eco.div.contains(this.div)) this.eco.div.removeChild(this.div); }

    /////////////////////////////
    /// SERIALIZATION METHODS ///
    /////////////////////////////

    to_dict(is_deep=false) {
        // general note: the undefined stuff will not be jsonified and that's perfect
        const edata = { last_mod_time: this.last_mod_time, last_mod_hash: this.last_mod_hash };
        let dict = { edata, wid: this.wid, name: this.name, tags: this.tags ?? [], 
            is_in_progress: this.is_in_progress, is_view_only: this.is_view_only, done: this.done, todo: this.todo,
            ebus_by_bid: {}, elis_by_lid: {},
            baw: this.baw.to_dict() 
        };

        if (is_deep) { // {?} Later that part will be removed if the ewo (world) is to become more of a shell
            this.ebus.forEach(ebu => { dict.ebus_by_bid[ebu.bid] = ebu.to_dict() });
            this.elis.forEach(eli => { dict.elis_by_lid[eli.lid] = eli.to_dict() });
        }
        return dict;
    } 

    from_dict(dict, overwrite=false) {
        if (overwrite) this.clear_all();
        const edata = dict.edata ?? {};
        [this.wid, this.name, this.tags] = [dict.wid ?? this.wid, dict.name ?? '', dict.tags ?? []];
        [this.last_mod_time, this.last_mod_hash] = [dict.last_mod_time ?? dict.lastModTime ?? '', dict.last_mod_hash ?? dict.lastModHash ?? ''];
        // [this.red_bid, this.green_bid, this.blue_bid] = [edata.red_bid, edata.green_bid, edata.blue_bid];
        [this.obs_pos.x, this.obs_pos.y] = [-128, -128]; // {?} Harmonize with [-128, -128] of the obs pos
        this.is_view_only = dict.is_view_only ?? false;
        let { ebus_by_bid, elis_by_lid } = dict;

        ebus_by_bid ??= dict.bubs_by_bid; ebus_by_bid ??= dict.ebus_by_bid; elis_by_lid ??= dict.elis_by_lid;  // {?} Legacy

        [this.is_in_progress, this.done, this.todo] = [dict.is_in_progress ?? false, dict.done ?? 0, dict.todo ?? 0];

        if (dict.baw) this.baw.from_dict(dict.baw);

        Object.entries(ebus_by_bid ?? this.ebus_by_bid ?? {}).forEach(([bid, ebu_dict]) => this.add_new_ebu_from_dict(ebu_dict, overwrite));
        Object.entries(elis_by_lid ?? {}).forEach(([lid, eliDict]) => this.add_new_eli_from_dict(eliDict, overwrite));
    }


    /////////////////////
    /// EVENT METHODS ///
    /////////////////////

    async on_event(event, key_event) {  // {?} should ultimately be centralized in the eco and xeco
        this.evo_and_refresh_lf_soon(); // allows us to return things and have modifications called just after
        const { key_combination, is_dir_key, meta_or_ctrl_key, alt_key, dir_v } = key_event ?? {};
        if (is_dir_key && ((meta_or_ctrl_key && !alt_key) || (this.is_view_only && this.red_bid != undefined))) return this.on_switch_red_ebu_in_direction(dir_v);
        if (meta_or_ctrl_key && alt_key && is_dir_key) return this.on_select_all_from_ebu_in_direction(this.red_ebu, dir_v);

        if (event == 'move_around_corners') { this.on_move_around_corners(); return true; }
        if (event == 'move_across_history') { this.on_move_across_history(); return true; }
        if (event == 'move_to_ebu') return this.on_move_to_ebu(this.red_ebu); 
        if (event == 'next') { this.red_bid = next_val_circ([... this.selection_bids], this.red_bid); return true; }
        if (event == 'prev') { this.red_bid = prev_val_circ([... this.selection_bids], this.red_bid); return true; }
    
        // Expected behavior: if there is a selection, forward to all members of the selection, otherwise move the observer
        if (!meta_or_ctrl_key && is_dir_key) { 
            const red_and_selection_bids = this.red_and_selection_bids; // note: this is an array, not a set like selection_bids
            if (red_and_selection_bids.length > 0 && !this.is_view_only) { 
                red_and_selection_bids.forEach(bid => this.ebus_by_bid[bid].on_dir_key(key_event)); 
                const red_and_selection_ebus = red_and_selection_bids.map(bid => this.ebus_by_bid[bid]);
                const bels_to_move = this.baw.get_intersecting_bels_from_ebus(red_and_selection_ebus).filter(bel => bel.is_locked);
                bels_to_move.forEach(bel => bel.on_dir_key(key_event, false)); // move_intersecting_ebus=false
                this.move_to_see_red_ebu();
                return true; 
            } 
            else { this.on_dir_key(key_event); return true; }
        }
        if (this.red_ebu) { if (await this.red_ebu.on_event(event, key_event)) return true; }
        // below: code if we don't have a red focus or we didn't capture anything
        if (event == 'toggle_red_focus') { this.red_bid = this.get_closest_ebu_bid(this.obs_pos.plus(new V(this.screen_width / 2, this.screen_height / 2))); return true; }
        return false;
    }

    async on_wheel(wheel_event) { // {?} To merge with on_event
        const { deltaX: delta_x, deltaY: delta_y, shiftKey: shift_key } = wheel_event;
        const round_unit = 32; // maybe move this somewhere else at some point
        const move_vect = new V(Math.round(delta_x / round_unit) * round_unit, Math.round(delta_y / round_unit) * round_unit);
        let multiplier = eco.zoom_multiplier * 2; if (shift_key) multiplier *= 8;
        this.obs_pos.add(move_vect.times(multiplier));
        return true;
    }

    get_ebus_at_screen_loc({ x, y }) { return this.ebus.filter(ebu => is_point_in_rect_dict({ x, y }, ebu.screen_rect_dict)) }

    on_switch_red_ebu_in_direction(dir_v) { this.switch_red_ebu_in_direction(dir_v); return true; }

    on_select_all_from_ebu_in_direction(center_ebu, dir_v) {
        if (!center_ebu) return true;
        this.selection_bids = new Set(this.get_all_ebus_in_direction(center_ebu, dir_v).map(ebu => ebu.bid));
        return true;
    }

    async on_mouse_click(mouse_event, mouse_state) {
        if (mouse_event.meta_or_ctrl_key) return true;
        return false;
    }

    async on_mouse_up(mouse_event, mouse_state) { // {?} To merge with on_event
        this.evo_and_refresh_lf_soon(true);
        const [x, y, w, h] = mouse_state.sel_rect;
        const abs_sel_rect = [x + this.obs_pos.x, y + this.obs_pos.y, w, h]; // needs to be improved and cleaned up and adapted to zoom
        const caught_bids = this.ebus.filter(ebu => ebu.intersects_abs_rect(... abs_sel_rect)).map(ebu => ebu.bid); // note: this is an array
        const selection_bids = mouse_event.shiftKey ? arr_xor([... this.selection_bids], caught_bids) : caught_bids; // note: this is an array
        this.selection_bids = new Set(selection_bids); 
    }

    // the specified metadata will override the specified data
    add_new_ebu_auto_loc(metadata={}) { // {?} Should improve the autolocation
        let { x: ox, y: oy } = this.obs_pos;
        [ox, oy] = [next_mult_round(ox, 16), next_mult_round(oy, 16)];
        let [x, y] = this.red_ebu ? [this.red_ebu.x, this.red_ebu.y + this.red_ebu.h] : [ox, oy];
        let [w, h] = this.red_ebu ? [this.red_ebu.w, 32] : [256, 32];
        const pos = metadata.pos ?? { x, y }, size = metadata.size ?? { w, h }, type = metadata.type ?? 'text';
        metadata = { ... metadata, type, pos, size };
        const new_ebu = this.add_new_ebu_from_dict({ metadata, text: '' });
        new_ebu.soft.h = 1;
        return new_ebu;
    }

    on_new_ebu(metadata={}) { 
        if (this.tags.includes('todo')) metadata.label = 'todo'; // {?} hacky
        if (this.tags.includes('capsule')) metadata.label = 'capsule'; // {?} hacky
        if (this.tags.includes('item')) metadata.label = 'item';
        if (this.tags.includes('objective')) metadata.label = 'objective';
        const ebu = this.add_new_ebu_auto_loc(metadata); this.red_bid = ebu?.bid ?? -1; return true; 
    }

    on_new_ebu_with_eli_from_red(metadata={}) {
        const old_red_ebu = this.red_ebu; 
        const new_red_ebu = this.add_new_ebu_auto_loc(32); 
        if (!all_defined(old_red_ebu, new_red_ebu)) return true; 
        this.add_new_eli_from_dict({ oribid: old_red_ebu.bid, desbid: new_red_ebu.bid, wid: this.wid }); 
        this.red_bid = new_red_ebu.bid;
        return true;
    }

    on_remove_red_ebu() { this.remove_ebu(this.red_ebu); return true; }

    on_remove_green_to_red_eli() { this.find_lids(this.green_bid, this.red_bid).forEach(lid => this.remove_eli_by_lid(lid)); return true; }

    on_new_eli(green_ebu, red_ebu) { 
        if (!all_defined(green_ebu, red_ebu) || green_ebu == red_ebu) return true;
        this.add_new_eli_from_dict( { oribid: green_ebu.bid, desbid: red_ebu.bid, wid: this.wid }); this.green_ebu.releaseGreen();
        return true;
    }

    // Called if the event is not forwarded to the selected ebubles
    on_dir_key(key_event) { 
        let multiplier = Math.max(Math.round(64 * eco.zoom_multiplier), 1); if (key_event.shiftKey) multiplier *= 16;
        this.obs_pos.add(key_event.dir_v.times(multiplier));
        return true;
    }

    on_move_around_corners() {
        const mpl = this.get_main_pos_list();
        const index = arr_of_arr_last_index_of(mpl, [this.obs_pos.x, this.obs_pos.y]); // -1 if not found
        [this.obs_pos.x, this.obs_pos.y] = mpl[(index + 1) % mpl.length];
    }

    on_move_across_history() {
        const ebus = this.ebus;
        const bids = ebus.map(ebu => ebu.bid);
        const dates = ebus.map(ebu => ebu.get_last_mod_date());
        const bids_by_date = zip_to_dict(dates, this.bids);
        dates.sort().reverse();
        if (dates.length > 0) {
            const last_mod_date = dates[0];
            const last_mod_bid = bids_by_date[last_mod_date];
            const last_mod_ebu = this.ebus_by_bid[last_mod_bid];
            this.move_to_center_ebu(last_mod_ebu);
        }
    }

    on_move_to_ebu(ebu) { if (ebu == undefined) return true; this.move_to_see_ebu(ebu); return true; }
    
    on_show_start() { 
        this.bids.forEach(bid => { this.fade_by_bid[bid] = 0.87 }); 
        this.evo_and_refresh_lf_soon(); 
        this.show_ewo_name = false;
    }

    on_show_stop() { this.fade_by_bid = {}; this.show_ewo_name = true; } // no fading
}
