////////////////////
/// A LINK CLASS ///
////////////////////
// Notionally a link should belong to an eco, not an ewo, but for display reasons, it is important to first focus
// on links that can be displayed in a world
////////////////////

class Eli {
	constructor(dict) { this.wid = dict.wid; this.init_div(); this.from_dict(dict); }

	init_div() { this.svg_link = new SvgLink(0, 0, 1, 1, rgb(255, 255, 255)); this.ewo.div.appendChild(this.svg_link.svg_node); }

	register() { this.register_wid(); this.register_eli(); }

	register_wid() { eco.wids_by_lid[this.lid] = this.wid } // {?} same: ultimately not needed
    register_eli() { eco.elis_by_lid[this.lid] = this } // {?} later this should not be needed, as that will be the native location of ebus


	destroy() { this.ewo.div.removeChild(this.svg_link.svg_node); this.refresh_lf(); }

	get ewo() { return eco.ewos_by_wid[this.wid] }

	get ori_ebu() { return this.ewo?.ebus_by_bid[this.oribid] } // undefined is an acceptable return value
	get des_ebu() { return this.ewo?.ebus_by_bid[this.desbid] } // undefined is an acceptable return value

	get is_ori_red() { return this.ori_ebu?.is_red } get is_des_red() { return this.des_ebu?.is_red }
	get is_ori_green() { return this.ori_ebu?.is_green } get is_des_green() { return this.des_ebu?.is_green }

	get is_displayable() { return all_defined(this.ori_ebu, this.des_ebu) }

	get fade() { return this.ori_ebu?.fade ?? 0 }

	get color() {
		if (this.is_ori_red) return colors.red; 
		if (this.is_des_red) return colors.green;
		if (this.fade > 0) return fade_text_col(this.fade);
		return colors.ebu_text;
	}

	comp_abs_link_rect() { // {?} hacky, used for the html export
		this.adjust_svg_link(this.ori_ebu.abs_rect_dict, this.des_ebu.abs_rect_dict);
		let sl = this.svg_link; let [ox, oy, dx, dy] = [sl.ox, sl.oy, sl.dx, sl.dy];
		let [x, y] = [Math.min(ox, dx), Math.min(oy, dy)]; let [w, h] = [Math.max(ox, dx) - x, Math.max(oy, dy) - y];
		return { x, y, w, h };
	}

	evo_hf() {}
	evo_lf() {}

	refresh_lf() { this.svg_link.update_intermediate_points(); }

	refresh_hf() { // {?} TO BE OPTIMIZED FOR PERFORMANCE
		this.svg_link.stroke = this.color;
		if (this.is_displayable) this.adjust_svg_link(this.ori_ebu.screen_soft_rect_dict, this.des_ebu.screen_soft_rect_dict);
	}

	adjust_svg_link(ori_ebu_rect_dict, des_ebu_rect_dict) {
		const { x: ox, y: oy, w: ow, h: oh } = ori_ebu_rect_dict, { x: dx, y: dy, w: dw, h: dh } = des_ebu_rect_dict;
		// {?} Logically correct but must be simplified or conceptualized (note: we favor vertical links over horizontal ones)
		if (oy + oh < dy) { // case mid-to-mid
			[this.svg_link.ox, this.svg_link.oy, this.svg_link.dx, this.svg_link.dy] = [ox + ow / 2, oy + oh, dx + dw / 2, dy];
			this.svg_link.orientation = 'vertical';
		}
		else if (dy + dh < oy) { // case mid-to-mid
			[this.svg_link.ox, this.svg_link.oy, this.svg_link.dx, this.svg_link.dy] = [ox + ow / 2, oy, dx + dw / 2, dy + dh];
			this.svg_link.orientation = 'vertical';
		}
		else if (ox + ow < dx) {
			[this.svg_link.ox, this.svg_link.oy, this.svg_link.dx, this.svg_link.dy] = [ox + ow, oy + oh / 2, dx, dy + dh / 2];
			this.svg_link.orientation = 'horizontal';
		}
		else if (dx + dw < ox) {
			[this.svg_link.ox, this.svg_link.oy, this.svg_link.dx, this.svg_link.dy] = [ox, oy + oh / 2, dx + dw, dy + dh / 2];
			this.svg_link.orientation = 'horizontal';
		}
		else {
			[this.svg_link.ox, this.svg_link.oy, this.svg_link.dx, this.svg_link.dy] = [ox + ow / 2, oy + oh / 2, dx + dw / 2, dy + dh / 2];
			this.svg_link.orientation = 'none';
		}
	}

	to_dict() { 
		return { lid : this.lid, oribid : this.oribid, desbid : this.desbid, wid: this.wid } 
	}

	from_dict(dict, overwrite=false) { 
		[this.lid, this.oribid, this.desbid, this.wid] = [dict.lid, dict.oribid, dict.desbid, dict.wid]; 
		this.register();
	}
}