// 
const colors = {
	red: '#ff0000',
	green: '#00ff00',
	blue: '#0000ff',
	yellow: '#ffff00',
	cyan: '#00ffff',
	magenta: '#ff00ff',
	input_bg: '#000011dd',
	input_fg: '#ffffff',
	math_preview_bg: '#000055cc',
	clickable_ebu: '#00ddff',
	clickable_ebu_hover: '#aaaaff',
	on_axis_code: '#ffff88',
	off_axis_code: '#aaaaaa',
	red_ebu_frame: '#ff0000',
	green_ebu_frame: '#00ff00',
	transparent: '#00000000',
	gate_frame: '#0044bb',
	tinycap_frame: '#004444',
	minicap_frame: '#005454',
	capsule_frame: '#006464',
	frame: '#4477bb',
	capsule_text: '#e0c0c0',
	location_text: '#ffffcc',
	ebu_text: '#e0d0d0',
	red_and_green_ebu_text: '#00ff00',
	selected_ebu_background: '#99000088'
}

function alphacol(v) { const b = Math.round(clip(v, 0, 1) * 255); return rgba(0, 0, b, b); }
function fade_text_col(f) { let o = Math.round((1 - clip(f, 0, 1)) * 255); return rgba(240, 220, 220, o); }
function fade_background_col(f) { let o = Math.round((1 - clip(f, 0, 1)) * 255); return rgba(0, 0, 0, o); }