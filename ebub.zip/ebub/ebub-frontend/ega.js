///////////////
// A GALAXY ///
///////////////

class Ega {
	constructor(dict) { // modify to accept a dictionary as input 
		this.from_dict(dict);
		this.cur_wid = this.main_wid; // {?} It's a passive variable, just to bookmark what is the current wid
	}

	get eco() { return eco } // {?} hack... ultimately we want the eco to be part of the ega

	get is_blackboard() { return this.eco.blackboard_ega_name == this.name }

	get is_cur() { return this.eco.cur_ega == this }
	get ewos() { return this.wids.filter(wid => wid in this.eco.ewos_by_wid).map(wid => this.eco.ewos_by_wid[wid]) }
	get is_cur_or_expanded() { return this.is_expanded || this.is_cur || this.is_blackboard }
	get num_ebus() { return arr_sum(this.wids.map(wid => this.eco.ewos_by_wid[wid]?.num_ebus ?? 0)) }

	get cur_wid() { return this._cur_wid }
	set cur_wid(_cur_wid) { this._cur_wid = _cur_wid; if (_cur_wid != undefined) this.eco.last_wids_by_gid[this.gid] = this.cur_wid }

	get full_name() { return this.name + (this.tags?.length > 0 ? ' (' + this.tags.join(' ') + ')' : '');}

	attach_ewo(ewo) { if (this.wids.indexOf(ewo.wid) == -1) { this.wids.push(ewo.wid); this.cur_wid = ewo.wid; } } // we check that the ewo is not there already
	detach_ewo(ewo) { this.wids = this.wids.filter(wid => wid != ewo?.wid) }

	cleanup_wids() { 
		this.wids = this.wids.filter(wid => wid in this.eco.ewos_by_wid); 
		if (this.wids.indexOf(this.main_wid) == -1) this.main_wid = first(this.wids);
		if (this.wids.indexOf(this.cur_wid) == -1) this.cur_wid = this.main_wid;
	}

	add_sync_address(address_to_add) { if (this.sync_addressses.indexOf(address_to_add) == -1) this.sync_addressses.push(address_to_add) }
	remove_sync_address(address_to_remove) { this.sync_addressses = this.sync_addressses.filter(address => address != address_to_remove) }

	upswap_cur_wid() { this.swap_wid(this.cur_wid, -1) } // swaps the cur wid with the previous wid, so that it takes its place 
	downswap_cur_wid() { this.swap_wid(this.cur_wid, 1) } // swaps the cur wid the with the next wid, so that it takes its place 

	swap_wid(wid, dir) { // dir should be +1 or -1
		const wid_index = this.wids.indexOf(wid); 
		if (wid_index == -1) return;
		const swap_index = wid_index + dir;
		if (swap_index < 0 || swap_index >= this.wids.length) return;
		const wids = this.wids;
		swap_entries(wids, wid_index, swap_index);
		this.eco.emap.reconstruct_soon();
	}

	/////////////////////
	/// SERIALIZATION ///
	/////////////////////

	to_dict(is_deep=false, add_timestamp=false) { 
		const dict =  { gid: this.gid, name: this.name, description: this.description, 
				wids: this.wids, main_wid: this.main_wid, cur_wid: this.cur_wid, sync_addressses: this.sync_addressses,
				is_expanded: this.is_expanded, tags: this.tags ?? [] };
		if (is_deep) dict.ewos_by_wid = merge_dicts(this.wids.map(wid => ({ [wid]: eco.ewos_by_wid[wid]?.to_dict(is_deep) })));
		if (add_timestamp) dict.timestamp = get_cur_epoch();
		return dict;
	}

	from_dict(dict) {
		[this.gid, this.name, this.description, this.tags] = [dict.gid, dict.name ?? '[no-name]', dict.description ?? '', dict.tags ?? []];
		[this.wids, this.main_wid, this.is_expanded, this.sync_addressses] = [dict.wids ?? [], dict.main_wid ?? dict.mainWid, dict.is_expanded ?? dict.isExpanded ?? true, dict.sync_addressses ?? dict.sync_addresses ?? []];
	}

}