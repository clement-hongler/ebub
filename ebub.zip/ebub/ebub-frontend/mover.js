
/////////////////
/// MOVEBOARD ///
/////////////////

class Mover {
    constructor() {
        [this.selection_wid, this.selection_bids] = [undefined, []];
        this.copied_bids_by_original_bid = {};
        this.selection_history = [];
    }

    prepare_move(ewo, is_cut_move) {
        if (this.selection_wid) this.selection_history.push( { selection_wid: this.selection_wid, selection_bids: this.selection_bids });
        [this.selection_wid, this.selection_bids] = [ewo.wid, [... ewo.selection_bids]]; 
        this.should_remove_original = false;
        this.is_cut_move = is_cut_move;
    }


    execute_prepared_move(des_ewo) { // {?} Needs an implementation when we make a copy
        const ori_ewo = eco.ewos_by_wid[this.selection_wid]; if (ori_ewo == undefined || des_ewo == undefined) return;
        const selection_ebus = this.selection_bids.map(bid => ori_ewo.ebus_by_bid[bid]).filter(ebu => ebu != undefined);
        const [sel_ori_xs, sel_ori_ys] = [selection_ebus.map(ebu => ebu.x), selection_ebus.map(ebu => ebu.y)];
        const sel_ori_top_left = { x: Math.min(... sel_ori_xs), y: Math.min(... sel_ori_ys) };
        const des_top_left = { x: des_ewo.obs_pos.x, y: des_ewo.obs_pos.y };
        const [red_bid, green_bid, blue_bid] = [ori_ewo.red_bid, ori_ewo.green_bid, ori_ewo.blueBid];
        const sel_bids = new Set([... ori_ewo.selection_bids].filter(bid => bid in ori_ewo.ebus_by_bid)); // filter the ebus that are still there (not erased) 
        const new_bids_by_old_bid = {};
        for (const ebu of selection_ebus) {
            if (this.is_cut_move) this.move_ebu(ebu, ori_ewo, des_ewo, sel_ori_top_left, des_top_left);
            else this.copy_ebu(ebu, ori_ewo, des_ewo, sel_ori_top_left, des_top_left); // updates copied_bids_by_original_bid
        }
        if (this.is_cut_move) [des_ewo.selection_bids, des_ewo.red_bid, des_ewo.green_bid, des_ewo.blue_bid] = [sel_bids, red_bid, green_bid, blue_bid];
        else {
            des_ewo.selection_bids = new Set([... sel_bids].map(bid => this.copied_bids_by_original_bid[bid]));
            [des_ewo.red_bid, des_ewo.green_bid, des_ewo.blue_bid] = [red_bid, green_bid, blue_bid].map(bid => this.copied_bids_by_original_bid[bid]);             
        }
        this.selection_wid = des_ewo.wid;
    }

    copy_ebu(ebu, ori_ewo, des_ewo, sel_ori_top_left, des_top_left) {
        const [x_shift, y_shift] = [256, 256];
        const new_ebu_dict = ebu.to_dict();
        [new_ebu_dict.metadata.bid, new_ebu_dict.metadata.wid] = [undefined, undefined]; // {?} small hack to force the des_ewo to create a new unique bid
        const new_ebu = des_ewo.add_new_ebu_from_dict(new_ebu_dict);
        this.adjust_ebu_pos(new_ebu, sel_ori_top_left, des_top_left);
        this.copied_bids_by_original_bid[ebu.bid] = new_ebu.bid;
        return new_ebu;
    }

    move_ebu(ebu, ori_ewo, des_ewo, sel_ori_top_left, des_top_left) {
        if (ori_ewo != des_ewo) { ori_ewo.unlink_ebu(ebu); ebu.destroy(); des_ewo.add_ebu(ebu); des_ewo.div.appendChild(ebu.div); }
        ebu.metadata.wid = des_ewo.wid; // {?} clarify whether to use a setter
        this.adjust_ebu_pos(ebu, sel_ori_top_left, des_top_left);
        ebu.register();
        return ebu;
    }

    adjust_ebu_pos(ebu, sel_ori_top_left, des_top_left) {
        const [x_shift, y_shift] = [256, 256];
        [ebu.x, ebu.y] = [ebu.x - sel_ori_top_left.x + des_top_left.x + x_shift, ebu.y - sel_ori_top_left.y + des_top_left.y + y_shift];
        [ebu.soft.x, ebu.soft.y] = [0, 0];
    }



    execute_alt_move(des_ewo) { this.is_cut_move ^= true; this.execute_prepared_move(des_ewo); this.is_cut_move ^= true; }
}

const mover = new Mover();
