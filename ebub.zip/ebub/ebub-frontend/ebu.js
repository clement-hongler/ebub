// This is the list of the ebu types. They are implemented as daughter classes of Ebu
// The various types are captured at the creation in the Ewo class as well (ewo.js)
////////////////////////////////////////////////////////////////////////////////////
/// Ultimately, most of the types of ebubles should disappear in favor of labels /// 
///

const ebu_types = ['text', 'draw', 'code', 'media'];


// {?} Clarify the shortcuts {?} Rename with better versions {?} Priorities/exclusivities are unclear
// {?} Should go full exclusive mode
const ebu_labels_by_initial = {
    '1': ['title_1'], '2' : ['title_2'], '3': ['title_3'], '0': ['small'],
    g: ['gate', 'anchor', 'alink'], n: ['note'], q: ['question', 'answer'], d: ['todo', 'done'],
    f : ['framed'], r: ['remark', 'summary'], a: ['beginning', 'end'], p: ['predicted', 'realized'],
    b: ['item'], l: ['location'], i: ['invert'], c: ['tinycap', 'minicap', 'capsule'], o: ['objective', 'achievement'],
    m: ['math-formula'] // {?} need to add something with date, with conclusion
};

const decorations_by_label = { question: '▹', answer: '▸', todo: '▫︎', done: '▪︎', item: '•', objective: '✧', achievement: '✦' }

const indended_ebu_label_set = new Set(['item', 'todo', 'done', 'question', 'answer', 'beginning', 'end', 'objective', 'achievement']);

const e_fields_by_label = { 
    gate: ['ewo-name', 'gal-name', 'anchor-name'], 
    anchor: ['anchor-name'], 
    alink: ['href'], 
    location: ['gps-coords', 'location-name', 'time'], 
    todo: ['todo', 'done', 'priority', 'deadline'],
    done: ['done'], note: ['note'] 
};

const tinycap_max_length = 24; // {?} to place at a better location
const smallcap_max_length = 80; // {?} to place at a better location
const ebu_display_params = { min_ebu_wid: 64, max_ebu_wid: 1024 }; // {?} To place at a better location 

// {?} Really need to fix the label as list vs singleton thing

// {?} Needs to be merged with AutoEbu
class Ebu {
    // {?} the first metadata assigment is a hack to allow us to know the ewo in the init_div
    constructor(dict) { this.metadata = dict.metadata; this.init_div(); this.from_dict(dict ?? {}); } 

    update_legacy_metadata() { 
        substitute_members(this.metadata.size, { x: 'w', y: 'h' }); 
        substitute(this.labels, { task: 'todo', comment: 'note', 'title-1': 'title_1', 'title-2': 'title_2', 'title-3': 'title_3' }); // {?} to deprecate eventually
        if ('subtype' in this.metadata) delete this.metadata['subtype'];
        this.metadata.is_xebu ??= this.metadata.is_xebu ?? false; // {?} legacy
        this.metadata.text_mod_times ??= this.metadata.textModTimes ?? [];
        if (this.labels.length > 0 && this.label == undefined) this.label = first(this.labels);
        delete this.metadata['is_xebu']; delete this.metadata['textModTimes']; 
    }

    init_div() {
        this.div = new_child_div(this.ewo.div, {});
        [this.text_div, this.label_div] = [new_child_div(this.div, {}), new_child_div(this.div, {})];
        this.label_text = '';
        this.is_mouse_over = false;

        add_events(this.div, { mouseover: (e) => this.on_mouse_over(e), mousemove: (e) => this.on_mouse_move(e) });
        add_events(this.div, { mouseleave: (e) => this.on_mouse_leave(e), click: (e) => this.on_mouse_click(e) });
    }

    init_pos_data() { this.soft = { x: this.x, y: this.y, w: this.w, h: this.h, alpha: 0, fade: 0 } }

    register() { this.register_wid(); this.register_ebu(); }

    register_wid() { eco.wids_by_bid[this.bid] = this.wid } // {?} same: ultimately not needed
    register_ebu() { eco.ebus_by_bid[this.bid] = this } // {?} later this should not be needed, as that will be the native location of ebus

    // removes the div from the parent (should also remove all the div's descendents)
    destroy() { this.ewo.div.removeChild(this.div); } 
  
    ////////////////////////////
    /// STATE ACCESS METHODS ///
    ////////////////////////////

    get is_xebu() { return this.metadata.is_xebu ?? false }

    get pos() { return this.metadata.pos } set pos(_pos) { this.metadata.pos.copy_from(_pos) }
    get size() { return this.metadata.size } set size(_size) { this.metadata.size.copy_from(_size) } 

    get x() { return this.pos.x ?? 0 } set x(_x) { this.pos.x = _x } 
    get y() { return this.pos.y ?? 0 } set y(_y) { this.pos.y = _y }
    get w() { return this.size.w ?? 0 } set w(_w) { this.size.w = _w } // {?} should migrate to size.w, but tricky
    get h() { return this.size.h ?? 0 } set h(_h) { this.size.h = _h } // {?} should migrate to size.h, but tricky

    get rect_dict() { return { x: this.x, y: this.y, w: this.w, h: this.h } }
    set rect_dict(_rect_dict) { const { x, y, w, h } = _rect_dict; [this.x, this.y, this.w, this.h] = [x, y, w, h]; }

    get wid() { return this.metadata.wid } // {?} clarify if to add a setter
    get bid() { return this.metadata.bid }
    get ewo() { return eco.ewos_by_wid[this.wid] } 

    get is_red() { return this.ewo?.red_bid == this.bid }
    get is_green() { return this.ewo?.green_bid == this.bid }
    get is_selected() { return this.ewo?.blue_bid == this.bid }

    get is_selected() { return this.ewo?.selection_bids?.has(this.bid) }
    set is_selected(_is_selected) { 
        if (_is_selected != this.is_selected) this.evo_and_refresh_lf_soon();
        if (this.ewo.selection_bids.has(this.bid)) { if (!_is_selected) this.ewo.selection_bids.delete(this.bid) }
        else { if (_is_selected && this.bid != undefined) this.ewo.selection_bids.add(this.bid) } // we only add to the selection if we have a bid
    }

    get type() { return this.metadata.type } 

    get label() { return this.metadata.label }
    set label(label) { this.metadata.label = label}

    get labels() { return this.metadata.labels ?? [] }  // {?} deprecated}
    set labels(_labels) { this.metadata.labels = rem_dupes(_labels ?? []); this.on_changed_label(); } // {?} deprecated}

    get is_text_locked() { return false; } // is overridden in e.g. debu 

    // {?} TO CLEAN UP
    get frame_color() { 
        if (eco.is_in_baw_edit) return colors.transparent
        if (this.is_red) return colors.red_ebu_frame;
        if (this.is_green) return colors.green_ebu_frame;
        if (this.is_gate) return colors.gate_frame;
        if (this.is_minicap) return colors.minicap_frame;
        if (this.is_tinycap) return colors.tinycap_frame;
        if (this.is_capsule) return colors.capsule_frame;
        if (this.is_framed) return colors.frame;
        return colors.transparent;
    }

    get text_color() { 
        if (this.is_green && this.is_red) return; colors.red_and_green_ebu_text 
        if (this.soft.fade > 0) return fade_text_col(this.soft.fade);
        if (this.is_capsule) return colors.capsule_text;
        if (this.is_location) return colors.location_text;
        return colors.ebu_text;
    } // If we are red, to show that we're green also, we do it on the text
   
    get background_color() { 
        if (this.is_selected && !this.is_red) return colors.selected_ebu_background;
        if (this.soft.alpha > 0) return alphacol(this.soft.alpha);
        if (this.soft.fade > 0) return fade_background_col(this.soft.fade);
        return colors.transparent; // {?} not clear if this should be completely transparent or not
    }

    get font_dict() {
        let [fsem, font_weight, font_style] = [1, 'normal', 'normal'];
        if (this.is_big_title) [fsem, font_weight, font_style] = [1.9, 'bold', 'normal'];
        else if (this.is_med_title) [fsem, font_weight, font_style] = [1.05, 'bold', 'normal'];
        else if (this.is_small_title) [fsem, font_weight, font_style] = [1, 'bold', 'italic'];
        else if (this.is_location) [fsem, font_weight, font_style] = [1, 'bold', 'normal'];
        else if (this.is_small) [fsem, font_weight, font_style] = [0.7, 'normal', 'normal'];
        return { fsem, font_weight, font_style };
    }

    get border_width() { return 1 }
    get border_style() { return 'solid' }
    get border_radius() { return this.is_gate || (this.is_capsule || this.is_tinycap) ? 8 : 0 }

    get is_math() { return false } // {?} ALl ebubles should be math ultimately

    get markdown_text() { // {?} a bit hacky, used to export ebubles into a markdown format
        if (this.is_big_title) return `** ${this.text} **`; 
        else if (this.is_med_title) return `* ${this.text} *`; 
        else if (this.is_small_title) return `: ${this.text} :`; 
        else if (this.is_location) return `[${this.text}]`;
        return this.text; 
    }

    get metadata_dict() { // used to remove useless 'default values'
        const metadata = JSON.parse(JSON.stringify(this.metadata));
        if (!metadata.is_xebu) delete metadata['is_xebu'];
        if (!metadata.source) delete metadata['source'];
        if (!metadata?.labels?.length) delete metadata['labels'];
        if (!metadata?.text_mod_times?.length) delete metadata['text_mod_times'];

        delete metadata['is_math']; // {?} historical vars
        return metadata;
    }

    get history_dict() {
        const history = JSON.parse(JSON.stringify(this.history));
        delete history['textModTimes']; delete history['lastModTime']; delete history['textModifications']; // clean up the old versions
        return history;
    }

    ///////////////////////
    /// SPATIAL METHODS ///
    ///////////////////////

    get cx() { return this.x + this.w / 2 }
    get cy() { return this.y + this.h / 2 }

    get is_at_rest() { if (this.ewo.show_all) return false; return this.soft.is_at_rest && this.ewo.obs_soft_pos.is_at_rest }
    get is_within_visible_rect() { 
        if (this.ewo.show_all) return true;
        let { w, h } = eco?.screen_size_dict, mar = 512; 
        let [x, y] = [0, 0];
        x -= mar; y -= mar; w += 2 * mar; h += 2 * mar;
        return rect_dict_intersection_area(this.screen_soft_rect_dict, { x, y, w, h }) > 0 || rect_dict_intersection_area(this.screen_rect_dict, { x, y, w, h }) > 0;
    }

    get screen_soft_pos() { return this.ewo.abs_to_soft_screen_pos(this.soft) }
    get screen_soft_size() { return { w: this.soft.w, h: this.soft.h } } // later we can rescale by the screen factor

    get screen_soft_pos_vec() { return [this.soft.x, this.soft.y] }
    get screen_soft_size_vec() { return [this.soft.w, this.soft.h] }

    get screen_pos() { return this.ewo.abs_to_screen_pos(this.pos) }
    get screen_size() { return { w: this.w, h: this.h } }
    get screen_rect_dict() { return { ... this.screen_pos, ... this.screen_size } }

    get abs_rect_dict() { return { x: this.x, y: this.y, w: this.w, h: this.h }}
    get abs_soft_rect_dict() { return { x: this.soft.x, y: this.soft.y, w: this.soft.w, h: this.soft.h }}

    get screen_rect_dict() { return { ... this.screen_pos, ... this.screen_size } } 
    get screen_soft_rect_dict() { return { ... this.screen_soft_pos, ... this.screen_soft_size } }

    get ideal_height() { return next_mult_round(this.text_div.offsetHeight, 16) }
    // The reference z coordinate
    get z() { return (this.is_red ? 32: 16) }

    get is_visible() { return this._is_visible ?? true } // by default we are visible
    set is_visible(_is_visible) { if (_is_visible != this.is_visible) adj_elem_visibility(this.div, _is_visible); this._is_visible = _is_visible; } // acts on the visibility if a change is needed

    get alpha() { return eco.alphas_by_bid[this.bid] ?? 0 }
    set alpha(_alpha) { eco.alphas_by_bid[this.bid] = clip(_alpha ?? 0, 0, 1) }

    get fade() { const fade = this.ewo.fade_by_bid[this.bid] ?? 0; return fade; }
    set fade(_fade) { this.ewo.fade_by_bid[this.bid] = _fade }
    // set alpha(_alpha) { if (_alpha > 0) eco.alphas_by_bid[this.bid] = _alpha; else if (this.bid in eco.alphas_by_bid) delete eco.alphas_by_bid[this.bid]; } // we maintain the sparsity

    // {?} Should be cleaned up
    get is_big_title() { return this.label == 'title_1' }
    get is_med_title() { return this.label == 'title_2' }
    get is_small_title() { return this.label == 'title_3' }
    get is_small() { return this.label == 'small' }
    get is_location() { return this.label == 'location' }
    get is_gate() { return this.label == 'gate' }
    get is_inverted() { return this.label == 'invert'} // mostly useful for images (and drawings) at this point
    get is_clickable() { return this.is_gate || this.is_xebu }
    get is_tinycap() { return this.label == 'tinycap' }
    get is_minicap() { return this.label == 'minicap'}
    get is_capsule() { return this.label == 'capsule' }
    get is_framed() { return this.label == 'framed'}
    get is_dotted() { return this.label == 'dotted' }
    get is_todo() { return this.label == 'todo' }
    get is_done() { return this.label == 'done' }
    get is_item() { return this.label == 'item' }
    get is_objective() { return this.label == 'objective' }
    get is_achievement() { return this.label == 'achievement' }
    get is_indented() { return indended_ebu_label_set.has(this.label) } // {?} to be improved
    get is_media_ebu() { return false }

    get cur_e_field() { return this.temp?.cur_e_field } set cur_e_field(_cur_e_field) { this.temp.cur_e_field = _cur_e_field }
    get cur_e_value() { return this.edata[this.cur_e_field] ?? '' } 
    set cur_e_value(_evalue) { if (!this.cur_e_field) return; this.edata[this.cur_e_field] = _evalue }
    get e_fields() { return this.label ? e_fields_by_label[this.label] : [] } 

    get is_code() { return false } // true for code ebubles

    get is_on_imaginary_axis() { return this.x == 0 }

    get is_active_code() { return this.is_code && this.is_on_imaginary_axis }

    get text_mod_times() { return this.history?.text_mod_times ?? [] }

    get needs_tex() { return false } // whether some latex compilation is needed

    get is_locked() { return this.ewo.is_view_only }

    get_creation_date() { // {?} a bit hacky
        if (this.bid.startsWith('b-')) {
            try { const date = new Date(); date.setTime(this.bid.substring(2, 15)); return format_full_date_with_time(date); }
            catch (err) { return undefined }
        }
    }
    get_last_mod_date() { return (this.text_mod_times.length > 0) ? format_full_date_with_time(new Date(last(this.text_mod_times))) : this.get_creation_date() }

    move_by(v) { this.move_to(this.pos.plus(v)) } // {?} clarify the use of 'move' (see with the navigation)
    move_to(pos) { this.pos = pos; }
    sq_dist_to(v) { return sq_dist_to_rect(v.x, v.y, this.x, this.y, this.w, this.h) } // defined in commmon.js

    contains_abs_point(x, y) { return is_in_rect(x, y, this.x, this.y, this.w, this.h) }
    intersects_abs_rect(x, y, w, h) { return rect_intersection_num([x, y, w, h], [this.x, this.y, this.w, this.h]) > 0 } 
    intersects_abs_rect_dict({ x, y, w, h }) { return this.intersects_abs_rect(x, y, w, h) }

    /////////////////////
    /// FOCUS METHODS ///
    /////////////////////

    // {?} Maybe better to create event onRed and on_release_red
    release_red() { this.evo_and_refresh_lf_soon(); if (this.is_red) this.ewo.red_bid = undefined; this.text = this.is_code ? this.text : this.text.trim(); } // {?} the trim is a bit hacky
    release_green() { this.evo_and_refresh_lf_soon(); if (this.is_green) this.ewo.green_bid = undefined }
    release_blue() { this.evo_and_refresh_lf_soon();  if (this.is_selected) this.ewo.blue_bid = undefined }

    toggle_green() { this.ewo.green_bid = this.is_green ? undefined : this.bid }
    toggle_selected() { this.is_selected ^= true; }

    /////////////////////////////
    /// SERIALIZATION METHODS ///
    /////////////////////////////

    from_dict({ metadata, text, edata, history }, overwrite=false) { 
        [this.metadata, this.text, this.edata, this.history] = [metadata ?? {}, text ?? '', edata ?? {}, history ?? {}];
        this.temp = {};
        this.update_legacy_metadata(); this.init_pos_data(); this.register();
    }

    to_dict() { 
        const dict = { text: this.text, metadata: this.metadata_dict, edata: this.edata, history: this.history_dict } 
        // {?} ugly, though makes files lighter
        if (!dict.metadata || Object.keys(dict.metadata).length == 0) delete dict['metadata']; if (!dict.text) delete dict['text']; 
        if (!dict.edata || Object.keys(dict.edata).length == 0) delete dict['edata']; 
        if (!dict.history || Object.keys(dict.history).length == 0) delete dict['history']; 
        return dict;
    }    

    ///////////////////////////////
    /// EVO AND DISPLAY METHODS ///
    ///////////////////////////////

    // checks for the data modifications and stores them in the metadata
    notarize() { if (this.temp.prev_text != this.text) { eco.notarize(this); this.temp.prev_text = this.text; } }

    evo_hf() { 
        if (this.needs_evo_lf) this.evo_lf();
        eco.num_hf_evo_steps++; 
        this.soft.is_at_rest = (this.soft.x == this.x && this.soft.y == this.y);
        this.soft.is_at_rest &&= (this.soft.w == this.w && this.soft.h == this.h);
        this.soft.is_at_rest &&= (this.soft.alpha == this.alpha && this.soft.fade == this.fade);
        if (this.is_at_rest || !this.is_within_visible_rect) return; 
        [this.soft.x, this.soft.y] = [adj_int(this.soft.x, this.x), adj_int(this.soft.y, this.y)];
        [this.soft.w, this.soft.h] = [adj_int(this.soft.w, this.w), adj_int(this.soft.h, this.h)];
        [this.soft.alpha, this.soft.fade] = [adj_float(this.soft.alpha, this.alpha), adj_float(this.soft.fade, this.fade)];
    }

    evo_lf() { this.needs_evo_lf = false; eco.number_of_lf_evos++;  }

    finalize() { [this.soft.x, this.soft.y, this.soft.w, this.soft.h, this.soft.alpha] = [this.x, this.y, this.w, this.h, this.alpha] }

    adj_pos() {
        const sw = -14, sh = -9, tdsx = -31.5, tdsy = 1;  // magic numbers to make everything hold tight // {?} Needs to be cleaned up
        let { x, y, w, h } = this.screen_soft_rect_dict; adj_elem(this.div, { x, y, w: w + sw, h: h + sh });
        if (this.task_decoration != undefined) { [this.task_decoration.x, this.task_decoration.y] = [tdsx, tdsy]; }
    }

    adj_cols() { 
        adj_elem(this.div, { fg: this.text_color, bg: this.background_color, border_color: this.frame_color });
    }

    adj_styles() {
        const padding_dict = ebu_padding_dict; // defined in appearance.js
        const { border_width, border_style, border_radius } = this; 
        adj_elem(this.div, { z: this.z, fsem: 1, border_width, border_style, border_radius, ... padding_dict });
        adj_elem(this.text_div, { ... padding_dict, x: -2, y: -2, lh: 1.4 }); // {?} magic numbers
        adj_elem(this.label_div, { ... padding_dict, x: -5, y: 5 }); // {?} magic numbers
        if (this.is_indented) adj_elem(this.div, { padding_left: 13, padding_right: 0 });
    }

    adj_content() {
        this.text_div.innerHTML = this.text;
    }

    refresh_hf() { 
        if (this.needs_refresh_lf) this.refresh_lf(); 
        adj_elem_visibility(this.div, this.is_within_visible_rect);
        if (this.is_at_rest || !this.is_within_visible_rect) return; 
        this.adj_pos(); 
        this.adj_cols(); 
    }

    refresh_lf() { // {?} SHOULD BE SIMPLIFIED
        this.needs_refresh_lf = false;
        this.adj_styles();
        this.adj_cols(); 
        this.refresh_label_div();
        this.adj_content();
        this.adj_pos();
    }

    refresh_label_div() { this.label_div.innerHTML = decorations_by_label[this.label] ?? '' }

    evo_and_refresh_lf_soon() { [this.needs_evo_lf, this.needs_refresh_lf] = [true, true]; }

    /////////////////////
    /// EVENT METHODS ///
    /////////////////////

    // Direct call to a ebuble means the ebuble is red 
    // {?} should be renamed on event
    async on_event(event, key_event) { // {?} to be later replaced by 'on_event'
        this.evo_and_refresh_lf_soon();
        setTimeout(() => { this.evo_lf(); this.refresh_lf() }, 1); // {?} hacky, but allows to have a snappy auto-resize
        const { is_dir_key, key_combination, prev_key_combination } = key_event;
        if (is_dir_key && !this.is_locked) { if (this.on_dir_key(key_event)) return true; }

        if (event == 'deep_action') return this.on_deep_action(event);
        if (event == 'toggle_red_focus') { this.release_red(); return true; }
        if (event == 'deep_toggle') { this.toggle_green(); return true; }
        if (event == 'toggle_selected') { this.toggle_selected(); return true; }
        if (event == 'round_position') return this.on_round_position(event)
        if (prev_key_combination == 'meta+J' && !this.is_locked) { return this.on_label_key(key_event); } // {?} to be cleaned up

        if (!this.is_text_locked && !this.is_locked) {
            this.text = key_event.adj_text(this.text, this.is_multispace);
            if (this.is_tinycap && this.text.length >= tinycap_max_length) this.text = this.text.substring(0, tinycap_max_length);
            if (this.is_minicap && this.text.length >= minicap_max_length) this.text = this.text.substring(0, minicap_max_length);

        }
        return true; // indicates we have captured the event
    }

    on_dir_key(key_event) {
        const { shift_key, dir_v, alt_key } = key_event;
        let multiplier = 16; if (shift_key) multiplier *= 8;
        let [dir_x, dir_y] = [dir_v.x, dir_v.y];
        dir_x *= multiplier; dir_y *= multiplier;

        if (alt_key) { this.w = clamp(this.w + dir_x, 32, 1024); this.h = clamp(this.h + dir_y, 32, 1024); }
        else { this.x += dir_x; this.y += dir_y; }
        return true;
    }

    on_label_key(key_event) {
        const key_labels = arr_wrap_if_not_arr(ebu_labels_by_initial[key_event.key]); if (key_labels.length == 0) return true;
        if (!this.label) { this.label = first(key_labels); return true; }
        this.label = next_val_if_exists(key_labels, this.label);
        return true;
    }

    on_deep_action(event) {
        if (this.is_gate) { eco.nav_to_ewo(this.edata['ewo-name']); return true; }
        if (this.is_xebu) { eco.move_to_see_ebu(this.ancestor_ebu); eco.is_in_xewo_mode = event.meta_or_ctrl_key || event.alt_key; return true; } // {?} ugly
        this.on_temporary_highlight(event);
        return false;
    }

    on_mouse_over(event) { }
    on_mouse_leave(event) { }
    on_mouse_move(event) { }
    on_mouse_click(event) { }

    on_temporary_highlight(event) { 
        if (kes.isAltDown) { this.fade = this.fade > 0.0 ? 0.0 : 0.8; }
        else { this.alpha = 0.8; setTimeout(() => { this.alpha = 0.0 }, 2000); } 
    }

    on_round_position(event) { [this.x, this.y] = [next_mult_round(this.x, 32), next_mult_round(this.y, 32)] }
    
    // Color callbacks are called when the color is changed, but do not 'cause' the color change
    on_get_red() { this.fade = 0;  }
    on_release_red() {  }
    on_get_green() { }
    on_release_green() {}
    on_get_blue() { }
    on_release_blue() { }

    on_changed_label() {
        const styles_by_label = {

        };
        this.evo_and_refresh_lf_soon(); 
    }

}

////////////////////////////////////
/////// THE DAUGHTERS OF BUB ///////
////////////////////////////////////
// Note: for serialization, they  //
// are created within ewo, in the //
// add_new_ebu_from_dict method       //
// Also: xebu is a daughter class //
// for terminal exchange, that is //
// defined in terminal.js         //
////////////////////////////////////


// Auto-resize Ebu
// {?} To be merged with Ebu (with an option for autoResize)
class AutoEbu extends Ebu {
    constructor(dict) { super(dict) }
    evo_lf() { super.evo_lf(); [this.w, this.h] = [clip(this.w, ebu_display_params.min_ebu_wid, ebu_display_params.max_ebu_wid), this.ideal_height]; }
}

// Math (katex) formula ebu
// {?} To be merged with ebu (with an option for math)
class MathEbu extends AutoEbu {
    constructor(dict = {}) { super(dict); }

    get ideal_height() { return next_mult_round(this.render_div.offsetHeight, 16) }
    
    init_div() { // is called by the constructor or the ebu parent
        super.init_div();
        // we permanently disable the viewing of the textDi, preferring the render_div
        // (though we could replace the latter by the former)
        hide_elem(this.text_div); 
        this.render_div = new_child_div(this.div, {}); // useful to show the math content
        this.preview_div = new_child_div(this.div, {});
        adj_elem(this.preview_div, { bg: colors.math_preview_bg, z: 128 , ... ebu_padding_dict });
        adj_elem(this.render_div, { gmar: 0, gpad: 3, lh: 1.4 });
    }

    refresh_lf() {
        super.refresh_lf();
        // the visibility of the preview div will be decided by the descendents
        const { x, y, w, h } = this.screen_soft_rect_dict;  
        if (all_defined(x, y, w, h)) adj_elem(this.preview_div, { x: w, w, y: -6, h: h });
    }
}

// Universal ebu
class UniEbu extends MathEbu {
    constructor(dict = {}) {
        dict.metadata.type = 'text'; 
        super(dict);
        this.prev_text_rendered = '';
        this.show_preview = false;
    }

    init_div() { 
        super.init_div(); 
        this.math_div = document.createElement('div'); // used to dump the katex and copy it into the div
    }

    get is_math() { return true }

    get needs_tex() { return this.uses_latex ?? false } // needs to 

    refresh_lf() { // Code inherited from inline math ebu
        super.refresh_lf();
        super.adj_cols(); // {?} messy

        if (this.prev_text_rendered != this.text) {

        // add some escape mechanism for the dollars
            const text = this.text.replaceAll('\\$', standard_unicum_0); // {?} hacky
            let dollar_split = text.split('$').map(dollar_part => dollar_part.replaceAll(standard_unicum_0, '$'));

            let render_html = '';

            this.uses_latex = false;
            // {?} should be cleaned up a bit
            if (this.last_text_rendered != this.text) {
                for (let i = 0; i < dollar_split.length; i++) {
                    if (i % 2 == 0) {
                        render_html += text_to_html(dollar_split[i]);  // {?} hacky
                    }
                    else { // odd index i, corresponding to an inline formulae
                        katex.render(dollar_split[i], this.math_div, { throwOnError: false });
                        render_html += this.math_div.innerHTML;
                        this.uses_latex = true;
                    }
                }
            }

            if (!this.is_clickable) this.render_div.innerHTML = render_html.length > 0 ? render_html : magical_invisible_char;

            // {?} 'click' should be added... the problem was the innerHTML edition
            if (this.is_clickable) { // {?} hacky and ugly, to be fixed now that we have understood what caused problem
                this.render_div.innerHTML = '';
                const alink = new_child_alink(this.render_div, { href: '#', position: 'relative', text_decoration: 'none', color: colors.clickable_ebu });
                alink.addEventListener('mouseover', () => { alink.style.color = colors.clickable_ebu_hover });
                alink.addEventListener('mouseleave', () => { alink.style.color = colors.clickable_ebu });
                alink.addEventListener('mouseup', (event) => setTimeout(() => this.on_deep_action(event), 1)); // {?} to be gotten rid of as soon as possible
                alink.innerHTML = render_html;
            }

            this.is_in_preview = dollar_split.length > 0 && dollar_split.length % 2 == 0;
            if (this.is_in_preview) this.preview_div.innerHTML = dollar_split.at(-1);
            else this.preview_div.innerHTML = '';


            this.prev_text_rendered = JSON.parse(JSON.stringify(this.text));
        }

        adj_elem(this.div, { ... this.font_dict, text_align: 'left', display: 'inline-block' });

        adj_elem_visibility(this.preview_div, this.is_red && this.is_in_preview);
    }
}

let init_div_count = 0;

// Media ebu: merge of image ebu and video ebu
/// 
// We need a mechanism to store the 'natural' width and height of the media. For now, it is all automatically resized to [256, 256]
class MediaEbu extends Ebu {
    constructor(dict = {}) {
        dict.metadata.type = 'media';
        dict.metadata.size ??= { w: 256, h: 256 };

        // dict.metadata.source ??= dict.metadata.image_source// ?? dict.metadata.img_src ?? dict.metadata.image_href ?? ""; // {?} hacky, legacy 
        // {?} legacy conversion code
        if (dict.metadata.source?.includes('/images/')) dict.metadata.source = dict.metadata.source.replace("/images/", "/media/");
        if (dict.metadata.source?.includes('/videos/')) dict.metadata.source = dict.metadata.source.replace("/videos/", "/media/");
        super(dict);
        this.auto_set_media_type(); // {?} a bit hacky, but useful for legacy
        this.must_reload_media = true;
    }


    get is_media_ebu() { return true }

    get source() { return this.metadata.source ?? '' }
    set source(_source) { 
        this.metadata.source = _source; this.must_reload_media = true; this.auto_set_media_type();
    }
    
    get media_type() { return this.metadata.media_type ?? 'image' } // {?} a bit hacky, but we will say image by default
    set media_type(_media_type) { this.metadata.media_type = _media_type }

    /*
        Needs an onload method that will adjust the ebuble width to the image (and will round, and perhaps adjust the 
        position to get something reasonable)... and later we can find an adjustment factor compared to the initial
        nominal size to resize the picture in case of need
    */
    get is_text_locked() { return true }

    auto_set_media_type() { // {?} the whole thing should be done better
        if (!this.source) this.media_type == 'image'; // {?} a bit hacky, but by default, we will say image
        if (this.source.endsWith('.jpg') || this.source.endsWith('.jpeg') || this.source.endsWith('.gif') || this.source.endsWith('.png') || this.source.endsWith('.webp') || this.source.endsWith('.svg')) { this.media_type = 'image'; }
        if (this.source.endsWith('.mp4')) this.media_type = 'video'
    }

    show_controls_temporarily() { 
        if (this.media_type != 'video') return;
        this.media_elem.controls = true; 
        setTimeout(() =>  { this.media_elem.controls = false }, 2000);
    }

    // Called by the parent's constructor
    init_div() {
        super.init_div();
        if (this.media_type == 'image') {
            this.media_elem = new_child_elem('img', this.div);
            adj_elem(this.media_elem, { w: this.w, h: this.h });
        }
        else if (this.media_type == 'video') {
            this.media_elem = new_child_elem('video', this.div);
            [this.media_elem.width, this.media_elem.height] = [this.width, this.height];
        }
        this.media_elem.addEventListener('load', () => this.on_media_loaded());
    }

    refresh_hf() { 
        super.refresh_hf(); const [w, h] = [this.soft.w, this.soft.h]; 
        adj_elem(this.media_elem, { w , h }); 
        if (this.soft.fade > 0) this.media_elem.style.opacity = `${1.0 - this.soft.fade}`;
    }

    refresh_lf() { 
        super.refresh_lf(); 
        if (this.must_reload_media) { 
            if (this.media_type == 'image') {
                this.media_elem.src = this.source ?? ''; 
            }
            else if (this.media_type == 'video') {
                this.media_elem.src = this.source ?? '';
            }
            this.must_reload_media = false; 
        } // {?} check if this has any use
        this.media_elem.style.filter = this.is_inverted ? 'invert(1)' : ''; 
        adj_elem(this.media_elem, { w: this.soft.w, h: this.soft.h }); 

    }

    async on_event(event, key_event) {
        if (event == 'deep_action') { console.log(this.metadata); if (this.media_type == 'video') this.show_controls_temporarily(); }
        if (event == 'import_action' ) { await this.on_import_media(); this.refresh_lf(); return true; }
        if (await super.on_event(event, key_event)) return true;
        return false;
    }

    async on_import_media() {
        const file_data = await eapi.request_file_to_open({ dialog_title: 'Please select media' });
        const { canceled, file_paths } = file_data;
        if (!canceled && file_paths.length == 1) {
            const source_path = file_paths[0];
            const source_file_name = source_path.substr(source_path.lastIndexOf(path.sep) + 1); // perhaps a bit hacky
            const dest_path =  path.join(path.media_dir, source_file_name);
            const { status } = await eapi.copy_file({ source_path, dest_path });
            this.source = dest_path;
            eco.post_status(status + " for the copy of the media from " + source_path + " to " + dest_path);
        }
    }

    async on_media_loaded() {}
}


// Code ebu
class CodeEbu extends AutoEbu {
    constructor(dict = {}) {
        dict.metadata.type = 'code';
        dict.metadata.size.x ??= 512;
        super(dict);
    }

    init_div() {
        super.init_div();
        hide_elem(this.text_div); 
        this.pre = new_child_pre(this.div); // useful to show the math content
        this.code = new_child_code(this.pre);
        adj_elem(this.pre, { gmar: 0, gpad: 2, lh: 1.4, fsp: 11, display: 'inline-block' });
        adj_elem(this.code, { gmar: 0, gpad: 2, lh: 1.4, fsp: 11, display: 'inline-block' });
    }

    get background_color() { return super.background_color }
    get text_color() { return this.is_on_imaginary_axis ? colors.on_axis_code : colors.off_axis_code }
    get frame_color() { return super.frame_color }

    get is_code() { return true }

    get ideal_height() { return next_mult_round(this.code.clientHeight, 16); }

    get is_text_locked() { return true }

    on_event(event, key_event) {
        // {?} hacky, but we mean that we want to edit the ebuble
        if (key_event.key_combination.length == 1 && eco.is_xeco && !eco.is_in_deep_edit) { eco.start_deep_edit(this); return true; } 
        else return super.on_event(event, key_event); 
    }

    adj_pos() {
        super.adj_pos();
        let { x, y, w, h } = this.screen_soft_rect_dict; 
        adj_elem(this.pre, { w }); adj_elem(this.code, { w }); // {?} to adjust to look nicer
    }

    adj_content() {
        this.code.innerHTML = this.text + magical_invisible_char; // forces newlines where necessary {?} a bit hacky
    }
}

////////////////////
/// DRAWING EBUS ///
////////////////////


class DrawEbu extends Ebu {
    constructor(dict = {}) {
        dict.metadata.type = 'draw';
        dict.metadata.size ??= { w: 256, h: 256, background_color: '#00003399' };
        super(dict);
    }

    get is_text_locked() { return true }

    destroy() { super.destroy(); }

    refresh_lf() {
        super.refresh_lf(); 
        adj_elem(this.div, { border_color: this.is_red ? colors.red_ebu_frame : colors.transparent });
        if (this.svg) [this.svg.w, this.svg.h] = [this.w, this.h];
    }

    evo_hf() {
        super.evo_hf();
        if (this.svg) this.svg.evo_hf();
    }

    refresh_hf() {
        super.refresh_hf();
        if (this.svg) this.svg.refresh_hf();
    }

    to_dict() { const dict = super.to_dict(); dict.svg = this.svg.to_dict(); return dict; }

    from_dict(dict) {
        super.from_dict(dict);
        this.svg = new SmartSvg(this.div, { w: this.w, h: this.h }); // defined in smartsvg.js
        if (dict.svg) { this.svg.from_dict(dict.svg); }
    }  

}
