//////////////////////////////////////
/// EXTERNAL COSMOS (or Ecosystem) ///
//////////////////////////////////////

class Eco { // Instantiated in the form of a xeco in index.js
    constructor(dict, parent_div) { 
        this.init(dict, parent_div);
        this.beats_threshold = 10;

        this.is_xeco = false; // this being false says we are in view mode by default
        this.blackboard_ega_name = 'blackboard';
        this.is_code_loop_on = false;
        [this.reference_zoom_level, this.zoom_level, this.soft_zoom_level]= [1.0, 1.0, 1.0];
        this.is_default_zoom_on = false;
        this.status_height = 24;
        this.soft_status_height = 24;
        this.status_display_time = 5000;
        this.status_queue = [];

        this.should_evo_and_refresh_soon = false;
        this.last_call_time = get_now_time();

        [this.mod_times_by_bid, this.text_mods_by_bid] = [{}, {}];

        this.events_by_time = {};

        this.activate_hf_mode();
    }

    // We need to clarify the init sequence (the order in which things are being called, taking into account the parent's calls)
    init(dict, parent_div) { 
        this.ebus_by_bid = {}; // will ultimately be the main repository of ebus
        this.elis_by_lid = {}; // same for elis
        this.ewos_by_wid = {};
        this.egas_by_gid = {};
        this.gids = [];
        this.wids_by_bid = {}; // {?} will also be useful for the uniformization where all the ebus are in the eco 
        this.wids_by_lid = {}; // {?} will also be useful for the uniformization where all the ebus are in the eco 

        this.timestamps_by_gid = {}; // the timestamps of the last updates of the gids
        this.alphas_by_bid = {}; // the attention field for the ebubles
        [this.cur_wid, this.cur_gid] = [undefined, undefined];
        this.last_wids_by_gid = {};
        this.init_div(parent_div); 
        this.zoom_facts_by_event = { zoom_in: sqrtsqrt2, large_zoom_in: 2, zoom_out: invsqrtsqrt2, large_zoom_out: 0.5 }; // {?} move somewhere else
        this.zoom_canonical_vals = [2 * sqrt2, invsqrtsqrt2];
        if (dict) this.from_dict(dict); 
    }

    init_div(parent_div) {
        this.div = new_child_div(parent_div, { fsem: 1, font: 'Courier', bg: '#000000', x: 0, y: 0, wpc: 100, hpc: 100 }, false); 
        const font_dict = { fsem: 1, font: 'Courier' };
        
        this.code_loop_div = new_child_div(this.div, font_dict); 

        this.status_div = new_child_div(this.div, { bg: '#123456aa', fg: 'white', z : 256, fsp: 13, ... ebu_padding_dict}, false);
        hide_elem(this.status_div);
        this.emap = new Emap(this);
        this.ega_menu_div = new_child_div(this.div, {}, false); // {?} experimental
        this.is_ega_menu_visible = false;

        this.helper = new Helper(this);
    }

    // destructor (cleans things up)
    destroy() {}

    reInit() { this.destroy(); this.init(); }

    //////////////////////
    /// ACCESS METHODS ///
    //////////////////////

    get ebus() { return Object.values(this.ebus_by_bid) }

    get cur_wid() { return this._cur_wid } // undefined is an acceptable value

    set cur_wid(_cur_wid) {
        this.evo_and_refresh_lf_soon();
        if (this.cur_wid == _cur_wid) return; // don't do anything if we're not switching wids
        if (!(_cur_wid in this.ewos_by_wid)) { this.post_status(`Ewo with wid=${_cur_wid} does not exist`); return; };
        const [old_ewo, new_ewo] = [this.ewos_by_wid[this.cur_wid], this.ewos_by_wid[_cur_wid]]; 
        old_ewo?.release_focus(); new_ewo?.acquire_focus(); this._cur_wid = _cur_wid;
        if (old_ewo?.name && new_ewo?.name) this.post_status(`Moved from ${old_ewo.name} to ${new_ewo.name}`);
        if (this.cur_ega != undefined) { // {?} a bit hacky, because when we create a gid, the cur_wid is undef
            if (this.cur_ega.wids.indexOf(_cur_wid) == -1 && this.cur_wid != undefined) this.cur_gid = undefined;// the new current ewo is not in the current ega
            else this.cur_ega.cur_wid = _cur_wid; // sets the last_wids_by_gid
        }
    }

    get cur_ega_wids() { return this.cur_ega?.wids ?? [] }

    get cur_ewo_gids() { return this.gids.filter(gid => this.egas_by_gid[gid].wids.indexOf(this.cur_wid) != -1) }
    get cur_ewo_bids() { return this.cur_ewo?.bids ?? [] }
    get cur_ewo_ebus() { return this.cur_ewo?.ebus ?? [] }

    get cur_gid() { return this._cur_gid } // undefined is an acceptable value
    set cur_gid(_cur_gid) { 
        this.evo_and_refresh_lf_soon(); if (this.cur_gid == _cur_gid) return; 
        this._cur_gid = _cur_gid; 
        // if we land somewhere and we don't know where to go
        if (this.cur_ega && this.cur_ega_wids.indexOf(this.cur_wid) == -1) this.cur_wid = first(this.cur_ega.wids);
        this.emap.reconstruct_soon();
    }

    get cur_ega() { return this.egas_by_gid[this.cur_gid] } // undefined is acceptable

    get cur_ewo() { return this.ewos_by_wid[this.cur_wid] ?? undefined }
    get wids() { return this.ewos.map(ewo => ewo.wid) }
    get ewos() { return Object.values(this.ewos_by_wid).filter(ewo => !ewo.is_xewo) } 

    get num_ewos() { return this.ewos.length } 

    get num_ebus() { return arr_sum(this.ewos.map(ewo => ewo.num_ebus)) }

    get cur_ega() { return this.egas_by_gid[this.cur_gid] ?? undefined }
    get egas() { return Object.values(this.egas_by_gid) ?? [] }
    get num_egas() { return this.egas.length }

    get is_code_loop_on() { return this._is_code_loop_on ?? false }
    set is_code_loop_on(_is_code_loop_on) { this._is_code_loop_on = _is_code_loop_on }

    // Whether we forward things to the world below
    get is_in_ewo_fw_mode() { return true }

    get screen_width() { return width() / this.zoom_level } // defined in common.js
    get screen_height() { return height() / this.zoom_level } // defined in common.js
    get screen_size_dict() { return { w: this.screen_width, h: this.screen_height } }

    get screen_soft_width() { return width() / this.soft_zoom_level }
    get screen_soft_height() { return height() / this.soft_zoom_level }
    get screen_soft_size_dict() { return { w: this.screen_soft_width, h: this.screen_soft_height } }

    get is_zen() { return false }

    get is_in_baw_edit() { return false }

    get zoom_multiplier() { // {?} ugly code
        const pow = Math.round(Math.log(this.zoom_level) / Math.log(2));
        let res = 1.0; 
        if (pow > 0) for (let i = 0; i < pow; i++) res /= 2;
        if (pow < 0) for (let i = 0; i < -pow; i++) res *= 2;
        return res;
    }

    get is_in_perspective_mode() { return kes.beats.meta >= this.beats_threshold }

    get front_ewo() { return this.cur_ewo } // overloaded in xeco

    get is_ega_menu_visible() { return this._is_ega_menu_visible ?? false }
    set is_ega_menu_visible(_is_ega_menu_visible) { this._is_ega_menu_visible = _is_ega_menu_visible; adj_elem_visibility(this.ega_menu_div, this._is_ega_menu_visible); }

    get_todo_bids() { return this.get_todo_ebus().map(ebu => ebu.bid) } // {?} very inefficient
    get_todo_ebus() { return this.ebus.filter(ebu => ebu.is_todo) } // {?} very inefficient

    get_egas_by_wid(wid) { return this.egas.filter(ega => ega.wids.indexOf(wid) != -1) } // {?} perhaps would be worth maintaining as a dictionary

    notarize(ebu) {
        const { bid, text } = ebu;
        const epoch = get_cur_epoch();
        if (bid in this.mod_times_by_bid) this.mod_times_by_bid[bid].push(epoch); 
        else this.mod_times_by_bid[bid] = [epoch];
        if (bid in this.text_mods_by_bid) this.text_mods_by_bid[bid].push(text);
        else this.text_mods_by_bid[bid] = [text];
    }

    normalize_gids() {
        this.gids = this.gids.filter(gid => gid in this.egas_by_gid); // remove the gids that don't correspont to an ega
        const missing_gids = Object.keys(this.egas_by_gid).filter(gid => this.gids.indexOf(gid) == -1);
        missing_gids.forEach(gid => this.gids.push(gid)); // add the gids that were not counted before
    }

    //////////////////////////////
    /// USER INTERFACE METHODS ///
    //////////////////////////////

    post_status(status) {
        this.status_queue.push(status);
        setTimeout(() => { this.status_queue.shift(0); this.refresh_status_lf(); }, this.status_display_time)
        this.refresh_status_lf();
    }

    ///////////////////////////////
    /// SERIALIZATION FUNCTIONS ///
    ///////////////////////////////

    to_dict() {
        const edata = { cur_wid: this.cur_wid, cur_gid: this.cur_gid, zoom_level: this.zoom_level, last_wids_by_gid: this.last_wids_by_gid };
        const dict = { edata, gids: this.gids, ewos_by_wid: {}, egas_by_gid: {}, ebus_by_bid: {}, elis_by_lid: {}, timestamps_by_gid: this.timestamps_by_gid ?? {} }; 
        // filters the non-trivial elements {?} a bit ugly
        for (const wid in this.ewos_by_wid) {
            const ewo = this.ewos_by_wid[wid]; if (ewo.ebus.length > 0) dict.ewos_by_wid[wid] = ewo.to_dict(); 
        }
        // filters the non-trivial elements {?} a bit ugly
        for (const gid in this.egas_by_gid) {
            const ega = this.egas_by_gid[gid]; if (ega.ewos.length > 0) dict.egas_by_gid[gid] = ega.to_dict();
        }
        for (const bid in this.ebus_by_bid) dict.ebus_by_bid[bid] = this.ebus_by_bid[bid].to_dict();
        for (const lid in this.elis_by_lid) dict.elis_by_lid[lid] = this.elis_by_lid[lid].to_dict();
        return dict;
    }

    from_dict(dict, overwrite=false) {
        let { ewos_by_wid, egas_by_gid, ebus_by_bid, elis_by_lid, edata, timestamps_by_gid, events_by_time, gids } = dict;
        egas_by_gid ??= dict.egas_by_gid; ewos_by_wid ??= dict.ewos_by_wid; 
        this.gids = (gids ?? []);

        for (const wid in ewos_by_wid ?? {}) sync_ewo_from_dict(this, ewos_by_wid[wid], overwrite); 
        for (const gid in egas_by_gid ?? {}) sync_ega_from_dict(this, egas_by_gid[gid], overwrite);
        for (const bid in ebus_by_bid ?? {}) sync_ebu_from_dict(this, ebus_by_bid[bid], overwrite);
        for (const lid in elis_by_lid ?? {}) sync_eli_from_dict(this, elis_by_lid[lid], overwrite);

        this.cleanup_egas();
        this.normalize_gids();
        const new_ewos_by_wid = {};

        [this.cur_wid, this.cur_gid, this.last_wids_by_gid] = [edata?.cur_wid, edata?.cur_gid, edata?.last_wids_by_gid ?? {}]; // {?} legacy

        if (this.cur_wid == undefined) this.cur_gid = first(this.gids); // {?} try to go to the first ega
        if (this.cur_wid == undefined) this.cur_wid = first(this.wids);

        this.zoom_level = edata?.zoom_level ?? 1.0;
        this.timestamps_by_gid = timestamps_by_gid ?? {};
    }

    to_html() { return this.div.innerHTML }

    from_history_dict(dict) {
        const { mod_times_by_bid, events_by_time } = dict ?? {};
        this.events_by_time = flex_merge_dicts(this.events_by_time, events_by_time);
    }

    to_history_dict() { return { mod_times_by_bid: this.mod_times_by_bid, events_by_time: this.events_by_time } }

    ////////////////////
    /// EDIT METHODS ///
    ////////////////////

    add_ewo(ewo) { if (ewo?.wid) this.ewos_by_wid[ewo.wid] = ewo; this.emap.reconstruct_soon(); return ewo }
    add_new_ewo(wid, name=undefined) { return this.add_new_ewo_from_dict({ wid, name: name ?? `ewo-${get_full_date()}` }) }
    add_new_ewo_from_dict(ewo_dict) { 
        const { wid } = ewo_dict; 
        if (wid in this.ewos_by_wid) this.remove_ewo_by_wid(wid);
        const ewo = this.add_ewo(new Ewo(this, ewo_dict)); return ewo; 
    }

    remove_ewo_by_wid(wid) { return this.remove_ewo(this.ewos_by_wid[wid]) }
    
    remove_ewo(ewo) {
        if (!ewo) return undefined;  
        this.egas.forEach(ega => ega.detach_ewo(ewo)); 
        ewo.destroy(); 
        delete this.ewos_by_wid[ewo.wid]; 
        this.emap.reconstruct_soon();
        return ewo; 
    }

    remove_ega(ega, is_deep=false) { // {?} seems to not be working
        if (!ega) return undefined; 
        const { gid } = ega;
        if (is_deep) ega.wids.forEach(wid => this.remove_ewo_by_wid(wid));
        delete this.egas_by_gid[gid];
        this.emap.reconstruct_soon();
        this.normalize_gids();
        return ega;
    }
    
    add_ega(ega) { if (ega.gid) this.egas_by_gid[ega.gid] = ega; if (this.gids.indexOf(ega.gid) == -1) this.gids.push(ega.gid); return ega }

    add_new_ega(gid, name=undefined) { return this.add_new_ega_from_dict({ gid, name: name ?? `ega-${get_full_date()}` }) }
    add_new_ega_from_dict(ega_dict) { return this.add_ega(new Ega(ega_dict)) }
    
    find_ega_by_name(ega_name) { for (const ega of this.egas) if (ega.name == ega_name) return ega; return undefined; }
    find_ewo_by_name(ewo_name, stay_within_cur_ega=false) {
        for (const ewo of (this.cur_ega?.ewos ?? [])) if (ewo.name == ewo_name) return ewo;
        if (stay_within_cur_ega) return undefined; // we didn't find in the current ewo
        for (const ewo of this.ewos) if (ewo.name == ewo_name) return ewo;
        return undefined;
    }

    cleanup_egas() { this.egas.forEach(ega => ega.cleanup_wids()) }

    get_blackboard_ega() { return this.find_ega_by_name(this.blackboard_ega_name) ?? this.make_blackboard_ega() }

    swap_gid(gid, dir) {
        const gid_index = this.gids.indexOf(gid); if (gid_index == -1) return;
        const swap_index = gid_index + dir;
        if (swap_index < 0 || swap_index >= this.gids.length) return;
        swap_entries(this.gids, gid_index, swap_index);
        this.emap.reconstruct_soon();
    }

    ////////////////////////
    /// MOTION FUNCTIONS ///
    ////////////////////////

    // {?} Add more flexibility
    nav_to_ewo_by_wid(wid) { if (wid in this.ewos_by_wid) this.cur_wid = wid; this.cur_gid = first(this.cur_ewo_gids); }
    nav_to_ewo_by_wid_with_gid(wid, gid) { if (gid in this.egas_by_gid) this.cur_gid = gid; if (wid in this.ewos_by_wid) this.cur_wid = wid;}

    nav_to_ewo(ewo_name) {
        const ewo = this.find_ewo_by_name(ewo_name);
        if (ewo?.wid != undefined) this.cur_wid = ewo.wid;
        else this.post_status(`Could not find ewo named ${ewo_name}`);         
    }
    nav_to_ega(ega_name) { 
        const ega = this.find_ega_by_name(ega_name); 
        if (ega?.gid != undefined) this.cur_gid = ega.gid; 
        else this.post_status(`Could not find ega named ${ega_name}`);         
    }
    nav_to_ega_by_gid(gid) { if (gid in this.egas_by_gid) this.cur_gid = gid; }
    // doesn't work with the xebubs
    move_to_see_ebu(ebu) { if (ebu.wid != this.cur_wid) this.nav_to_ewo_by_wid(ebu.wid); this.cur_ewo.move_to_see_ebu(ebu); }

    move_ewo_to_ega(ewo, ega) { 
        if (ewo?.wid == undefined || ega?.gid == undefined || ega.wids.indexOf(ewo.wid) != -1) return; 
        this.egas.forEach(ega => ega.detach_ewo(ewo)); ega.attach_ewo(ewo); this.nav_to_ewo_by_wid(ewo.wid); 
        this.post_status(`Moved ${ewo.name} to ${ega.name}`);
        this.evo_and_refresh_lf_soon();
    }

    /////////////////////////////
    /// EVO & REFRESH METHODS ///
    /////////////////////////////

    activate_hf_mode(hf_time_millis=5000) { this.is_in_hf_mode = true; }

    evo_hf(is_deep=true) { 
        this.emap.evo_hf(); if (is_deep) this.cur_ewo?.evo_hf(); 
        this.soft_status_height = adj_float(this.soft_status_height, this.status_height, 0.7);
    }
    
    evo_lf(is_deep=true) { this.emap.evo_lf(); if (is_deep) this.cur_ewo?.evo_lf(); }

    refresh_hf(is_deep=true, force=false) { // force means that we will run regardless of whether we are in hf mode
        // if (!this.is_in_hf_mode && !force) return; 
        if (this.should_evo_and_refresh_soon) { this.should_evo_and_refresh_soon = false; this.evo_lf(); this.refresh_lf(); } // {?} a little inelegant that evo_lf is run by refresh_lf
        this.emap.refresh_hf(); 
        this.helper.refresh_hf();
        if (is_deep) this.cur_ewo?.refresh_hf(); 

        const old_zoom_level = this.soft_zoom_level; // {?} Should be improved with a tracker
        this.soft_zoom_level = adj_float(this.soft_zoom_level, this.zoom_level);
        if (old_zoom_level != this.soft_zoom_level) document.body.style.zoom = this.soft_zoom_level;
        
        const { w, h } = this.screen_soft_size_dict;
        adj_elem(this.status_div, { x: 0, y: h - this.soft_status_height, w, h: this.soft_status_height }); 
    }

    refresh_lf(is_deep=true) {
        adj_elem(this.div, { bg: 'black', z: 10 });
        this.emap.refresh_lf();
        this.helper.refresh_lf();
        if (is_deep) this.cur_ewo?.refresh_lf();  
        this.refresh_hf(is_deep, true);
    }

    refresh_status_lf() {

        adj_elem_visibility(this.status_div, this.status_queue.length > 0);

        this.status_height = Math.min(this.status_queue.length, 10) * 20;
        this.status_div.innerHTML = this.status_queue.join('<br />');
    }


    // {?} the second refresh is a bit hacky
    evo_and_refresh_lf_soon() { this.should_evo_and_refresh_soon = true; this.number_of_timeouts++; }

    //////////////////////////////
    /// EXCHANGE EVENT METHODS ///
    //////////////////////////////

    // Now only used for debug purposes
    async on_check_agent_responses() {
        const message = await eapi.checkAgentResponses({ type: 'stdout' });
        if (message) { console.log(message); } return true;
    }

    /////////////////////
    /// EVENT METHODS ///
    /////////////////////

    async on_event(event, key_event) { // {?} Should integrate mouse events and others to this function
        this.activate_hf_mode(); // toggles the high refresh mode
        this.evo_and_refresh_lf_soon();

        if (event == 'toggle_helper') return this.on_toggle_helper();
        if (event == 'delete_ewo') return await this.on_remove_cur_ewo();
        if (event == 'delete_ega') return await this.on_remove_cur_ega(false);
        if (event == 'delete_ega_deep') return await this.on_remove_cur_ega(true);
        if (event == 'toggle_default_zoom') return this.on_toggle_default_zoom();
        if (event in this.zoom_facts_by_event) return this.on_zoom(this.zoom_facts_by_event[event]);
        if (event == 'zoom_canonical') return this.on_set_zoom(next_val_circ(this.zoom_canonical_vals, this.zoom_level));


        if (event == 'pick_ega') return this.on_pick_ega();
        if (event == 'next_ewo' || event == 'prev_ewo') return this.on_switch_cur_ewo(event == 'next_ewo' ? -1: +1);
        if (event == 'next_ewo_in_ega' || event == 'prev_ewo_in_ega') return this.on_switch_cur_ewo_in_ega(event == 'next_ewo_in_ega' ? -1: +1); 
        if (event == 'next_ega' || event == 'prev_ega') return this.on_switch_cur_ega(event == 'next_ega' ? -1: +1);
        if (event == 'toggle_ega_menu') return this.on_toggle_ega_menu(); // {?} perhaps to deprecate

        // {?} check if that poses problem re: the click capture
        if (this.emap?.on_event(event, key_event)) return; // forward to emap and stop if emap has returned true 

        if (this.is_in_ewo_fw_mode) {
            if (!this.is_in_baw_edit) return await this.cur_ewo?.on_event(event, key_event) ?? false;
        }
        else return true;
    }

    async on_wheel(wheel_event) { // {?} TO BE INTEGRATED WITHIN ONEVENT
        this.activate_hf_mode(); // toggles the high refresh mode
        if (this.is_in_ewo_fw_mode) return await this.front_ewo?.on_wheel(wheel_event)?? false; 
        else return true;
    }

    async on_mouse_up(mouse_event, mouse_state) { return true }
    async on_mouse_down(mouse_event, mouse_state) { return true }
    async on_mouse_move(mouse_event, mouse_state) { return true }
    async on_mouse_click(mouse_event, mouse_state) { return false }

    on_new_ewo(ega=undefined) { 
        this.emap.reconstruct_soon();  
        if (ega == undefined) ega = this.get_blackboard_ega();
        const wid = `w-${get_cur_epoch()}`; 
        const ewo_name = (!ega.is_blackboard) ? `${get_full_date()}` : `${get_full_date_with_time()}`;
        ega.wids.push(wid);
        const ewo = this.add_new_ewo(wid, ewo_name); this.cur_gid = ega.gid; this.cur_wid = wid;
        if (ega.tags?.length > 0) for (let i = 0; i < ega.tags.length; i++) ewo.tags.push(ega.tags[i]);
        this.post_status(`Created a new ewo with wid=${wid} in ega ${ega.name}`);
        this.post_status(`In the prompt (meta+Enter), type 'name [ewo_name]' to set the ewo's name`);
        return true; 
    } // {?} improve: wid shouldn't be here


    on_new_blackboard_ewo() { return this.on_new_ewo(undefined); }

    on_switch_cur_ewo(direction) { 
        this.cur_wid = move_in_arr_circular(this.wids, this.cur_wid, direction); 
        this.emap.ensure_cur_ega_is_vis(); return true; 
    }

    on_switch_cur_ewo_in_ega(direction) { this.cur_wid = move_in_arr_circular(this.cur_ega_wids, this.cur_wid, direction); return true; }

    on_zoom(factor) { if (this.is_default_zoom_on) return false; return this.on_set_zoom(this.zoom_level * factor); }
    on_set_zoom(zoom_level) { this.zoom_level = zoom_level;  this.adjust_zoom(); return true; }
    norm_zoom() { this.zoom_level = stick_to_arr(this.zoom_level, fractional_powers_of_two) } // in common.js
    adjust_zoom() { this.norm_zoom(); this.emap.reconstruct_soon(); this.helper.reconstruct_soon(); }


    make_blackboard_ega() { // {?} hacky... needed if there is no blackboard ega
        const gid = `xg-blackboard`; // {?} hacky... we also use the fact that it appears last
        const ega = this.add_new_ega(gid, this.blackboard_ega_name);
        this.emap.reconstruct_soon();
        return ega;
    }

    on_new_ega(name=undefined) { 
        const gid = `g-${get_cur_epoch()}`; 
        const ega = this.add_new_ega(gid, name);
        this.cur_gid = ega.gid;
        this.emap.reconstruct_soon();  
        if (name) this.post_status(`Created a new ega with gid=${gid} and name=${name}`);
        else this.post_status(`Created a new ega with gid=${gid}. In the prompt (meta+Enter), type 'ega [ega_name]' to set the ega's name`);
        return true; 
    } 

    on_switch_cur_ega(direction) {
        this.cur_gid = move_in_arr_circular(this.gids, this.cur_gid, direction); 
        this.emap.ensure_cur_ega_is_vis();
        this.post_status(`Moved to ega ${this.cur_ega?.name}. `);
        return true; 
    }

    // nav_to_ewo and nav_to_ega are defined in parent eco.js
    on_nav_to_ewo(ewo_name) { this.nav_to_ewo(ewo_name); this.emap.ensure_cur_ega_is_vis(); return true; }
    on_nav_to_ega(ega_name) { this.nav_to_ega(ega_name); this.emap.ensure_cur_ega_is_vis(); return true; }

    on_move_cur_ewo_to_ega(ega_name) {
        const [ewo, ega] = [this.cur_ewo, this.find_ega_by_name(ega_name)]; 
        if (ewo != undefined && ega != undefined) { this.move_ewo_to_ega(ewo, ega); return true; }
        return false;
    }

    on_toggle_ega_ewo() {  }

    on_remove_cur_ewo() { // {?} should be replaced by a method to delete an ewo, followed by something to check if the ewo was the current one
        if (this.num_ewos == 1) { this.post_status(`Cannot delete ewo if there is only one ewo`); return false; }
        const ewo = this.cur_ewo; if (!ewo) { this.post_status("Is not currently in an ewo"); return false; }
        this.post_status(`Trying to delete current ewo with wid=${ewo.wid} and name=${ewo.name}`);
        const old_wid = this.cur_wid, old_ewo_name = this.cur_ewo?.name; 
        this.remove_ewo_by_wid(old_wid);
        this.post_status(`Removed ewo with wid=[${old_wid}] and name=[${old_ewo_name}]`);
        this.cur_wid = move_in_arr_circular(this.cur_ega_wids.length > 0 ? this.cur_ega_wids : this.wids, old_wid);
        this.emap?.evo_and_refresh_lf_soon();
        return true;
    }

    on_remove_cur_ega(is_deep=false) {
        const cur_ewo = this.cur_ewo, cur_ega = this.cur_ega; if (cur_ega == undefined) return true;
        const { gid: old_gid, name: old_name } = cur_ega;
        this.remove_ega(cur_ega, is_deep);
        this.post_status(`Removed ega with gid=[${old_gid}] and name=[${old_name}] (is_deep=${is_deep})`);
        if (is_deep) this.cur_gid = move_in_arr_circular(this.gids, old_gid);
        else { this.cur_gid = undefined; this.cur_wid = cur_ewo?.wid; }
        this.emap?.evo_and_refresh_lf_soon();
        return true;
    }

    on_toggle_default_zoom() { this.is_default_zoom_on ^= true; this.post_status(this.is_default_zoom_on ? 'Using the default html zoom' : 'Using the smart zoom'); return true; }

    on_toggle_ega_menu() { this.is_ega_menu_visible ^= true; return true; }

    on_toggle_helper() {
        this.helper.is_visible ^= true;
    }    

    on_pick_ega() {
        const ega_name = prompt("Give a ega name"); // doesn't work for web c
        this.egaMove(ega_name); return true;
    }

}

