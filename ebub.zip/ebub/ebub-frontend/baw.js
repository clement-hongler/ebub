/////////////////////////////
/// Baw: background world ///
/////////////////////////////

class Baw {
	constructor(ewo, dict) { 
		this.ewo = ewo; 
		[this.z_rest, this.z_edit] = [-256, 256]; // the first in rest mode, the second in edit mode
		[this.b_rest, this.b_edit] = ['#00000000', '#22000088'];
		this.init_div(ewo);
		this.init();
	}


	init_div(ewo) {
		this.div = new_child_div(ewo.div, { x: 0, y: 0, wpc: 100, hpc: 100, z: this.cur_z, bg: this.cur_b });
	}  

	init() {
        this.bels_by_eid = {}; this.cur_eid = undefined;
	}

	//////////////////////
	/// ACCESS METHODS ///
	//////////////////////

	get eco() { return this.ewo.eco }

	get cur_z() { return this.eco.is_in_baw_edit ? this.z_edit : this.z_rest }
	get cur_b() { return this.eco.is_in_baw_edit ? this.b_edit : this.b_rest  }

	get obs_pos() { return this.ewo.obs_pos }
	set obs_pos(_obs_pos) { this.ewo.obs_pos = _obs_pos }

	get bels() { return Object.values(this.bels_by_eid) }

	get cur_bel() { return this.bels_by_eid[this.cur_eid] } // undefined is fine
	set cur_bel(cur_bel) { this.cur_eid = cur_bel?.eid; }


	///////////////////
	/// EVO METHODS ///
	///////////////////

	evo_hf() { this.bels.forEach(bel => bel.evo_hf()) }
	evo_lf() { this.bels.forEach(bel => bel.evo_lf())}

	refresh_hf() { this.bels.forEach(bel => bel.refresh_hf()) }

	refresh_lf() { adj_elem(this.div, { z: this.cur_z, bg: this.cur_b }); this.bels.forEach(bel => bel.refresh_lf()); }

	evo_and_refresh_lf() { this.evo_lf(); this.refresh_lf(); }

	add_bel(bel) {  this.bels_by_eid[bel.eid] = bel; return bel; }

	add_new_bel_from_dict(dict) {
		switch (dict?.type) {
			case 'fra_bel': return this.add_bel(new FraBel(this, dict)); 
		}
		return undefined; 
	}

	remove_bel(bel) { 
		if (bel) bel.destroy(); 
		delete this.bels_by_eid[bel.eid];
		if (this.cur_bel == bel) this.cur_bel = undefined; 
	}

	get_intersecting_bels(mouse_rect_dict) { 
		const intersecting_bels = [];
		for (const bel of this.bels) {
			const bel_abs_screen_rect = this.ewo.abs_to_screen_rect(bel.rect_dict);
			if (rect_dict_intersection_area(mouse_rect_dict, bel_abs_screen_rect) > 0) intersecting_bels.push(bel);
		}
		return intersecting_bels;
	}

	get_intersecting_bels_from_abs_rect_dict(abs_rect_dict) { return this.bels.filter(bel => rect_dict_intersection_area(abs_rect_dict, bel.rect_dict)) }

	get_intersecting_bels_from_ebus(ebus) { return rem_dupes(flex_flatten(ebus.map(ebu => this.get_intersecting_bels_from_abs_rect_dict(ebu.rect_dict)))) }

	//////////////////////
	/// EVENT HANDLERS ///
	//////////////////////

	// {?} this whole thing should be cleaned up, with context-dependent events and a centralization of their handling
	on_event(event, key_event) {
		if (event == 'new_ebu') return this.on_new_fra_bel(); 
		if (event == 'delete_ebu') return this.on_remove_cur_bel(); 
		if (event == 'toggle_red_focus') return this.on_toggle_cur_bel();
		if (this.cur_bel) return this.cur_bel.on_event(event, key_event);
		return false;
	}

	on_mouse_up(mouse_event, mouse_state) { return this.on_select_cur_bel_in_rect(mouse_state.sel_rect); }
	on_mouse_down(mouse_event, mouse_state) {}
	on_mouse_move(mouse_event, mouse_state) {}
	on_mouse_click(mouse_event, mouse_state) {
		const { x, y } = mouse_state.last_click;
		return this.on_select_cur_bel_in_rect({ x: x - 1, y: y - 1, w: 2, h: 2 });
	}
	on_new_fra_bel() { 
		let { x, y } = this.obs_pos;
        [x, y] = [next_mult_round(x, 32), next_mult_round(y, 32)];
        const eid = `e-${get_unique_id()}`;
		this.cur_bel = this.add_new_bel_from_dict({ eid, type: 'fra_bel', x, y, w: 256, h: 256, is_locked: false }); 
		return true; 
	}

	on_remove_cur_bel() { this.remove_bel(this.cur_bel); return true; }

	on_toggle_cur_bel() {
		if (this.cur_bel) this.cur_bel = undefined;
		return true;
	}

	on_select_cur_bel_in_rect(mouse_rect_dict) {
		const intersecting_bels = this.get_intersecting_bels(mouse_rect_dict);
        this.cur_bel = next_val_circ(intersecting_bels, this.cur_bel);
        this.evo_and_refresh_lf();
        return true;
	}

	to_dict() { 
		const bels_by_eid = {};
		for (const eid in this.bels_by_eid) bels_by_eid[eid] = this.bels_by_eid[eid].to_dict();
		return { bels_by_eid } 
	}

	from_dict(dict) {
		this.bels_by_eid = {};
		for (const eid in (dict.bels_by_eid ?? {})) this.add_new_bel_from_dict(dict.bels_by_eid[eid]);
	}
}

///////////////////////////////////////////////////////
// To add: fra bel
// 