// {?} This whole file is quite hacky, it would be nice to improve

const html_preamble = '<!DOCTYPE html>';
const include_katex_css_code = '<link rel="stylesheet" href="katex/katex.css" />';
const meta_charset_line = '<meta charset="UTF-8">';
const meta_viewport_line = '<meta name="viewport" content="width=device-width, initial-scale=0.7">';
const meta_head = meta_charset_line + '\n' + meta_viewport_line;
const ewo_style_code = // {?} deprecated
'body { background-color: black; color: white; font-family: Courier; font-size: 13pt; }' + '\n' +
'div#world_div { left: 32px; top: 32px; position: absolute } ';
const scrolldown_script_code = 'window.onload = () => { window.scrollTo(0, document.body.scrollHeight + 100) };';
const alink_style_code = 'a { color: yellow; text-decoration: none; }\na:hover{ color: red; text-decoration: none; }\na:visited { color: yellow; text-decoration: none; }\na:active { color: red; text-decoration: none; }';
const head_style_code = 'h1 { color: white; text-decoration: none; font-size: 16pt; margin-left: 16px }';
