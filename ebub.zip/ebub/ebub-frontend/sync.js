/////////////////////////////////////////////////////////////////////////////
/// USED TO IMPORY, EXPORT, SERIALIZE, SYNCHRONIZZE, AND CONVERT BUB DATA ///
/////////////////////////////////////////////////////////////////////////////



/////////////
/// UTILS ///
/////////////

function is_ega_dict(dict) { return dict?.gid != undefined }
function is_ewo_dict(dict) { return dict?.wid != undefined }
function cut_before(s, index) { return index >= 0 ? s.substring(0, index) : s } // {?} change name
function remove_last_ext(file_path) { return cut_before(file_path, file_path.lastIndexOf('.')) }
function get_companion_media_dir(file_path) { return path.join(path.dirname(file_path), 'media'); }

///////////////////////////////
/// JSON SERIALIZATION SYNC ///
///////////////////////////////

function sync_ewo_from_dict(eco, ewo_dict, overwrite=false) {
    let { wid, ebus_by_bid } = ewo_dict; 
    ebus_by_bid ??= ewo_dict.bubs_by_bid; ebus_by_bid ??= ewo_dict.ebus_by_bid; // {?} legacy

    if (!all_defined(wid)) { console.log(`sync_ewo_from_dict error: ${ewo_dict}`); return; }
    if (overwrite || !(wid in eco.ewos_by_wid)) eco.add_new_ewo_from_dict(ewo_dict);
    else eco.ewos_by_wid[wid].from_dict(ewo_dict, overwrite); 
    return eco.ewos_by_wid[wid];
}

function sync_ega_from_dict(eco, ega_dict, overwrite=false) {
    const { gid } = ega_dict ?? {}; // {?}
    if (!all_defined(gid)) { console.log(`Invalid ${ega_dict}`); return; }
    if (overwrite || !(gid in eco.egas_by_gid)) eco.add_new_ega_from_dict(ega_dict);
    else eco.egas_by_gid[gid].from_dict(ega_dict);
    const ewo_dicts = Object.values(ega_dict.ewos_by_wid ?? {});
    for (const ewo_dict of ewo_dicts) sync_ewo_from_dict(eco, ewo_dict, overwrite)
    return eco.egas_by_gid[gid];
}

function sync_ebu_from_dict(eco, ebu_dict, overwrite=false) {
    const { bid, wid } = ebu_dict.metadata; 
    if (bid == undefined || wid == undefined) { console.log(`Ebu has no bid or wid in metadata`); return; }
    const ewo = eco.ewos_by_wid[wid]; 
    if (ewo == undefined) { console.log(`Cannot find the ewo for this ebu`); return; }
    ewo.add_new_ebu_from_dict(ebu_dict, overwrite);
}

function sync_eli_from_dict(eco, eli_dict, overwrite=false) {
    const { lid, wid } = eli_dict; 
    if (lid == undefined || wid == undefined) { console.log(`Eli has no lid or wid in metadata`); return; }
    const ewo = eco.ewos_by_wid[wid]; 
    if (ewo == undefined) { console.log(`Cannot find the ewo for this eli`); return; }
    ewo.add_new_eli_from_dict(eli_dict, overwrite);
}


/////////////////
/// HTML SYNC ///
/////////////////


// {?} the innerHTML contains the outerHTML of the children, which is not really needed and which should be cleaned up
function ebu_to_html(ebu) { 
    if (ebu.is_media_ebu) return media_ebu_to_html(ebu)
    else return `<div id='${lower_hyphens(ebu.bid)}'>${ebu.div.innerHTML}</div>`;
}

function media_ebu_to_html(ebu) { // {?} very hacky
    const media_child = last(ebu.div.children); // {?} very hacky
    const old_media_src = ebu.source;
    const media_file_name = path.basename(old_media_src);
    const new_media_src = `media/${media_file_name}`;
    let res = `<div id='${lower_hyphens(ebu.bid)}'>${ebu.div.innerHTML}</div>`;
    res = res.replace(`src="${old_media_src}"`, `src="${new_media_src}"`); // {?} super hacky
    console.log(res);
    return res;
}

function ebu_to_css(ebu, origin=undefined) { 
    const property_dict = style_to_property_dict(ebu.div.style);
     // {?} hacky, though it clearly reduces the output size (should be generalized into something that removes what is obvious and redundant)
    if (property_dict['font-size'] == '1em') delete property_dict['font-size'];
    property_dict.display = 'block';
    if (origin != undefined) {
        const { x: ox, y: oy } = origin;
        let [x, y] = [ebu.x - ox, ebu.y - oy]; //[parseInt(property_dict.left) - ox, parseInt(property_dict.top) - oy];
        if (x >= 0 && y >= 0) [property_dict.left, property_dict.top] = [`${x}px`, `${y}px`];
        else property_dict.display = 'none';
    }
    [property_dict.width, property_dict.height] = [`${ebu.w}px`, `${ebu.h}px`];
    if (ebu.bid == 'b-1713958063864') { console.log(property_dict); console.log(ebu.div.children[ebu.div.children.length - 1]); }
    return `div#${lower_hyphens(ebu.bid)} ` + dict_to_css(property_dict); 
}

function bel_to_html(bel) { return `<div id='${lower_hyphens(bel.eid)}'>${bel.div.innerHTML}</div>`; }

function bel_to_css(bel, origin=undefined) {
    bel.refresh_lf(); // {?} to clean up 
    const property_dict = style_to_property_dict(bel.div.style);
    property_dict.display = 'block';
    if (origin != undefined) {
        const { x: ox, y: oy } = origin;
        let [x, y] = [bel.x - ox, bel.y - oy]; //[parseInt(property_dict.left) - ox, parseInt(property_dict.top) - oy];
        if (x >= 0 && y >= 0) [property_dict.left, property_dict.top] = [`${x}px`, `${y}px`];
        else property_dict.display = 'none';
    }
    return `div#${lower_hyphens(bel.eid)} ` + dict_to_css(property_dict); 
}

function eli_to_html(eli) { 
    let { w, h } = eli.comp_abs_link_rect();
    w += 32; h += 32; // {?} hacky
    return `<svg id='${lower_hyphens(eli.lid)}' width='${w}' height='${h}'>${eli.svg_link.svg_node.innerHTML}</svg>`; 
}

function eli_to_css(eli, origin=undefined) {
    const property_dict = style_to_property_dict(eli.svg_link.svg_node.style);
    property_dict.display = 'block';
    if (origin != undefined) {
        const { x: ox, y: oy } = origin;
        const { x: elix, y: eliy } = eli.comp_abs_link_rect();
        let [x, y] = [elix - ox, eliy - oy]; //[parseInt(property_dict.left) - ox, parseInt(property_dict.top) - oy];
        if (x >= 0 && y >= 0) [property_dict.left, property_dict.top] = [`${x}px`, `${y}px`];
        else property_dict.display = 'none';
    }
    return `#${lower_hyphens(eli.lid)} ` + dict_to_css(property_dict); 
}

//function ebu_to_css(ebu) { return `div#${lower_hyphens(ebu.bid)} { left: ${ebu.x}px; top: ${ebu.y}px; width: ${ebu.w}px; height: ${ebu.h}px; position: absolute; }`; }

function ewo_to_html(ewo, { media_dir, use_selection=false, origin=undefined, add_auto_scroll_bottom=false, ega_menu_div=undefined }) { // {?} still a bit hacky
    const ebus = (!use_selection) ? ewo.ebus : [... ewo.selection_bids].map(bid => ewo.ebus_by_bid[bid]);
    const bels = (!use_selection) ? ewo.bels : ewo.bels.filter(bel => ebus.some(ebu => bel.intersects_ebu(ebu)));
    const elis = (!use_selection) ? ewo.elis : ewo.elis.filter(eli => ebus.indexOf(eli.ori_ebu) != -1 && ebus.indexOf(eli.des_ebu) != -1);
    const old_selection_bids = ewo.selection_bids;
    ewo.selection_bids = new Set([]); ewo.evo_lf(); ewo.refresh_lf(); // {?} hacky
    const [x_corner, y_corner] = [Math.min(... ebus.map(ebu => ebu.x)), Math.min(... ebus.map(ebu => ebu.y))];
    if (!origin) origin = { x: 0, y: 0 };
    let div_html = ebus.map(ebu => ebu_to_html(ebu)).join('\n'); 
    div_html += '\n' + bels.map(bel => bel_to_html(bel)).join('\n');
    div_html += '\n' + elis.map(eli => eli_to_html(eli)).join('\n');
    div_html += '\n' + `<div id="bottom_div">.</div>`;
    const ebu_style = JSON.stringify(ebu_padding_dict).replaceAll(',', 'px;') // {?} very hacky
    let style_css = `body ` + style_to_css(eco.div.style) + '\n';
    style_css += '\n' + alink_style_code + '\n' + head_style_code;
    style_css += `div#world_div ` + style_to_css(ewo.div.style) + '\n'; 
    style_css += `div#bottom_div { top: ${ewo.bottom + 320}px; left: 0px; position: absolute; color: black; }` + '\n';
    if (ega_menu_div) style_css += `div#ega_menu_div ` + style_to_css(ega_menu_div.style);
    // + `div.ebu ${ebu_style}` + '\n' // {?} should be re-instated in a way or another
    style_css += '\n' + ebus.map(ebu => ebu_to_css(ebu, origin)).join('\n');
    style_css += '\n' + bels.map(bel => bel_to_css(bel, origin)).join('\n');
    style_css += '\n' + elis.map(eli => eli_to_css(eli, origin)).join('\n');

    let head = meta_head 
    head += '\n' + `<title>${ewo.name}</title>`;
    if (ewo.needs_tex) head += '\n' + include_katex_css_code;
    head += '\n' + wrap_in_tag('style', style_css, 1);

    let body = `<div id="world_div">\n${div_html}\n</div>\n`;
    if (ega_menu_div) body += `<div id="ega_menu_div">${ega_menu_div.innerHTML}</div>`;
    if (add_auto_scroll_bottom) body +=  `<script>\n${scrolldown_script_code}\n</script>`;
    const html = wrap_dict_to_html({ head, body }, 1);

    ewo.selection_bids = old_selection_bids; ewo.evo_lf(); ewo.refresh_lf(); 


    return html;
}

function ega_menu_to_html(ega_menu_div, ega_name) { 
    let style_css = `body ` + style_to_css(eco.div.style) + '\n';
    style_css += '\n' + alink_style_code + '\n' + head_style_code;
    const head = meta_head + '\n' + wrap_in_tag('style', style_css, 1);
    const body = '<div>' + wrap_in_tag('h1', ega_name) + '</div>' + '\n' + '<div>' + ega_menu_div.innerHTML + '</div>';
    return wrap_dict_to_html({ head, body }); 
}

function redirection_html(redirection_target) {
    return wrap_dict_to_html({ head: `<meta http-equiv="refresh" content="0; url=${redirection_target}">`, body: `` });
}

async function on_export_ewo_to_html(eco, use_selection=false) {
    const cur_ewo = eco.cur_ewo; if (!cur_ewo) return false;

    const cur_ewo_name = cur_ewo.name ?? cur_ewo.wid; 
    const default_file_name = `${cur_ewo_name}_${get_full_date()}.html`;


    const { canceled, file_path } = await eapi.request_file_to_save({ dialog_title: `Export selection to`, file_extension: '.html', default_file_name });;
    if (canceled || !file_path) { eco.post_status(`Export canceled`); return true; }

    const media_dir = get_companion_media_dir(file_path);
    const data = ewo_to_html(cur_ewo, { media_dir, use_selection });
    // {?} will need to make sure that if there are media, we ensure the media dir exists

    const result = await eapi.save({ file_path, data }); 
    console.log(`World exported to ${file_path}: ${result}`);
}


let last_export_dir = undefined; // {?} TEMPORARY, SHOULD BE UNIFORMLY HANDLED AND SERIALIZED

async function on_export_ega_to_html(eco, activate_timestamping=true, export_to_json=true) {
    const cur_ega = eco.cur_ega; if (!cur_ega) return false;
    // {?} NEED TO ADD CODE TO SELECT TARGET DIR
    const results_by_ewo_name = {};
    const target_dir = await eapi.request_select_dir({ dialog_title: "Please choose a target dir:", default_path: last_export_dir }); // {?} would be good to a nice default dir
    if (target_dir == undefined) return;
    last_export_dir = target_dir; // {?} temporary code
    const num_media_ebus = num_media_in_ega(cur_ega);
    const media_dir = path.join(target_dir, 'media'); // {?} path.join is in common.js and needs to be properly initialized  
    if (num_media_ebus > 0) {
        const result = await eapi.ensure_dir_exists({ dir: media_dir }); 
        if (!result) eco.post_status(`Failed to create ${media_dir}`); 
    }

    let ega_menu_div = new_div();
    fill_ega_menu_div(cur_ega, ega_menu_div);
    let origin = { x : -32, y: -(parseInt(ega_menu_div.style.height) + 64) };
    // origin = undefined;

    for (const ewo of cur_ega.ewos) {
        const ewo_name = ewo.name ?? ewo.wid;
        const file_name = ewo_name + '.html';
        const file_path = path.join(target_dir, file_name); // {?} path.join is in common.js and needs to be properly initialized  
        const original_media_sources_by_bid = {};
        for (const media_ebu of ewo.media_ebus) {
            const media_source_file_path = media_ebu.source;
            if (media_source_file_path?.length == 0) { console.log(`Media ebu with bid=${media_ebu.bid} does not have a source`); continue; }
            original_media_sources_by_bid[media_ebu.bid] = media_ebu.media_source;
            const media_file_name = path.basename(media_source_file_path);
            const media_dest_file_path = path.join(media_dir, media_file_name);
//            media_ebu.source = `media/${media_file_name}`;
            await eapi.copy_file({ source_path: media_source_file_path, dest_path: media_dest_file_path });
        }

        const data = ewo_to_html(ewo, { media_dir, ega_menu_div, origin }); 
        results_by_ewo_name[ewo_name] = await eapi.save({ file_path, data });
        // restore the original media source
    }
    const index_file_path = path.join(target_dir, 'index.html');

    const ega_menu = ega_menu_to_html(ega_menu_div, cur_ega.name);

    let index_file_data = ega_menu; // {?} hacky... by default we have a menu, but 
    if (cur_ega.main_wid != undefined) {
        const main_ewo_name = eco.ewos_by_wid[cur_ega.main_wid].name; 
        index_file_data = redirection_html(main_ewo_name + '.html');
    }

    await eapi.save({ file_path: index_file_path, data: index_file_data});

    if (cur_ega.ewos.some(ewo => ewo.needs_tex)) await export_katex_to_dir(target_dir);

    const successes = Object.keys(results_by_ewo_name).filter(name => results_by_ewo_name[name]);
    const failures = Object.keys(results_by_ewo_name).filter(name => !results_by_ewo_name[name]); 
    if (successes.length > 0) eco.post_status(`Export to ${successes.join(' ')} successful`);
    if (failures.length > 0) eco.post_status(`Export to ${failures.join(' ')} failed`); 

    if (export_to_json) {
        const json_file_name = `archive.json`;
        const json_file_path = path.join(target_dir, json_file_name);
        await sync_ega_to_json_file(cur_ega, json_file_path);
    }


    if (activate_timestamping) { // we save an archive both in the ega folder and in the proofs // {?} hacky 
        const timestamp_dir_path = path.join(target_dir, 'timestamp');
        const { html_proofs_dir_path } = get_timestamp_dirs();
        const { html_proof } = await get_string_timestamps(JSON.stringify(cur_ega.to_dict(true)));

        const cur_proof_file_name = `${cur_ega.name}-${get_full_date_with_time()}-timestamp.html`; 
        const archive_file_name = `ega-${cur_ega.name}-${get_full_date_with_time()}.html`;
        const cur_proof_file_path = path.join(timestamp_dir_path, cur_proof_file_name);
        const archive_file_path = path.join(html_proofs_dir_path, archive_file_name);
        await eapi.ensure_dir_exists( { dir: timestamp_dir_path });
        await eapi.ensure_dir_exists( { dir: html_proofs_dir_path });

        await eapi.save({ file_path: cur_proof_file_path, data: html_proof });
        await eapi.save({ file_path: archive_file_path, data: html_proof });
        eco.post_status(`Timestamp proof posted`);
    }
}

async function export_katex_to_dir(dir) {
    const source_path = path.join(path.app_dir, 'ebub-external-libs', 'katex');
    const dest_path = path.join(dir, 'katex');
    await eapi.ensure_dir_exists( { dir: dest_path });
    await eapi.copy_dir({ source_path, dest_path });
}



/////////////////
/// JSON SYNC ///
/////////////////

 async function on_sync_cur_ewo_to_json_file(eco) {
    const cur_ewo = eco.cur_ewo; if (!cur_ewo) return true; 
    const default_file_name = `ebub-ewo-${cur_ewo.name ?? cur_ewo.wid}-${get_full_date()}.json`;
    console.log(default_file_name);
     const { canceled, file_path } = await eapi.request_file_to_save({dialog_title: 'Export world to', file_extension: '.json', default_file_name });
    
    if (canceled || !file_path) { eco.post_status(`Export canceled`); return true; }
    const data = JSON.stringify(cur_ewo.to_dict(true)); // is_deep: true
    const res = await eapi.save({ file_path, data }); 
    console.log(num_media_in_ewo(cur_ewo) + " media in cur_ewo");
    if (num_media_in_ewo(cur_ewo) > 0) { await copy_ewo_media_to_dir(cur_ewo, get_companion_media_dir(file_path)); }
    return true;
}   

async function on_sync_cur_ega_to_json_file(eco) {
    const cur_ega = eco.cur_ega; if (cur_ega == undefined) { eco.post_status(`Current ega not defined.`); return true; }
    const default_file_name = `ebub-ega-${(cur_ega.name ?? cur_ega.gid)}-${get_full_date()}.json`;    // {?} To generalize with a browser-friendly variant
    const { canceled, file_path } = await eapi.request_file_to_save({ dialog_title: `Export ega to`, file_extension: '.json', default_file_name });
    if (canceled || !file_path) { eco.post_status(`Export canceled`); return true; }
    await sync_ega_to_json_file(cur_ega, file_path);
    return true;
}

async function sync_ega_to_json_file(ega, file_path) {
    const data = JSON.stringify(ega.to_dict(true, true)); // is_deep: true, addTimestamp: true
    const res = await eapi.save({ file_path, data });
    eco.post_status(res);
    if (num_media_in_ega(ega) > 0) { await copy_ega_media_to_dir(ega, get_companion_media_dir(file_path)); }
}

/////////////////
/// TEXT SYNC ///
/////////////////

async function on_export_cur_ewo_to_md_text(eco) {
    const cur_ewo = eco.cur_ewo; if (!cur_ewo) return false;
    const bids = [... cur_ewo.selection_bids]; 
    const ebus = bids.map(bid => cur_ewo.ebus_by_bid[bid]);
    const text = ebus.map(ebu => ebu.markdown_text).join('\n\n');

    const cur_ewo_name = 'world' + (cur_ewo.name ? '-' + cur_ewo.name : ''); 
    const default_file_name = `${cur_ewo_name}_${get_full_date()}.txt`;

    const { canceled, file_path } = await eapi.request_file_to_save({ dialog_title: `Export selection to`, file_extension: '.txt', default_file_name });;
    if (canceled || !file_path) { eco.post_status(`Export canceled`); return true; }

    const result = await eapi.save({ file_path, data: text }); 
    console.log(`World exported to ${file_path}: ${result}`);

    return true;
}

/////////////////////
/// IMAGE UTILITY ///
/////////////////////

function num_media_in_ewo(ewo) { return ewo.media_ebus?.length ?? 0 }
function num_media_in_ega(ega) { return sum(ega.ewos.map(ewo => num_media_in_ewo(ewo))) } // defined in common.js // {?} clean up 

async function copy_ewo_media_to_dir(ewo, media_target_dir) {
    const res = await eapi.ensure_dir_exists({ dir: media_target_dir }); if (!res) return eco.post_status(`Could not create directory ${media_target_dir} to store media`);
    for (const media_ebu of ewo.media_ebus) {
        const media_source_file_path = media_ebu.source;
        const media_file_name = path.basename(media_source_file_path);
        const media_dest_file_path = path.join(media_target_dir, media_file_name);
        await eapi.copy_file({ source_path: media_source_file_path, dest_path: media_dest_file_path });
    }
}

async function copy_ega_media_to_dir(ega, media_target_dir) { for (const ewo of ega.ewos) await copy_ewo_media_to_dir(ewo, media_target_dir) }

////////////////////
/// EWO/GAL LOAD ///
////////////////////

async function on_smart_load(eco, overwrite=false) {
    const dialog_title = `Pick file to sync from (overwrite=${overwrite})`;
    const { canceled, file_paths } = await eapi.request_file_to_open({ dialog_title });
    for (const file_path of file_paths) {
        const media_dir_path = get_companion_media_dir(file_path); // if needed
        const data = await eapi.load({ file_path }); // {?} To generalize with a browser-friendly variant
        const dict = JSON.parse(data); 
        const [is_ewo, is_ega] = [is_ewo_dict(dict), is_ega_dict(dict)];
        let [ewo, ega] = [undefined, undefined];
        if (is_ewo) { ewo = sync_ewo_from_dict(eco, dict); eco.post_status(`Loaded ewo from ${file_path}`); eco.cur_wid = ewo.wid; }
        if (is_ega) { ega = sync_ega_from_dict(eco, dict); eco.post_status(`Loaded ega from ${file_path}`); eco.cur_gid = ega.gid; }
        if ((is_ewo || is_ega) && await eapi.is_dir_existing({ file_path: media_dir_path })) {
            const media_ebus = is_ewo ? ewo.media_ebus : flex_flatten(ega.ewos.map(ewo => ewo.media_ebus));
            for (const ebu of media_ebus) {
                const media_name = path.basename(ebu.media_source);
                const source_path = path.join(media_dir_path, media_name);
                const dest_path = path.join(path.media_dir, media_name);
                const res = await eapi.copy_file( { source_path, dest_path });
                if (res?.status == 'Success') ebu.media_source = dest_path;
            }
            ewo.media_ebus.forEach(ebu => {  });
            eco.post_status(`Copied media from ${media_dir_path} and adjusted ${ewo.media_ebus.length} media sources`);
        }
    }
}


// {?} Should be moved to sync.js
async function on_load_eco(eco) {
    try {
        const file_path = eco.file_path;
        if (!(await eapi.is_file_existing({ file_path }))) { 
            eco.post_status(`Could not load eco from ${file_path}. Using a blank world instead`); 
            await on_add_help_ega(eco); // in helper.hs
            return false; 
        }
        const file_string = await eapi.load({ file_path });
        const file_dict = JSON.parse(file_string);
        eco.from_dict(file_dict); // string -> dict -> [build]
        eco.post_status(`Loaded eco from ${file_path} with ${eco.num_ebus} ebus`);
        if (eco.num_ewos == 0) await on_add_help_ega(eco); // if there is no world, we will add one so that we're ready to work
        await on_load_eco_history(eco);
        return true;
    }
    catch (err) { console.log("Error while loading eco:", err); throw err; return false; }
}

async function on_load_eco_history(eco) {
    const file_path = cur_eco_history_file_path;
    if (!(await eapi.is_file_existing({ file_path }))) { 
        eco.post_status(`Could not load eco history from ${file_path}`); 
        return false; 
    }
    const file_string = await eapi.load({ file_path });
    const history_dict = JSON.parse(file_string);
    eco.from_history_dict(history_dict);
}

//////////////////////
/// SAVE FUNCTIONS ///
//////////////////////


async function on_save_eco(xeco) {
    const result = await eapi.save({ file_path: xeco.file_path, data: JSON.stringify(xeco.to_dict()) }); // dict->string->save
    xeco.post_status(result); 
    await save_history(xeco);
    await save_all_codes(xeco);
    return true;
} 

// {?} Should be moved to index.js or sync.js
async function on_save_snapshot_copy(xeco) {
    const full_date = get_full_date_with_time();

    const snapshots_dir_name = 'snapshots';
    const snapshots_dir_path = path.join(path.data_dir, snapshots_dir_name);

    const snapshot_file_name = `ebub-data-${full_date}.json`;
    const snapshot_file_path = path.join(snapshots_dir_path, snapshot_file_name);

    await eapi.ensure_dir_exists(snapshots_dir_path);

    const result = await eapi.save({ file_path: snapshot_file_path, data: JSON.stringify(xeco.to_dict()) }); // dict->string->save
    xeco.post_status(result); await save_all_codes(xeco);
    return true;
}

async function save_all_codes(xeco) { for (const ega of xeco.egas) await save_ega_codes(xeco, ega) }

async function save_ega_codes(xeco, ega) { if (ega?.name?.length > 0) for (const ewo of ega.ewos) await save_ewo_code(xeco, ewo, ega.name) }

async function save_ewo_code(xeco, ewo, ega_name) {
    const code = ewo?.get_active_code(), name = ewo?.name;
    if (code?.length == 0 || name == undefined) return;
    const file_path =  path.join(path.data_dir, 'codes', ega_name, name + '.py'); // {?} hacky but says what we want
    const result = await eapi.save({ file_path, data: code }); 
}

async function save_history(xeco) {
    const result = await eapi.save({ file_path: cur_eco_history_file_path, data: JSON.stringify(xeco.to_history_dict()) }); // dict->string->save
}

async function load_history(xeco) {
    const history_string = await eapi.save({ file_path: cur_eco_history_file_path });
    const history_dict = JSON.stringify(history_string);
    xeco.from_history_dict(history_dict);
}

//////////////////////////////
/// TIMESTAMPING UTILITIES ///
//////////////////////////////

function get_timestamp_dirs() { // also used above for the ega export {?} inelegant
    const timestamp_dir_path = path.join(path.data_dir, 'timestamps');
    const text_proofs_dir_path = path.join(timestamp_dir_path, 'text-proofs');
    const html_proofs_dir_path = path.join(timestamp_dir_path, 'html-proofs');
    const html_claims_dir_path = path.join(timestamp_dir_path, 'html-claims');
    return { timestamp_dir_path, text_proofs_dir_path, html_proofs_dir_path, html_claims_dir_path };
}

async function on_timestamp_red_ebu(xeco, is_lean=true) { 
    const red_ebu = xeco.red_ebu;
    if (red_ebu == undefined) xeco.post_status('Select a red_ebu prior to timestamping');
    if (is_lean) await timestamp_string(red_ebu.text + ` [${get_full_date_with_time()}]`, 'bub');
    else await timestamp_data(xeco.red_ebu?.to_dict(), 'ebu') 
}

async function on_timestamp_selection(xeco) { await timestamp_data(xeco.selection_ebus.map(ebu => ebu.to_dict()), 'ebus') }

async function on_timestamp_cur_ewo(xeco) { await timestamp_data(xeco.cur_ewo?.to_dict(true), 'ewo') }

async function on_timestamp_cur_ega(xeco) { await timestamp_data(xeco.cur_ega?.to_dict(true), 'ega') }

// data is either a dict or an array (something cleanly serializable)
async function timestamp_data(data, label) { timestamp_string(data ? JSON.stringify(data) : '', label) }

async function get_string_timestamps(data) {
    const string_hash = await sha_256_async(data);
    const pow_salt = await find_pow_salt(string_hash);
    const witness_string = `${string_hash}:${pow_salt}`;
    const text_proof = 'EBUB-TIMESTAMP' + '\n' + data + '\n' + witness_string;   
    const html_proof = wrap_witness_sender({ witness_string, data, timestamp_server });
    const html_claim = wrap_witness_sender({ witness_string, timestamp_server }); // {?} timestamp_server is in index.js for now
    return { text_proof, html_proof, html_claim };
}

async function timestamp_string(string, label) {
    if (!string) { console.log('Empty string: did not timestamp'); return; }
    const { text_proof, html_proof, html_claim } = await get_string_timestamps(string);
    const date_string = get_full_date_with_time();
    const timestamp_file_name = `timestamp-${label}-${date_string}.txt`;
    const { timestamp_dir_path, text_proofs_dir_path, html_proofs_dir_path, html_claims_dir_path } = get_timestamp_dirs();

    for (let path of [timestamp_dir_path, text_proofs_dir_path, html_proofs_dir_path, html_claims_dir_path]) {
        await eapi.ensure_dir_exists(path);
    }

    const text_proof_file_name = `${label}-${date_string}-proof.text`;
    const html_proof_file_name = `${label}-${date_string}-proof.html`;
    const html_claim_file_name = `${label}-${date_string}-claim.html`;

    const text_proof_file_path = path.join(text_proofs_dir_path, text_proof_file_name);
    const html_proof_file_path = path.join(html_proofs_dir_path, html_proof_file_name);
    const html_claim_file_path = path.join(html_claims_dir_path, html_claim_file_name);

    await eapi.save({ file_path: text_proof_file_path, data: text_proof });
    await eapi.save({ file_path: html_proof_file_path, data: html_proof });
    await eapi.save({ file_path: html_claim_file_path, data: html_claim });

    eco.post_status(`Saved timestamp (proofs and claim) to ${timestamp_dir_path} [with reference ${label}-${date_string}]`);
    send_witness_ebub(timestamp_server, witness_string); // {?} should have an option to do it later
}

async function find_pow_salt(initial_segment, prefix_to_find = '0000', num_digits_to_try=8) {
    const upper_bound = Math.pow(10, num_digits_to_try);
    for (let i = 0; i < upper_bound; i++) {
        const salt = nf(i, num_digits_to_try); const composite_hash = await sha_512_async(initial_segment + ':' + salt);
        if (composite_hash.startsWith(prefix_to_find)) return salt;
    }
    return undefined;
}


// {?} need to be unified further with send_witness_ebub
function send_witness_html(timestamp_server) {
    const witness_pre = document.getElementById('witness_string');
    const witness_string = witness_pre.innerText;

    const ws = new WebSocket(timestamp_server);
    ws.addEventListener('open', on_ws_open);
    ws.addEventListener('message', on_ws_message);

    async function on_ws_open(e) { await ws.send(witness_string) }

    async function on_ws_message(message) {
        try {
            witness_pre.innerText += ' ' + get_witness_confirmation_text(message);
            const swb = document.getElementById('swb'); if (swb) swb.style.display = 'none'; //  will only be non null if in a sender webpage
        } 
        catch (err) { return }
    }
}

// {?} need to be unified further with send_witness_html
function send_witness_ebub(timestamp_server, witness_string) {

    const ws = new WebSocket(timestamp_server);
    ws.addEventListener('open', on_ws_open);
    ws.addEventListener('message', on_ws_message);

    async function on_ws_open(e) { await ws.send(witness_string) }

    async function on_ws_message(message) {
        try { eco.post_status(get_witness_confirmation_text(message)) } 
        catch (err) { return }
    }
}

function get_witness_confirmation_text(message) { 
    try {
        const { witness_time, was_seen_before } = JSON.parse(message.data);
        return was_seen_before ? `(confirmed to exist since ${witness_time})` : `(just registered at ${witness_time})` 
    }
    catch (err) {
        return 'Could not parse confirmation message';
    }
}


function wrap_witness_sender({ witness_string, data, timestamp_server }) { 
    let result = '';
    result += `<!doctype HTML>\n<html>\n<body>` + '\n';
    if (data != undefined) result += `Origin:\n<code>\n\t<pre>${data}</pre>\n</code>` + '\n';
    result += `Witness:\n<code>\n\t<pre id='witness_string'>${witness_string}</pre>\n</code>` + '\n';
    result += `Check Witness:\n<code>\n\t<pre><a href='https://www.eulalie.io'>https://www.eulalie.io</a></pre>\n</code>`;
    result += `Timestamp Server:\n<code>\n\t<pre id ='timestamp_server'>${timestamp_server}</pre>\n</code>`;
    result += `<button onclick='submit_witness()' id='swb'>Submit Witness</button>` + '\n';
    result += `<script type='text/javascript'>\n${get_witness_confirmation_text.toString()}\n</script>` + '\n';
    result += `<script type='text/javascript'>\n${send_witness_html.toString()}\n</script>` + '\n';
    result += `<script type='text/javascript'>\nfunction submit_witness() { send_witness_html(document.getElementById('timestamp_server').innerText) }` + '\n' 
                + `setTimeout(submit_witness, 1);` + '\n' 
                + `</script>` + '\n';
    result += `</body>\n</html>\n`;
    return result;
}



