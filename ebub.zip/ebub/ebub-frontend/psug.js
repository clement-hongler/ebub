///////////////////////////////
/// Prompt Suggestion Class ///
///////////////////////////////

class Psug {
	constructor(xeco, prompt_div) {
		this.xeco = xeco;
		this.psugs = [];
		this.psug_divs = [];
		this.cur_psug_index = 3;
		this.init_div(prompt_div);
		// {?} later these should be just the keys of a dictionary that maps first words to functions
		this.prompt_command_names = ['name', 'rename', 'name-ewo', 'rename-ewo', 'ewo', 'info', 'ega'];
	}

	get cur_prompt_text() { return this.xeco.prompt_text_area.value }
	set cur_prompt_text(_prompt_text) { this.xeco.prompt_text_area.value = _prompt_text }

	get_possible_commands(prompt_beg) { return this.prompt_command_names.filter(name => name.startsWith(prompt_beg)); }

	init_div(prompt_div) {
		this.div = new_child_div(prompt_div);
		//for (let i = 0; i < 10; i++) this.add_new_psug(`This is a prompt suggestion at height ${i * 32}`);
	}

	add_new_psug(psug) {
		this.psugs.push(psug);
		const y = this.psugs.length * 32;
		const psug_div = new_child_div(this.div, { x: 0, y, w: 1024, h: 32, bg: '#000000dd' });
		psug_div.innerText = psug;
		this.psug_divs.push(psug_div);
	}

	clear_psugs() {
		this.div.innerHTML = '';
		this.psugs = [];
		this.psug_divs = [];
	}


	refresh_lf() {
		adj_elem(this.div, { h: this.screen_height - 32, resize: 'none', z: 1000000000 }); // {?} ugly
		this.psug_divs.forEach((psug_div, index) => { adj_elem(psug_div, { color: index == this.cur_psug_index ? '#ffffff' : '#dddddd' }) });
	}


	// Makes a list of suggestions based
	make_psugs() {
		this.clear_psugs();
		if (this.cur_prompt_text) {
			const possible_commands = this.get_possible_commands(this.cur_prompt_text);
			possible_commands.forEach(possible_command => this.add_new_psug(possible_command));
		}
	}
}