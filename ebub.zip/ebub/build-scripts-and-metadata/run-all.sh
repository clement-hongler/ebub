./node-build.sh
./mac-notarize.sh
./upload-to-metasim.sh